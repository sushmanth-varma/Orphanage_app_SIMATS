package com.SIMATS.hope;

public class ReceiptRequest {
    private int donation_id;
    private int volunteer_id;
    private int user_id;
    private String purpose;
    private String remarks;
    private double amount_donated;
    private double amount_used;
    private String item_description;
    private int quantity;

    // Constructor, getters and setters
}