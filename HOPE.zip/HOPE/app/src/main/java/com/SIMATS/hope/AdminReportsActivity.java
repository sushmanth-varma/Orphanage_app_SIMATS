package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class AdminReportsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_reports);

        CardView viewAllReportsCard = findViewById(R.id.viewAllReportsLayout);
        CardView updateReportStatusCard = findViewById(R.id.updateReportStatusLayout);

        viewAllReportsCard.setOnClickListener(v -> {
            startActivity(new Intent(AdminReportsActivity.this, AdminViewAllReportsActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });


        updateReportStatusCard.setOnClickListener(v -> {
            startActivity(new Intent(AdminReportsActivity.this, UpdateReportStatusActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }
}