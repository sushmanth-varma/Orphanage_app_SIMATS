// ApiResponse.java
package com.SIMATS.hope;

public class Volunteer_OtpResponse {
    private String status;
    private String message;
    private String password;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getPassword() {
        return password;
    }
}