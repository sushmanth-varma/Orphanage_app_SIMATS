package com.SIMATS.hope;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.util.concurrent.TimeUnit;

public class AssignVolunteerActivity_admin extends AppCompatActivity {

    private TextInputEditText donationIdEditText, volunteerIdEditText;
    private MaterialButton assignButton;
    private ProgressBar progressBar;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_volunteer_admin);

        // Initialize views
        donationIdEditText = findViewById(R.id.donationIdEditText);
        volunteerIdEditText = findViewById(R.id.volunteerIdEditText);
        assignButton = findViewById(R.id.assignButton);
        progressBar = findViewById(R.id.progressBar);

        // Initialize Retrofit with logging and timeout
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/") // Replace with your actual base URL
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(ApiService.class);

        assignButton.setOnClickListener(v -> assignVolunteer());
    }

    private void assignVolunteer() {
        String donationId = donationIdEditText.getText().toString().trim();
        String volunteerId = volunteerIdEditText.getText().toString().trim();

        if (donationId.isEmpty() || volunteerId.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show progress and disable button
        progressBar.setVisibility(View.VISIBLE);
        assignButton.setEnabled(false);

        AssignmentRequest_Donation_admin request = new AssignmentRequest_Donation_admin(
                Integer.parseInt(donationId),
                Integer.parseInt(volunteerId)
        );

        Call<AssignmentResponse_Donation_admin> call = apiService.assignVolunteer(request);
        call.enqueue(new Callback<AssignmentResponse_Donation_admin>() {
            @Override
            public void onResponse(Call<AssignmentResponse_Donation_admin> call, Response<AssignmentResponse_Donation_admin> response) {
                progressBar.setVisibility(View.GONE);
                assignButton.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    AssignmentResponse_Donation_admin assignmentResponse = response.body();
                    if (assignmentResponse.getStatus().equals("success")) {
                        Toast.makeText(AssignVolunteerActivity_admin.this,
                                "Volunteer assigned successfully", Toast.LENGTH_SHORT).show();
                        finish(); // Close activity on success
                    } else {
                        Toast.makeText(AssignVolunteerActivity_admin.this,
                                assignmentResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    try {
                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
                        Toast.makeText(AssignVolunteerActivity_admin.this,
                                "Failed to assign volunteer: " + errorBody, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(AssignVolunteerActivity_admin.this,
                                "Failed to assign volunteer", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AssignmentResponse_Donation_admin> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                assignButton.setEnabled(true);
                Toast.makeText(AssignVolunteerActivity_admin.this,
                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                t.printStackTrace();
            }
        });
    }
}