package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReportsActivity_Volunteer extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports_volunteer);

        // Navigate to Assigned Reports
// Example button click handler in VolunteerDashboardActivity
        findViewById(R.id.btnAssignedReports).setOnClickListener(v -> {
            startActivity(new Intent(this, AssignedReportsActivity_Volunteer.class));
        });

        // Navigate to Update Report Status
        findViewById(R.id.btnUpdateReportStatus).setOnClickListener(v -> {
            Intent intent = new Intent(this, UpdateReportStatusActivity_Volunteer.class);
            startActivity(intent);
        });
        findViewById(R.id.btnUpdateReportStatus).setOnClickListener(v -> {
            Log.d("NAV", "Attempting to launch UpdateStatusActivity");
            try {
                Intent intent = new Intent(this, UpdateReportStatusActivity_Volunteer.class);
                startActivity(intent);
            } catch (Exception e) {
                Log.e("NAV", "Failed to start activity", e);
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}