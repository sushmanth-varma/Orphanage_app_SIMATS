package com.SIMATS.hope;

public class DonationRequest {
    private String donation_type;
    private String cause;
    private String full_name;
    private String contact;         // Used in monetary
    private String phone;           // Used in material
    private String email;           // Used internally
    private String orphanage_name;
    private double amount;          // Only for monetary
    private String item_description; // Only for material
    private int quantity;
    private String status;
    private String location;
    // Only for material

    // Getters and Setters
    public String getDonation_type() { return donation_type; }
    public void setDonation_type(String donation_type) { this.donation_type = donation_type; }

    public String getCause() { return cause; }
    public void setCause(String cause) { this.cause = cause; }

    public String getFull_name() { return full_name; }
    public void setFull_name(String full_name) { this.full_name = full_name; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getOrphanage_name() { return orphanage_name; }
    public void setOrphanage_name(String orphanage_name) { this.orphanage_name = orphanage_name; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getItem_description() { return item_description; }
    public void setItem_description(String item_description) { this.item_description = item_description; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
