package com.SIMATS.hope;

public class ApiResult<T> {
    private String status;
    private String message;
    private T data;

    // Getters
    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }

    // Setters
    public void setStatus(String status) {
        this.status = status;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setData(T data) {
        this.data = data;
    }

    // Helper method to check if request was successful
    public boolean isSuccess() {
        return "success".equalsIgnoreCase(status);
    }
}