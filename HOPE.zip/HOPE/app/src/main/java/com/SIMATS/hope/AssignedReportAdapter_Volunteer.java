package com.SIMATS.hope;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class AssignedReportAdapter_Volunteer extends RecyclerView.Adapter<AssignedReportAdapter_Volunteer.ViewHolder> {

    private final Context context;
    private final ArrayList<AssignedReport_Volunteer> reports;

    public AssignedReportAdapter_Volunteer(Context context, ArrayList<AssignedReport_Volunteer> reports) {
        this.context = context;
        this.reports = reports;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtId, txtType, txtName, txtLocation, txtExactLocation, txtStatus;

        public ViewHolder(View itemView) {
            super(itemView);
            txtId = itemView.findViewById(R.id.txtId);
            txtType = itemView.findViewById(R.id.txtType);
            txtName = itemView.findViewById(R.id.txtName);
            txtLocation = itemView.findViewById(R.id.txtLocation);
            txtExactLocation = itemView.findViewById(R.id.txtExactLocation);
            txtStatus = itemView.findViewById(R.id.txtStatus);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.report_item_card_volunteer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AssignedReport_Volunteer report = reports.get(position);

        // Set report data
        holder.txtId.setText(report.getFormattedId());
        holder.txtType.setText(context.getString(R.string.report_type, report.type));
        holder.txtName.setText(context.getString(R.string.report_name_age, report.name, report.age));
        holder.txtLocation.setText(context.getString(R.string.report_location, report.generalLocation));
        holder.txtExactLocation.setText(context.getString(R.string.report_coordinates, report.getFormattedCoordinates()));
        holder.txtStatus.setText(context.getString(R.string.report_status, report.status));

        // Set click listener if coordinates are valid
        holder.itemView.setClickable(report.hasValidCoordinates());
        if (report.hasValidCoordinates()) {
            holder.itemView.setOnClickListener(v -> openLocationInMap(report));
            holder.txtExactLocation.setTextColor(ContextCompat.getColor(context, R.color.colorPrimary));
        } else {
            holder.txtExactLocation.setTextColor(ContextCompat.getColor(context, R.color.gray));
        }

        // Set status color
        switch(report.status.toLowerCase()) {
            case "completed":
                holder.txtStatus.setTextColor(ContextCompat.getColor(context, R.color.green));
                break;
            case "in progress":
                holder.txtStatus.setTextColor(ContextCompat.getColor(context, R.color.orange));
                break;
            default:
                holder.txtStatus.setTextColor(ContextCompat.getColor(context, R.color.red));
        }
    }

    private void openLocationInMap(AssignedReport_Volunteer report) {
        try {
            double[] coordinates = report.getCoordinates();
            String geoUri = String.format("geo:%f,%f?q=%f,%f(%s)",
                    coordinates[0], coordinates[1],
                    coordinates[0], coordinates[1],
                    report.generalLocation);

            String mapsWebUrl = String.format("https://www.google.com/maps/search/?api=1&query=%f,%f",
                    coordinates[0], coordinates[1]);

            // Try Google Maps first
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));
            mapIntent.setPackage("com.google.android.apps.maps");

            if (mapIntent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(mapIntent);
                return;
            }

            // Fallback to any map app
            Intent fallbackIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));
            if (fallbackIntent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(fallbackIntent);
                return;
            }

            // Final fallback to browser
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(mapsWebUrl));
            context.startActivity(browserIntent);

        } catch (Exception e) {
            Toast.makeText(context, "Couldn't open map", Toast.LENGTH_SHORT).show();
            Log.e("MapIntent", "Error opening location", e);
        }
    }

    @Override
    public int getItemCount() {
        return reports.size();
    }
}