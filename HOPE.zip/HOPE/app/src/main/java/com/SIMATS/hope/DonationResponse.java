package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class DonationResponse {
    private String status;
    private String message;
    private int donation_id;
    private boolean success;

    public boolean isSuccess() {
        return success;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getDonation_id() {
        return donation_id;
    }

    // Setters (optional, but good practice)
    public void setStatus(String status) { this.status = status; }
    public void setMessage(String message) { this.message = message; }
    public void setDonation_id(int donation_id) { this.donation_id = donation_id; }
    public void setSuccess(boolean success) { this.success = success; }
}