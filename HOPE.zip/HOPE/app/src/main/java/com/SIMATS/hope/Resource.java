package com.SIMATS.hope;

public class Resource {
    private String id;
    private String name;
    private String file_path; // must match JSON key from PHP

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFilePath() {
        return file_path;
    }

}
