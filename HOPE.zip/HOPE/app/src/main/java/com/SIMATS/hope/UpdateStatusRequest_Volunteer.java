package com.SIMATS.hope;

public class UpdateStatusRequest_Volunteer {
    private int report_id;
    private String status;
    private int volunteer_id;

    public UpdateStatusRequest_Volunteer(int report_id, String status, int volunteer_id) {
        this.report_id = report_id;
        this.status = status;
        this.volunteer_id = volunteer_id;
    }

    public int getReport_id() {
        return report_id;
    }

    public String getStatus() {
        return status;
    }

    public int getVolunteer_id() {
        return volunteer_id;
    }
}
