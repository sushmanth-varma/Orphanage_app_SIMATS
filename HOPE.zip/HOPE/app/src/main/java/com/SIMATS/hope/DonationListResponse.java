//package com.SIMATS.hope;
//
//import java.util.List;
//
//public class DonationListResponse {
//    private boolean status;
//    private String message;
//    private List<DonationModel> data;
//    private int count;
//    private int total_count;
//    private int current_page;
//    private int total_pages;
//
//    // Getters and Setters
//    public boolean isStatus() { return status; }
//    public String getMessage() { return message; }
//    public List<DonationModel> getData() { return data; }
//    public int getCount() { return count; }
//    public int getTotalCount() { return total_count; }
//    public int getCurrentPage() { return current_page; }
//    public int getTotalPages() { return total_pages; }
//}
package com.SIMATS.hope;

import java.util.List;

public class DonationListResponse {
    private boolean status;
    private String message;
    private List<DonationModel> data;
    private int count;
    private int total_count;
    private int current_page;
    private int total_pages;

    // Getters and Setters
    public boolean isStatus() { return status; }
    public void setStatus(boolean status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public List<DonationModel> getData() { return data; }
    public void setData(List<DonationModel> data) { this.data = data; }

    public int getCount() { return count; }
    public void setCount(int count) { this.count = count; }

    public int getTotalCount() { return total_count; }
    public void setTotalCount(int totalCount) { this.total_count = totalCount; }

    public int getCurrentPage() { return current_page; }
    public void setCurrentPage(int currentPage) { this.current_page = currentPage; }

    public int getTotalPages() { return total_pages; }
    public void setTotalPages(int totalPages) { this.total_pages = totalPages; }
}