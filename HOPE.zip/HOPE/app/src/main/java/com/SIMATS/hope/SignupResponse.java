package com.SIMATS.hope;

public class SignupResponse {
    private String status;
    private String message;
    private User user;

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public User getUser() { return user; }

    public static class User {
        private int id;
        private String username;
        private String phone;
        private String role;

        public int getId() { return id; }
        public String getUsername() { return username; }
        public String getPhone() { return phone; }
        public String getRole() { return role; }
    }
}
