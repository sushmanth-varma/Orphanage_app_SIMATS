package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Load animations
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        Animation bounce = AnimationUtils.loadAnimation(this, R.anim.bounce);

        // Apply animations
        findViewById(R.id.sloganText).startAnimation(fadeIn);

        ImageView bird1 = findViewById(R.id.bird1);
        ImageView bird2 = findViewById(R.id.bird2);
        bird1.startAnimation(bounce);
        bird2.startAnimation(bounce);

        Button startButton = findViewById(R.id.startButton);
        startButton.startAnimation(fadeIn);

        startButton.setOnClickListener(v -> {
            // Add button press animation
            v.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_click));

            new Handler().postDelayed(() -> {
                Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }, 200);
        });
    }
}