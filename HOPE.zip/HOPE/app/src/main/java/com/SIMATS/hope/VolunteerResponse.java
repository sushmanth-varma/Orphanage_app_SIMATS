// VolunteerResponse.java
package com.SIMATS.hope;

import java.util.List;

public class VolunteerResponse {
    private String status;
    private String message;
    private List<Volunteer_admin> data;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public List<Volunteer_admin> getData() {
        return data;
    }

    public boolean isSuccess() {
        return "success".equalsIgnoreCase(status);
    }
}
