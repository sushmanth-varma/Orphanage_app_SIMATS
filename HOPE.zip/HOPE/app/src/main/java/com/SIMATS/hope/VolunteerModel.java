package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class VolunteerModel {
    @SerializedName("id")
    private int id;

    @SerializedName("full_name")
    private String fullName;

    @SerializedName("phone")
    private String phone;

    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPhone() {
        return phone;
    }
}