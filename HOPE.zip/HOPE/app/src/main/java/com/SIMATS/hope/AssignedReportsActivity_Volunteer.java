//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.Toast;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
//import java.util.ArrayList;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class AssignedReportsActivity_Volunteer extends AppCompatActivity {
//
//    private static final String TAG = "AssignedReports";
//    private RecyclerView recyclerView;
//    private AssignedReportAdapter_Volunteer adapter;
//    private ArrayList<AssignedReport_Volunteer> reports = new ArrayList<>();
//    private PrefManager prefManager;
//    private SwipeRefreshLayout swipeRefreshLayout;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_assigned_reports_volunteer);
//
//        prefManager = new PrefManager(this);
//        checkLoginStatus();
//
//        initializeViews();
//        setupRecyclerView();
//        fetchAssignedReports();
//    }
//
//    private void checkLoginStatus() {
//        if (!prefManager.isLoggedIn() || !prefManager.isVolunteer()) {
//            redirectToLogin();
//        }
//    }
//
//    private void initializeViews() {
//        recyclerView = findViewById(R.id.recyclerReports);
//        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
//        swipeRefreshLayout.setOnRefreshListener(this::fetchAssignedReports);
//    }
//
//    private void setupRecyclerView() {
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        adapter = new AssignedReportAdapter_Volunteer(this, reports);
//        recyclerView.setAdapter(adapter);
//    }
//
//    private void redirectToLogin() {
//        Toast.makeText(this, "Please login as volunteer", Toast.LENGTH_SHORT).show();
//        Intent intent = new Intent(this, LoginActivity.class);
//        intent.putExtra("role", "volunteer");
//        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//        finish();
//    }
//
//    private void fetchAssignedReports() {
//        int volunteerId = prefManager.getVolunteerId();
//        if (volunteerId == -1) {
//            Toast.makeText(this, "Invalid volunteer session", Toast.LENGTH_SHORT).show();
//            redirectToLogin();
//            return;
//        }
//
//        swipeRefreshLayout.setRefreshing(true);
//
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<ApiResponseAssignedReports> call = apiService.getAssignedReports(volunteerId);
//
//        call.enqueue(new Callback<ApiResponseAssignedReports>() {
//            @Override
//            public void onResponse(Call<ApiResponseAssignedReports> call,
//                                   Response<ApiResponseAssignedReports> response) {
//                swipeRefreshLayout.setRefreshing(false);
//                if (response.isSuccessful() && response.body() != null) {
//                    handleApiResponse(response.body());
//                } else {
//                    Toast.makeText(AssignedReportsActivity_Volunteer.this,
//                            "Failed to get response", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ApiResponseAssignedReports> call, Throwable t) {
//                swipeRefreshLayout.setRefreshing(false);
//                Toast.makeText(AssignedReportsActivity_Volunteer.this,
//                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//                Log.e(TAG, "API call failed", t);
//            }
//        });
//    }
//
//    private void handleApiResponse(ApiResponseAssignedReports apiResponse) {
//        if (apiResponse.isSuccess()) {
//            updateReportsList(apiResponse.getData());
//        } else if ("empty".equals(apiResponse.getStatus())) {
//            reports.clear();
//            adapter.notifyDataSetChanged();
//            Toast.makeText(this, apiResponse.getMessage(), Toast.LENGTH_LONG).show();
//        } else {
//            Toast.makeText(this, "Error: " + apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private void updateReportsList(ArrayList<AssignedReport_Volunteer> newReports) {
//        reports.clear();
//        if (newReports != null) {
//            reports.addAll(newReports);
//        }
//        adapter.notifyDataSetChanged();
//
//        if (reports.isEmpty()) {
//            Toast.makeText(this, "No reports assigned to you", Toast.LENGTH_LONG).show();
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AssignedReportsActivity_Volunteer extends AppCompatActivity {

    private static final String TAG = "AssignedReports";
    private RecyclerView recyclerView;
    private AssignedReportAdapter_Volunteer adapter;
    private ArrayList<AssignedReport_Volunteer> reports = new ArrayList<>();
    private PrefManager prefManager;
    private SwipeRefreshLayout swipeRefreshLayout;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assigned_reports_volunteer);

        prefManager = new PrefManager(this);
        checkLoginStatus();

        initializeViews();
        setupBottomNavigation();
        setupRecyclerView();
        fetchAssignedReports();
    }

    private void checkLoginStatus() {
        if (!prefManager.isLoggedIn() || !prefManager.isVolunteer()) {
            redirectToLogin();
        }
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerReports);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        swipeRefreshLayout.setOnRefreshListener(this::fetchAssignedReports);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(AssignedReportsActivity_Volunteer.this, VolunteerDashboardActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_reports) {
                    // Already on reports page, do nothing
                    return true;
                } else if (itemId == R.id.nav_donations) {
                    startActivity(new Intent(AssignedReportsActivity_Volunteer.this, DonationListActivity_volunteer.class));
                    finish();
                    return true;
                }
                return false;
            }
        });

        // Set reports as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_reports);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AssignedReportAdapter_Volunteer(this, reports);
        recyclerView.setAdapter(adapter);
    }

    private void redirectToLogin() {
        Toast.makeText(this, "Please login as volunteer", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.putExtra("role", "volunteer");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    private void fetchAssignedReports() {
        int volunteerId = prefManager.getVolunteerId();
        if (volunteerId == -1) {
            Toast.makeText(this, "Invalid volunteer session", Toast.LENGTH_SHORT).show();
            redirectToLogin();
            return;
        }

        swipeRefreshLayout.setRefreshing(true);

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ApiResponseAssignedReports> call = apiService.getAssignedReports(volunteerId);

        call.enqueue(new Callback<ApiResponseAssignedReports>() {
            @Override
            public void onResponse(Call<ApiResponseAssignedReports> call,
                                   Response<ApiResponseAssignedReports> response) {
                swipeRefreshLayout.setRefreshing(false);
                if (response.isSuccessful() && response.body() != null) {
                    handleApiResponse(response.body());
                } else {
                    Toast.makeText(AssignedReportsActivity_Volunteer.this,
                            "Failed to get response", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponseAssignedReports> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                Toast.makeText(AssignedReportsActivity_Volunteer.this,
                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e(TAG, "API call failed", t);
            }
        });
    }

    private void handleApiResponse(ApiResponseAssignedReports apiResponse) {
        if (apiResponse.isSuccess()) {
            updateReportsList(apiResponse.getData());
        } else if ("empty".equals(apiResponse.getStatus())) {
            reports.clear();
            adapter.notifyDataSetChanged();
            Toast.makeText(this, apiResponse.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Error: " + apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void updateReportsList(ArrayList<AssignedReport_Volunteer> newReports) {
        reports.clear();
        if (newReports != null) {
            reports.addAll(newReports);
        }
        adapter.notifyDataSetChanged();

        if (reports.isEmpty()) {
            Toast.makeText(this, "No reports assigned to you", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Set reports as selected when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_reports);
        }
    }
}