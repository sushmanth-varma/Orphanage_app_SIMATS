//////package com.SIMATS.hope;
//////
//////import android.app.ProgressDialog;
//////import android.content.SharedPreferences;
//////import android.os.Bundle;
//////import android.view.View;
//////import android.widget.Button;
//////import android.widget.EditText;
//////import android.widget.ImageView;
//////import android.widget.Toast;
//////
//////import androidx.appcompat.app.AppCompatActivity;
//////
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////
//////public class MonetaryDonationActivity extends AppCompatActivity {
//////    private EditText autoCompleteCause, editCustomAmount, editLocation,
//////            editName, editContact, editOrphanageName;
//////    private Button btn100, btn500, btn1000, btnSubmit;
//////    private ImageView ivBack; // Added back button reference
//////    private ApiService apiService;
//////    private ProgressDialog progressDialog;
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.activity_monetary_donation);
//////
//////        initializeViews();
//////        setupClickListeners();
//////    }
//////
//////    private void initializeViews() {
//////        autoCompleteCause = findViewById(R.id.autoCompleteCause);
//////        editCustomAmount = findViewById(R.id.editCustomAmount);
//////        editLocation = findViewById(R.id.editLocation);
//////        editName = findViewById(R.id.editName);
//////        editContact = findViewById(R.id.editContact);
//////        editOrphanageName = findViewById(R.id.editTextOrphanageName);
//////
//////        btn100 = findViewById(R.id.btn100);
//////        btn500 = findViewById(R.id.btn500);
//////        btn1000 = findViewById(R.id.btn1000);
//////        btnSubmit = findViewById(R.id.btnSubmit);
//////        ivBack = findViewById(R.id.ivBack); // Initialize back button
//////
//////        apiService = ApiClient.getClient().create(ApiService.class);
//////        progressDialog = new ProgressDialog(this);
//////        progressDialog.setMessage("Submitting donation...");
//////        progressDialog.setCancelable(false);
//////    }
//////
//////    private void setupClickListeners() {
//////        btn100.setOnClickListener(v -> {
//////            editCustomAmount.setText("100");
//////            editCustomAmount.setError(null);
//////        });
//////
//////        btn500.setOnClickListener(v -> {
//////            editCustomAmount.setText("500");
//////            editCustomAmount.setError(null);
//////        });
//////
//////        btn1000.setOnClickListener(v -> {
//////            editCustomAmount.setText("1000");
//////            editCustomAmount.setError(null);
//////        });
//////
//////        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
//////
//////        // Add back button functionality
//////        ivBack.setOnClickListener(v -> finish());
//////    }
//////
//////    private void validateAndSubmitDonation() {
//////        String cause = autoCompleteCause.getText().toString().trim();
//////        String amountStr = editCustomAmount.getText().toString().trim();
//////        String location = editLocation.getText().toString().trim();
//////        String name = editName.getText().toString().trim();
//////        String contact = editContact.getText().toString().trim();
//////        String orphanageName = editOrphanageName.getText().toString().trim();
//////
//////        // Validate inputs
//////        if (!FormValidator.validateField(autoCompleteCause, "Please select a cause")) return;
//////        if (!FormValidator.validateField(editCustomAmount, "Please enter an amount")) return;
//////        if (!FormValidator.validateField(editLocation, "Please enter a location")) return;
//////        if (!FormValidator.validateField(editName, "Please enter your name")) return;
//////        if (!FormValidator.validateField(editContact, "Please enter contact information")) return;
//////        if (!FormValidator.validateField(editOrphanageName, "Please enter orphanage name")) return;
//////
//////        if (!FormValidator.isValidEmailOrPhone(contact)) {
//////            editContact.setError("Please enter valid email or phone");
//////            editContact.requestFocus();
//////            return;
//////        }
//////
//////        try {
//////            double amount = Double.parseDouble(amountStr);
//////            if (amount <= 0) {
//////                editCustomAmount.setError("Amount must be greater than 0");
//////                editCustomAmount.requestFocus();
//////                return;
//////            }
//////
//////            submitDonationToServer(cause, amount, location, name, contact, orphanageName);
//////        } catch (NumberFormatException e) {
//////            editCustomAmount.setError("Please enter a valid amount");
//////            editCustomAmount.requestFocus();
//////        }
//////    }
//////
//////    private void submitDonationToServer(String cause, double amount, String location,
//////                                        String name, String contact, String orphanageName) {
//////        progressDialog.show();
//////        btnSubmit.setEnabled(false);
//////
//////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////        int userId = prefs.getInt("user_id",0);
//////
//////        MonetaryDonationRequest request = new MonetaryDonationRequest(
//////                cause, amount, name, contact, orphanageName, location,userId
//////        );
//////
//////        Call<DonationResponse> call = apiService.sendMonetaryDonation(request);
//////        call.enqueue(new Callback<DonationResponse>() {
//////            @Override
//////            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
//////                progressDialog.dismiss();
//////                btnSubmit.setEnabled(true);
//////
//////                if (response.isSuccessful() && response.body() != null) {
//////                    DonationResponse donationResponse = response.body();
//////                    if (donationResponse.isSuccess()) {
//////                        showSuccess(donationResponse.getMessage());
//////                    } else {
//////                        showError(donationResponse.getMessage());
//////                    }
//////                } else {
//////                    showError("Server error. Please try again.");
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<DonationResponse> call, Throwable t) {
//////                progressDialog.dismiss();
//////                btnSubmit.setEnabled(true);
//////                showError("Network error: " + t.getMessage());
//////            }
//////        });
//////    }
//////
//////    private void showSuccess(String message) {
//////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//////        clearForm();
//////    }
//////
//////    private void showError(String message) {
//////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//////    }
//////
//////    private void clearForm() {
//////        autoCompleteCause.setText("");
//////        editCustomAmount.setText("");
//////        editLocation.setText("");
//////        editName.setText("");
//////        editContact.setText("");
//////        editOrphanageName.setText("");
//////    }
//////}
////package com.SIMATS.hope;
////
////import android.app.ProgressDialog;
////import android.content.Intent;
////import android.content.SharedPreferences;
////import android.net.Uri;
////import android.os.Bundle;
////import android.text.Editable;
////import android.text.TextWatcher;
////import android.view.View;
////import android.widget.AdapterView;
////import android.widget.ArrayAdapter;
////import android.widget.Button;
////import android.widget.EditText;
////import android.widget.ImageView;
////import android.widget.Spinner;
////import android.widget.Toast;
////
////import androidx.appcompat.app.AppCompatActivity;
////
////import java.util.ArrayList;
////import java.util.HashMap;
////import java.util.List;
////import java.util.Map;
////
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class MonetaryDonationActivity extends AppCompatActivity {
////    private Spinner spinnerCause, spinnerLocation, spinnerOrphanage;
////    private EditText editCustomAmount, editName, editContact;
////    private Button btn100, btn500, btn1000, btnSubmit;
////    private ImageView ivBack;
////    private ApiService apiService;
////    private ProgressDialog progressDialog;
////
////    private List<String> causesList = new ArrayList<>();
////    private List<String> citiesList = new ArrayList<>();
////    private List<Orphanage> orphanageList = new ArrayList<>();
////    private Map<String, String> orphanagePhoneMap = new HashMap<>();
////    private Map<String, Integer> orphanageIdMap = new HashMap<>();
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_monetary_donation);
////
////        initializeViews();
////        setupData();
////        setupClickListeners();
////    }
////
////    private void initializeViews() {
////        spinnerCause = findViewById(R.id.spinnerCause);
////        spinnerLocation = findViewById(R.id.spinnerLocation);
////        spinnerOrphanage = findViewById(R.id.spinnerOrphanage);
////        editCustomAmount = findViewById(R.id.editCustomAmount);
////        editName = findViewById(R.id.editName);
////        editContact = findViewById(R.id.editContact);
////
////        btn100 = findViewById(R.id.btn100);
////        btn500 = findViewById(R.id.btn500);
////        btn1000 = findViewById(R.id.btn1000);
////        btnSubmit = findViewById(R.id.btnSubmit);
////        ivBack = findViewById(R.id.ivBack);
////
////        apiService = ApiClient.getClient().create(ApiService.class);
////        progressDialog = new ProgressDialog(this);
////        progressDialog.setMessage("Processing donation...");
////        progressDialog.setCancelable(false);
////    }
////
////    private void setupData() {
////        // Setup causes
////        causesList.add("Select Cause");
////        causesList.add("Donation for Children");
////        causesList.add("Donation for Disabled Persons");
////        causesList.add("Donation for Education");
////        causesList.add("Donation for Food & Nutrition");
////        causesList.add("Donation for Healthcare");
////        causesList.add("Donation for Shelter");
////        causesList.add("Donation for Clothing");
////        causesList.add("General Donation");
////
////        ArrayAdapter<String> causeAdapter = new ArrayAdapter<>(this,
////                android.R.layout.simple_spinner_dropdown_item, causesList);
////        spinnerCause.setAdapter(causeAdapter);
////
////        // Fetch cities
////        fetchCities();
////
////        // Setup orphanage spinner listener
////        spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
////            @Override
////            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
////                String selectedCity = parent.getItemAtPosition(position).toString();
////                if (!selectedCity.equals("Select Location") && !selectedCity.isEmpty()) {
////                    fetchOrphanages(selectedCity);
////                } else {
////                    // Clear orphanage spinner if no city selected
////                    orphanageList.clear();
////                    orphanagePhoneMap.clear();
////                    orphanageIdMap.clear();
////                    ArrayAdapter<String> emptyAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
////                            android.R.layout.simple_spinner_dropdown_item, new String[]{"Select Orphanage"});
////                    spinnerOrphanage.setAdapter(emptyAdapter);
////                }
////            }
////
////            @Override
////            public void onNothingSelected(AdapterView<?> parent) {
////            }
////        });
////    }
////
////    private void fetchCities() {
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<CityResponse> call = apiService.getAllCities();
////
////        call.enqueue(new Callback<CityResponse>() {
////            @Override
////            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
////                if (response.isSuccessful() && response.body() != null) {
////                    citiesList = response.body().getCities();
////                    if (citiesList != null && !citiesList.isEmpty()) {
////                        citiesList.add(0, "Select Location");
////                        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
////                                android.R.layout.simple_spinner_dropdown_item, citiesList);
////                        spinnerLocation.setAdapter(locationAdapter);
////                    }
////                }
////            }
////
////            @Override
////            public void onFailure(Call<CityResponse> call, Throwable t) {
////                Toast.makeText(MonetaryDonationActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
////            }
////        });
////    }
////
////    private void fetchOrphanages(String city) {
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<OrphanageResponse> call = apiService.getOrphanages(city);
////
////        call.enqueue(new Callback<OrphanageResponse>() {
////            @Override
////            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
////                if (response.isSuccessful() && response.body() != null) {
////                    OrphanageResponse orphanageResponse = response.body();
////                    if ("success".equals(orphanageResponse.getStatus())) {
////                        orphanageList = orphanageResponse.getOrphanages();
////
////                        List<String> orphanageNames = new ArrayList<>();
////                        orphanageNames.add("Select Orphanage");
////
////                        // Clear previous data
////                        orphanagePhoneMap.clear();
////                        orphanageIdMap.clear();
////
////                        for (Orphanage orphanage : orphanageList) {
////                            orphanageNames.add(orphanage.getName());
////                            // Store phone number and ID for each orphanage
////                            orphanagePhoneMap.put(orphanage.getName(), orphanage.getPhone());
////                            orphanageIdMap.put(orphanage.getName(), orphanage.getId());
////                        }
////
////                        ArrayAdapter<String> orphanageAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
////                                android.R.layout.simple_spinner_dropdown_item, orphanageNames);
////                        spinnerOrphanage.setAdapter(orphanageAdapter);
////                    }
////                }
////            }
////
////            @Override
////            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
////                Toast.makeText(MonetaryDonationActivity.this, "Failed to fetch orphanages", Toast.LENGTH_SHORT).show();
////            }
////        });
////    }
////
////    private void setupClickListeners() {
////        btn100.setOnClickListener(v -> {
////            editCustomAmount.setText("100");
////            editCustomAmount.setError(null);
////        });
////
////        btn500.setOnClickListener(v -> {
////            editCustomAmount.setText("500");
////            editCustomAmount.setError(null);
////        });
////
////        btn1000.setOnClickListener(v -> {
////            editCustomAmount.setText("1000");
////            editCustomAmount.setError(null);
////        });
////
////        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
////        ivBack.setOnClickListener(v -> finish());
////    }
////
////    private void setupRealTimeValidation() {
////        editName.addTextChangedListener(new TextWatcher() {
////            @Override
////            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
////
////            @Override
////            public void onTextChanged(CharSequence s, int start, int before, int count) {}
////
////            @Override
////            public void afterTextChanged(Editable s) {
////                if (!s.toString().isEmpty() && !FormValidator.isValidName(s.toString())) {
////                    editName.setError("Only letters, spaces, . ' - allowed");
////                } else {
////                    editName.setError(null);
////                }
////            }
////        });
////
////        editContact.addTextChangedListener(new TextWatcher() {
////            @Override
////            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
////
////            @Override
////            public void onTextChanged(CharSequence s, int start, int before, int count) {}
////
////            @Override
////            public void afterTextChanged(Editable s) {
////                String contact = s.toString();
////                if (!contact.isEmpty()) {
////                    if (contact.contains("@")) {
////                        if (!FormValidator.isValidEmail(contact)) {
////                            editContact.setError("Invalid email format");
////                        } else {
////                            editContact.setError(null);
////                        }
////                    } else {
////                        if (!FormValidator.isValidIndianMobile(contact)) {
////                            editContact.setError("Invalid mobile number");
////                        } else {
////                            editContact.setError(null);
////                        }
////                    }
////                } else {
////                    editContact.setError(null);
////                }
////            }
////        });
////    }
////
////    private void validateAndSubmitDonation() {
////        String cause = spinnerCause.getSelectedItem().toString();
////        String location = spinnerLocation.getSelectedItem().toString();
////        String orphanageName = spinnerOrphanage.getSelectedItem().toString();
////        String amountStr = editCustomAmount.getText().toString().trim();
////        String name = editName.getText().toString().trim();
////        String contact = editContact.getText().toString().trim();
////
////        // Validate inputs
////        if (cause.equals("Select Cause")) {
////            Toast.makeText(this, "Please select a cause", Toast.LENGTH_SHORT).show();
////            return;
////        }
////        if (location.equals("Select Location")) {
////            Toast.makeText(this, "Please select a location", Toast.LENGTH_SHORT).show();
////            return;
////        }
////        if (orphanageName.equals("Select Orphanage")) {
////            Toast.makeText(this, "Please select an orphanage", Toast.LENGTH_SHORT).show();
////            return;
////        }
////
////        // Validate amount
////        if (amountStr.isEmpty()) {
////            editCustomAmount.setError("Please enter an amount");
////            editCustomAmount.requestFocus();
////            return;
////        }
////
////        double amount = 0;
////        try {
////            amount = Double.parseDouble(amountStr);
////            if (amount <= 0) {
////                editCustomAmount.setError("Amount must be greater than 0");
////                editCustomAmount.requestFocus();
////                return;
////            }
////            if (amount > 100000) {
////                editCustomAmount.setError("Amount cannot exceed ₹1,00,000");
////                editCustomAmount.requestFocus();
////                return;
////            }
////        } catch (NumberFormatException e) {
////            editCustomAmount.setError("Please enter a valid amount");
////            editCustomAmount.requestFocus();
////            return;
////        }
////
////        // Validate name with strict rules
////        if (name.isEmpty()) {
////            editName.setError("Please enter your name");
////            editName.requestFocus();
////            return;
////        }
////
////        if (!FormValidator.isValidName(name)) {
////            editName.setError("Please enter a valid name (only letters, spaces, . ' - allowed)");
////            editName.requestFocus();
////            return;
////        }
////
////        // Validate contact information
////        if (contact.isEmpty()) {
////            editContact.setError("Please enter email or phone number");
////            editContact.requestFocus();
////            return;
////        }
////
////        // Check if it's email or phone and validate accordingly
////        if (contact.contains("@")) {
////            // It's an email
////            if (!FormValidator.isValidEmail(contact)) {
////                editContact.setError("Please enter a valid email address");
////                editContact.requestFocus();
////                return;
////            }
////        } else {
////            // It's a phone number
////            if (!FormValidator.isValidIndianMobile(contact)) {
////                editContact.setError("Please enter a valid 10-digit Indian mobile number");
////                editContact.requestFocus();
////                return;
////            }
////        }
////
////        // Get orphanage phone number and redirect to payment
////        String orphanagePhone = orphanagePhoneMap.get(orphanageName);
////        if (orphanagePhone != null && !orphanagePhone.isEmpty()) {
////            redirectToPayment(orphanagePhone, amount, cause, orphanageName);
////        } else {
////            submitDonationToServer(cause, amount, location, name, contact, orphanageName);
////        }
////    }
////
////    // ... rest of your methods (redirectToPayment, submitDonationToServer, etc.)
////
////
////        // Get orphanage phone number and redirect to payment
////
////    private void redirectToPayment(String phoneNumber, double amount, String cause, String orphanageName) {
////        // Create UPI payment intent
////        String upiId = phoneNumber + "@upi"; // Assuming phone number is UPI ID
////        String note = "Donation for " + cause + " - " + orphanageName;
////
////        Uri uri = Uri.parse("upi://pay?pa=" + upiId +
////                "&pn=" + orphanageName +
////                "&am=" + amount +
////                "&tn=" + note +
////                "&cu=INR");
////
////        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
////
////        // Check if there's an app to handle the intent
////        if (intent.resolveActivity(getPackageManager()) != null) {
////            startActivityForResult(intent, 101);
////        } else {
////            // Fallback: Show phone number and ask user to manually make payment
////            Toast.makeText(this, "Please make payment to: " + phoneNumber, Toast.LENGTH_LONG).show();
////            // You can also copy to clipboard
////            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
////            android.content.ClipData clip = android.content.ClipData.newPlainText("Phone Number", phoneNumber);
////            clipboard.setPrimaryClip(clip);
////
////            Toast.makeText(this, "Phone number copied to clipboard", Toast.LENGTH_SHORT).show();
////
////            // Proceed with donation submission
////            submitDonationToServer(cause, amount,
////                    spinnerLocation.getSelectedItem().toString(),
////                    editName.getText().toString().trim(),
////                    editContact.getText().toString().trim(),
////                    orphanageName);
////        }
////    }
////
////
////    @Override
////    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
////        super.onActivityResult(requestCode, resultCode, data);
////        if (requestCode == 101) {
////            if (resultCode == RESULT_OK) {
////                // Payment successful
////                submitDonationToServer(
////                        spinnerCause.getSelectedItem().toString(),
////                        Double.parseDouble(editCustomAmount.getText().toString()),
////                        spinnerLocation.getSelectedItem().toString(),
////                        editName.getText().toString().trim(),
////                        editContact.getText().toString().trim(),
////                        spinnerOrphanage.getSelectedItem().toString()
////                );
////            } else {
////                Toast.makeText(this, "Payment cancelled", Toast.LENGTH_SHORT).show();
////            }
////        }
////    }
////
////    private void submitDonationToServer(String cause, double amount, String location,
////                                        String name, String contact, String orphanageName) {
////        progressDialog.show();
////        btnSubmit.setEnabled(false);
////
////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////        int userId = prefs.getInt("user_id", 0);
////
////        MonetaryDonationRequest request = new MonetaryDonationRequest(
////                cause, amount, name, contact, orphanageName, location, userId
////        );
////
////        Call<DonationResponse> call = apiService.sendMonetaryDonation(request);
////        call.enqueue(new Callback<DonationResponse>() {
////            @Override
////            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
////                progressDialog.dismiss();
////                btnSubmit.setEnabled(true);
////
////                if (response.isSuccessful() && response.body() != null) {
////                    DonationResponse donationResponse = response.body();
////                    if (donationResponse.isSuccess()) {
////                        showSuccess(donationResponse.getMessage());
////                    } else {
////                        showError(donationResponse.getMessage());
////                    }
////                } else {
////                    showError("Server error. Please try again.");
////                }
////            }
////
////            @Override
////            public void onFailure(Call<DonationResponse> call, Throwable t) {
////                progressDialog.dismiss();
////                btnSubmit.setEnabled(true);
////                showError("Network error: " + t.getMessage());
////            }
////        });
////    }
////
////    private void showSuccess(String message) {
////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
////        clearForm();
////    }
////
////    private void showError(String message) {
////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
////    }
////
////    private void clearForm() {
////        spinnerCause.setSelection(0);
////        spinnerLocation.setSelection(0);
////        spinnerOrphanage.setSelection(0);
////        editCustomAmount.setText("");
////        editName.setText("");
////        editContact.setText("");
////    }
////
////}
//package com.SIMATS.hope;
//
//import android.app.ProgressDialog;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.net.Uri;
//import android.os.Bundle;
//import android.text.Editable;
//import android.text.TextWatcher;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.Spinner;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.android.material.bottomnavigation.BottomNavigationView;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class MonetaryDonationActivity extends AppCompatActivity {
//    private Spinner spinnerCause, spinnerLocation, spinnerOrphanage;
//    private EditText editCustomAmount, editName, editContact;
//    private Button btn100, btn500, btn1000, btnSubmit;
//    private ImageView ivBack;
//    private ApiService apiService;
//    private ProgressDialog progressDialog;
//    private BottomNavigationView bottomNavigationView;
//
//    private List<String> causesList = new ArrayList<>();
//    private List<String> citiesList = new ArrayList<>();
//    private List<Orphanage> orphanageList = new ArrayList<>();
//    private Map<String, String> orphanagePhoneMap = new HashMap<>();
//    private Map<String, Integer> orphanageIdMap = new HashMap<>();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_monetary_donation);
//
//        initializeViews();
//        setupBottomNavigation();
//        setupData();
//        setupClickListeners();
//        setupRealTimeValidation();
//    }
//
//    private void initializeViews() {
//        spinnerCause = findViewById(R.id.spinnerCause);
//        spinnerLocation = findViewById(R.id.spinnerLocation);
//        spinnerOrphanage = findViewById(R.id.spinnerOrphanage);
//        editCustomAmount = findViewById(R.id.editCustomAmount);
//        editName = findViewById(R.id.editName);
//        editContact = findViewById(R.id.editContact);
//
//        btn100 = findViewById(R.id.btn100);
//        btn500 = findViewById(R.id.btn500);
//        btn1000 = findViewById(R.id.btn1000);
//        btnSubmit = findViewById(R.id.btnSubmit);
//        ivBack = findViewById(R.id.ivBack);
//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//
//        apiService = ApiClient.getClient().create(ApiService.class);
//        progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Processing donation...");
//        progressDialog.setCancelable(false);
//    }
//
//    private void setupBottomNavigation() {
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                int itemId = item.getItemId();
//
//                if (itemId == R.id.nav_home) {
//                    startActivity(new Intent(MonetaryDonationActivity.this, DashboardActivity.class));
//                    finish();
//                    return true;
//                } else if (itemId == R.id.nav_donate) {
//                    // Already on donate page, no need to navigate
//                    return true;
//                } else if (itemId == R.id.nav_report) {
//                    startActivity(new Intent(MonetaryDonationActivity.this, ReportChildActivity.class));
//                    finish();
//                    return true;
//                } else if (itemId == R.id.nav_volunteer) {
//                    startActivity(new Intent(MonetaryDonationActivity.this, VolunteerRequestActivity.class));
//                    finish();
//                    return true;
//                } else if (itemId == R.id.nav_profile) {
//                    startActivity(new Intent(MonetaryDonationActivity.this, SettingsActivity.class));
//                    finish();
//                    return true;
//                }
//                return false;
//            }
//        });
//
//        // Highlight the Donate button since this is a donation-related activity
//        bottomNavigationView.setSelectedItemId(R.id.nav_donate);
//    }
//
//    private void setupData() {
//        // Setup causes
//        causesList.add("Select Cause");
//        causesList.add("Donation for Children");
//        causesList.add("Donation for Disabled Persons");
//        causesList.add("Donation for Education");
//        causesList.add("Donation for Food & Nutrition");
//        causesList.add("Donation for Healthcare");
//        causesList.add("Donation for Shelter");
//        causesList.add("Donation for Clothing");
//        causesList.add("General Donation");
//
//        ArrayAdapter<String> causeAdapter = new ArrayAdapter<>(this,
//                android.R.layout.simple_spinner_dropdown_item, causesList);
//        spinnerCause.setAdapter(causeAdapter);
//
//        // Fetch cities
//        fetchCities();
//
//        // Setup orphanage spinner listener
//        spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedCity = parent.getItemAtPosition(position).toString();
//                if (!selectedCity.equals("Select Location") && !selectedCity.isEmpty()) {
//                    fetchOrphanages(selectedCity);
//                } else {
//                    // Clear orphanage spinner if no city selected
//                    orphanageList.clear();
//                    orphanagePhoneMap.clear();
//                    orphanageIdMap.clear();
//                    ArrayAdapter<String> emptyAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
//                            android.R.layout.simple_spinner_dropdown_item, new String[]{"Select Orphanage"});
//                    spinnerOrphanage.setAdapter(emptyAdapter);
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });
//    }
//
//    private void fetchCities() {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<CityResponse> call = apiService.getAllCities();
//
//        call.enqueue(new Callback<CityResponse>() {
//            @Override
//            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    citiesList = response.body().getCities();
//                    if (citiesList != null && !citiesList.isEmpty()) {
//                        citiesList.add(0, "Select Location");
//                        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
//                                android.R.layout.simple_spinner_dropdown_item, citiesList);
//                        spinnerLocation.setAdapter(locationAdapter);
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<CityResponse> call, Throwable t) {
//                Toast.makeText(MonetaryDonationActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void fetchOrphanages(String city) {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<OrphanageResponse> call = apiService.getOrphanages(city);
//
//        call.enqueue(new Callback<OrphanageResponse>() {
//            @Override
//            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    OrphanageResponse orphanageResponse = response.body();
//                    if ("success".equals(orphanageResponse.getStatus())) {
//                        orphanageList = orphanageResponse.getOrphanages();
//
//                        List<String> orphanageNames = new ArrayList<>();
//                        orphanageNames.add("Select Orphanage");
//
//                        // Clear previous data
//                        orphanagePhoneMap.clear();
//                        orphanageIdMap.clear();
//
//                        for (Orphanage orphanage : orphanageList) {
//                            orphanageNames.add(orphanage.getName());
//                            // Store phone number and ID for each orphanage
//                            orphanagePhoneMap.put(orphanage.getName(), orphanage.getPhone());
//                            orphanageIdMap.put(orphanage.getName(), orphanage.getId());
//                        }
//
//                        ArrayAdapter<String> orphanageAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
//                                android.R.layout.simple_spinner_dropdown_item, orphanageNames);
//                        spinnerOrphanage.setAdapter(orphanageAdapter);
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
//                Toast.makeText(MonetaryDonationActivity.this, "Failed to fetch orphanages", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void setupClickListeners() {
//        btn100.setOnClickListener(v -> {
//            editCustomAmount.setText("100");
//            editCustomAmount.setError(null);
//        });
//
//        btn500.setOnClickListener(v -> {
//            editCustomAmount.setText("500");
//            editCustomAmount.setError(null);
//        });
//
//        btn1000.setOnClickListener(v -> {
//            editCustomAmount.setText("1000");
//            editCustomAmount.setError(null);
//        });
//
//        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
//        ivBack.setOnClickListener(v -> finish());
//    }
//
//    private void setupRealTimeValidation() {
//        editName.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {}
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                if (!s.toString().isEmpty() && !FormValidator.isValidName(s.toString())) {
//                    editName.setError("Only letters, spaces, . ' - allowed");
//                } else {
//                    editName.setError(null);
//                }
//            }
//        });
//
//        editContact.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {}
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                String contact = s.toString();
//                if (!contact.isEmpty()) {
//                    if (contact.contains("@")) {
//                        if (!FormValidator.isValidEmail(contact)) {
//                            editContact.setError("Invalid email format");
//                        } else {
//                            editContact.setError(null);
//                        }
//                    } else {
//                        if (!FormValidator.isValidIndianMobile(contact)) {
//                            editContact.setError("Invalid mobile number");
//                        } else {
//                            editContact.setError(null);
//                        }
//                    }
//                } else {
//                    editContact.setError(null);
//                }
//            }
//        });
//    }
//
//    private void validateAndSubmitDonation() {
//        String cause = spinnerCause.getSelectedItem().toString();
//        String location = spinnerLocation.getSelectedItem().toString();
//        String orphanageName = spinnerOrphanage.getSelectedItem().toString();
//        String amountStr = editCustomAmount.getText().toString().trim();
//        String name = editName.getText().toString().trim();
//        String contact = editContact.getText().toString().trim();
//
//        // Validate inputs
//        if (cause.equals("Select Cause")) {
//            Toast.makeText(this, "Please select a cause", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (location.equals("Select Location")) {
//            Toast.makeText(this, "Please select a location", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (orphanageName.equals("Select Orphanage")) {
//            Toast.makeText(this, "Please select an orphanage", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Validate amount
//        if (amountStr.isEmpty()) {
//            editCustomAmount.setError("Please enter an amount");
//            editCustomAmount.requestFocus();
//            return;
//        }
//
//        double amount = 0;
//        try {
//            amount = Double.parseDouble(amountStr);
//            if (amount <= 0) {
//                editCustomAmount.setError("Amount must be greater than 0");
//                editCustomAmount.requestFocus();
//                return;
//            }
//            if (amount > 100000) {
//                editCustomAmount.setError("Amount cannot exceed ₹1,00,000");
//                editCustomAmount.requestFocus();
//                return;
//            }
//        } catch (NumberFormatException e) {
//            editCustomAmount.setError("Please enter a valid amount");
//            editCustomAmount.requestFocus();
//            return;
//        }
//
//        // Validate name with strict rules
//        if (name.isEmpty()) {
//            editName.setError("Please enter your name");
//            editName.requestFocus();
//            return;
//        }
//
//        if (!FormValidator.isValidName(name)) {
//            editName.setError("Please enter a valid name (only letters, spaces, . ' - allowed)");
//            editName.requestFocus();
//            return;
//        }
//
//        // Validate contact information
//        if (contact.isEmpty()) {
//            editContact.setError("Please enter email or phone number");
//            editContact.requestFocus();
//            return;
//        }
//
//        // Check if it's email or phone and validate accordingly
//        if (contact.contains("@")) {
//            // It's an email
//            if (!FormValidator.isValidEmail(contact)) {
//                editContact.setError("Please enter a valid email address");
//                editContact.requestFocus();
//                return;
//            }
//        } else {
//            // It's a phone number
//            if (!FormValidator.isValidIndianMobile(contact)) {
//                editContact.setError("Please enter a valid 10-digit Indian mobile number");
//                editContact.requestFocus();
//                return;
//            }
//        }
//
//        // Get orphanage phone number and redirect to payment
//        String orphanagePhone = orphanagePhoneMap.get(orphanageName);
//        if (orphanagePhone != null && !orphanagePhone.isEmpty()) {
//            redirectToPayment(orphanagePhone, amount, cause, orphanageName);
//        } else {
//            submitDonationToServer(cause, amount, location, name, contact, orphanageName);
//        }
//    }
//
//    private void redirectToPayment(String phoneNumber, double amount, String cause, String orphanageName) {
//        // Create UPI payment intent
//        String upiId = phoneNumber + "@upi"; // Assuming phone number is UPI ID
//        String note = "Donation for " + cause + " - " + orphanageName;
//
//        Uri uri = Uri.parse("upi://pay?pa=" + upiId +
//                "&pn=" + orphanageName +
//                "&am=" + amount +
//                "&tn=" + note +
//                "&cu=INR");
//
//        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
//
//        // Check if there's an app to handle the intent
//        if (intent.resolveActivity(getPackageManager()) != null) {
//            startActivityForResult(intent, 101);
//        } else {
//            // Fallback: Show phone number and ask user to manually make payment
//            Toast.makeText(this, "Please make payment to: " + phoneNumber, Toast.LENGTH_LONG).show();
//            // You can also copy to clipboard
//            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
//            android.content.ClipData clip = android.content.ClipData.newPlainText("Phone Number", phoneNumber);
//            clipboard.setPrimaryClip(clip);
//
//            Toast.makeText(this, "Phone number copied to clipboard", Toast.LENGTH_SHORT).show();
//
//            // Proceed with donation submission
//            submitDonationToServer(cause, amount,
//                    spinnerLocation.getSelectedItem().toString(),
//                    editName.getText().toString().trim(),
//                    editContact.getText().toString().trim(),
//                    orphanageName);
//        }
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == 101) {
//            if (resultCode == RESULT_OK) {
//                // Payment successful
//                submitDonationToServer(
//                        spinnerCause.getSelectedItem().toString(),
//                        Double.parseDouble(editCustomAmount.getText().toString()),
//                        spinnerLocation.getSelectedItem().toString(),
//                        editName.getText().toString().trim(),
//                        editContact.getText().toString().trim(),
//                        spinnerOrphanage.getSelectedItem().toString()
//                );
//            } else {
//                Toast.makeText(this, "Payment cancelled", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//    private void submitDonationToServer(String cause, double amount, String location,
//                                        String name, String contact, String orphanageName) {
//        progressDialog.show();
//        btnSubmit.setEnabled(false);
//
//        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//        int userId = prefs.getInt("user_id", 0);
//
//        MonetaryDonationRequest request = new MonetaryDonationRequest(
//                cause, amount, name, contact, orphanageName, location, userId
//        );
//
//        Call<DonationResponse> call = apiService.sendMonetaryDonation(request);
//        call.enqueue(new Callback<DonationResponse>() {
//            @Override
//            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
//                progressDialog.dismiss();
//                btnSubmit.setEnabled(true);
//
//                if (response.isSuccessful() && response.body() != null) {
//                    DonationResponse donationResponse = response.body();
//                    if (donationResponse.isSuccess()) {
//                        showSuccess(donationResponse.getMessage());
//                    } else {
//                        showError(donationResponse.getMessage());
//                    }
//                } else {
//                    showError("Server error. Please try again.");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<DonationResponse> call, Throwable t) {
//                progressDialog.dismiss();
//                btnSubmit.setEnabled(true);
//                showError("Network error: " + t.getMessage());
//            }
//        });
//    }
//
//    private void showSuccess(String message) {
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//        clearForm();
//    }
//
//    private void showError(String message) {
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//    }
//
//    private void clearForm() {
//        spinnerCause.setSelection(0);
//        spinnerLocation.setSelection(0);
//        spinnerOrphanage.setSelection(0);
//        editCustomAmount.setText("");
//        editName.setText("");
//        editContact.setText("");
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        // Highlight the Donate button when returning to this activity
//        if (bottomNavigationView != null) {
//            bottomNavigationView.setSelectedItemId(R.id.nav_donate);
//        }
//    }
//}
package com.SIMATS.hope;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MonetaryDonationActivity extends AppCompatActivity {
    private Spinner spinnerCause, spinnerLocation, spinnerOrphanage;
    private EditText editCustomAmount, editName, editContact;
    private Button btn50,btn100, btn500, btn1000, btnSubmit;
    private ImageView ivBack;
    private ApiService apiService;
    private ProgressDialog progressDialog;
    private BottomNavigationView bottomNavigationView;
    private ImageButton btnDecrease, btnIncrease; // Changed from Button to ImageButton
    private int lastSelectedAmount = 0;
    private List<String> causesList = new ArrayList<>();
    private List<String> citiesList = new ArrayList<>();
    private List<Orphanage> orphanageList = new ArrayList<>();
    private Map<String, String> orphanagePhoneMap = new HashMap<>();
    private Map<String, Integer> orphanageIdMap = new HashMap<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monetary_donation);

        initializeViews();
        setupBottomNavigation();
        setupData();
        setupClickListeners();
        setupRealTimeValidation();
    }

    private void initializeViews() {
        spinnerCause = findViewById(R.id.spinnerCause);
        spinnerLocation = findViewById(R.id.spinnerLocation);
        spinnerOrphanage = findViewById(R.id.spinnerOrphanage);
        editCustomAmount = findViewById(R.id.editCustomAmount);
        editName = findViewById(R.id.editName);
        editContact = findViewById(R.id.editContact);
        btn50=findViewById(R.id.btn50);
        btn100 = findViewById(R.id.btn100);
        btn500 = findViewById(R.id.btn500);
        btn1000 = findViewById(R.id.btn1000);
        btnSubmit = findViewById(R.id.btnSubmit);
        ivBack = findViewById(R.id.ivBack);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        btnDecrease = findViewById(R.id.btnDecrease);
        btnIncrease = findViewById(R.id.btnIncrease);

        apiService = ApiClient.getClient().create(ApiService.class);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing donation...");
        progressDialog.setCancelable(false);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    // Redirect to appropriate dashboard based on user type
                    SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                    String userRole = prefs.getString("user_role", "user");

                    Intent intent;
                    if ("admin".equalsIgnoreCase(userRole)) {
                        intent = new Intent(MonetaryDonationActivity.this, NGODashboardActivity.class);
                    } else if ("volunteer".equalsIgnoreCase(userRole)) {
                        intent = new Intent(MonetaryDonationActivity.this, VolunteerDashboardActivity.class);
                    } else {
                        intent = new Intent(MonetaryDonationActivity.this, DashboardActivity.class);
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                    return true;
                } else if (itemId == R.id.nav_donate) {
                    // Already on donate page, no need to navigate
                    return true;
                } else if (itemId == R.id.nav_report) {
                    startActivity(new Intent(MonetaryDonationActivity.this, ReportChildActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_volunteer) {
                    startActivity(new Intent(MonetaryDonationActivity.this, VolunteerRequestActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(MonetaryDonationActivity.this, SettingsActivity.class));
                    finish();
                    return true;
                }
                return false;
            }
        });

        // Highlight the Donate button since this is a donation-related activity
        bottomNavigationView.setSelectedItemId(R.id.nav_donate);
    }

    private void setupData() {
        // Setup causes
        causesList.add("Select Cause");
        causesList.add("Donation for Children");
        causesList.add("Donation for Disabled Persons");
        causesList.add("Donation for Education");
        causesList.add("Donation for Food & Nutrition");
        causesList.add("Donation for Healthcare");
        causesList.add("Donation for Shelter");
        causesList.add("Donation for Clothing");
        causesList.add("General Donation");

        ArrayAdapter<String> causeAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, causesList);
        spinnerCause.setAdapter(causeAdapter);

        // Fetch cities
        fetchCities();

        // Setup orphanage spinner listener
        spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = parent.getItemAtPosition(position).toString();
                if (!selectedCity.equals("Select Location") && !selectedCity.isEmpty()) {
                    fetchOrphanages(selectedCity);
                } else {
                    // Clear orphanage spinner if no city selected
                    orphanageList.clear();
                    orphanagePhoneMap.clear();
                    orphanageIdMap.clear();
                    ArrayAdapter<String> emptyAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
                            android.R.layout.simple_spinner_dropdown_item, new String[]{"Select Orphanage"});
                    spinnerOrphanage.setAdapter(emptyAdapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void fetchCities() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<CityResponse> call = apiService.getAllCities();

        call.enqueue(new Callback<CityResponse>() {
            @Override
            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    citiesList = response.body().getCities();
                    if (citiesList != null && !citiesList.isEmpty()) {
                        citiesList.add(0, "Select Location");
                        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
                                android.R.layout.simple_spinner_dropdown_item, citiesList);
                        spinnerLocation.setAdapter(locationAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<CityResponse> call, Throwable t) {
                Toast.makeText(MonetaryDonationActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchOrphanages(String city) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<OrphanageResponse> call = apiService.getOrphanages(city);

        call.enqueue(new Callback<OrphanageResponse>() {
            @Override
            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    OrphanageResponse orphanageResponse = response.body();
                    if ("success".equals(orphanageResponse.getStatus())) {
                        orphanageList = orphanageResponse.getOrphanages();

                        List<String> orphanageNames = new ArrayList<>();
                        orphanageNames.add("Select Orphanage");

                        // Clear previous data
                        orphanagePhoneMap.clear();
                        orphanageIdMap.clear();

                        for (Orphanage orphanage : orphanageList) {
                            orphanageNames.add(orphanage.getName());
                            // Store phone number and ID for each orphanage
                            orphanagePhoneMap.put(orphanage.getName(), orphanage.getPhone());
                            orphanageIdMap.put(orphanage.getName(), orphanage.getId());
                        }

                        ArrayAdapter<String> orphanageAdapter = new ArrayAdapter<>(MonetaryDonationActivity.this,
                                android.R.layout.simple_spinner_dropdown_item, orphanageNames);
                        spinnerOrphanage.setAdapter(orphanageAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
                Toast.makeText(MonetaryDonationActivity.this, "Failed to fetch orphanages", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupClickListeners() {
        btn50.setOnClickListener(v -> {
            editCustomAmount.setText("50");
            editCustomAmount.setError(null);
            lastSelectedAmount = 50;
        });
        btn100.setOnClickListener(v -> {
            editCustomAmount.setText("100");
            editCustomAmount.setError(null);
            lastSelectedAmount = 100;
        });

        btn500.setOnClickListener(v -> {
            editCustomAmount.setText("500");
            editCustomAmount.setError(null);
            lastSelectedAmount = 500;
        });

        btn1000.setOnClickListener(v -> {
            editCustomAmount.setText("1000");
            editCustomAmount.setError(null);
            lastSelectedAmount = 1000;
        });

        btnDecrease.setOnClickListener(v -> adjustAmount(false));
        btnIncrease.setOnClickListener(v -> adjustAmount(true));

        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
        ivBack.setOnClickListener(v -> finish());
    }

    private void adjustAmount(boolean increase) {
        String currentAmountStr = editCustomAmount.getText().toString().trim();
        int currentAmount = 0;
        int increment = 50; // Default increment

        // Determine the increment based on the last selected amount
        if (lastSelectedAmount > 0) {
            increment = lastSelectedAmount;
        } else if (!currentAmountStr.isEmpty()) {
            try {
                currentAmount = Integer.parseInt(currentAmountStr);
                // Determine increment based on current amount
                if (currentAmount % 1000 == 0) {
                    increment = 1000;
                } else if (currentAmount % 500 == 0) {
                    increment = 500;
                } else if (currentAmount % 100 == 0) {
                    increment = 100;
                } else {
                    increment = 50;
                }
            } catch (NumberFormatException e) {
                increment = 50;
            }
        }

        // Calculate new amount
        int newAmount;
        if (currentAmountStr.isEmpty()) {
            newAmount = increase ? increment : 0;
        } else {
            try {
                currentAmount = Integer.parseInt(currentAmountStr);
                newAmount = increase ? currentAmount + increment : Math.max(0, currentAmount - increment);
            } catch (NumberFormatException e) {
                newAmount = increase ? increment : 0;
            }
        }

        // Update the amount field
        editCustomAmount.setText(String.valueOf(newAmount));
        editCustomAmount.setError(null);
    }

    private void setupRealTimeValidation() {
        editName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty() && !FormValidator.isValidName(s.toString())) {
                    editName.setError("Only letters, spaces, . ' - allowed");
                } else {
                    editName.setError(null);
                }
            }
        });

        editContact.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String contact = s.toString();
                if (!contact.isEmpty()) {
                    if (contact.contains("@")) {
                        if (!FormValidator.isValidEmail(contact)) {
                            editContact.setError("Invalid email format");
                        } else {
                            editContact.setError(null);
                        }
                    } else {
                        if (!FormValidator.isValidIndianMobile(contact)) {
                            editContact.setError("Invalid mobile number");
                        } else {
                            editContact.setError(null);
                        }
                    }
                } else {
                    editContact.setError(null);
                }
            }
        });
    }

    private void validateAndSubmitDonation() {
        String cause = spinnerCause.getSelectedItem().toString();
        String location = spinnerLocation.getSelectedItem().toString();
        String orphanageName = spinnerOrphanage.getSelectedItem().toString();
        String amountStr = editCustomAmount.getText().toString().trim();
        String name = editName.getText().toString().trim();
        String contact = editContact.getText().toString().trim();

        // Validate inputs
        if (cause.equals("Select Cause")) {
            Toast.makeText(this, "Please select a cause", Toast.LENGTH_SHORT).show();
            return;
        }
        if (location.equals("Select Location")) {
            Toast.makeText(this, "Please select a location", Toast.LENGTH_SHORT).show();
            return;
        }
        if (orphanageName.equals("Select Orphanage")) {
            Toast.makeText(this, "Please select an orphanage", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate amount
        if (amountStr.isEmpty()) {
            editCustomAmount.setError("Please enter an amount");
            editCustomAmount.requestFocus();
            return;
        }

        double amount = 0;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                editCustomAmount.setError("Amount must be greater than 0");
                editCustomAmount.requestFocus();
                return;
            }
            if (amount > 100000) {
                editCustomAmount.setError("Amount cannot exceed ₹1,00,000");
                editCustomAmount.requestFocus();
                return;
            }
        } catch (NumberFormatException e) {
            editCustomAmount.setError("Please enter a valid amount");
            editCustomAmount.requestFocus();
            return;
        }

        // Validate name with strict rules
        if (name.isEmpty()) {
            editName.setError("Please enter your name");
            editName.requestFocus();
            return;
        }

        if (!FormValidator.isValidName(name)) {
            editName.setError("Please enter a valid name (only letters, spaces, . ' - allowed)");
            editName.requestFocus();
            return;
        }

        // Validate contact information
        if (contact.isEmpty()) {
            editContact.setError("Please enter email or phone number");
            editContact.requestFocus();
            return;
        }

        // Check if it's email or phone and validate accordingly
        if (contact.contains("@")) {
            // It's an email
            if (!FormValidator.isValidEmail(contact)) {
                editContact.setError("Please enter a valid email address");
                editContact.requestFocus();
                return;
            }
        } else {
            // It's a phone number
            if (!FormValidator.isValidIndianMobile(contact)) {
                editContact.setError("Please enter a valid 10-digit Indian mobile number");
                editContact.requestFocus();
                return;
            }
        }

        // Get orphanage phone number and redirect to payment
        String orphanagePhone = orphanagePhoneMap.get(orphanageName);
        if (orphanagePhone != null && !orphanagePhone.isEmpty()) {
            redirectToPayment(orphanagePhone, amount, cause, orphanageName);
        } else {
            submitDonationToServer(cause, amount, location, name, contact, orphanageName);
        }
    }

    private void redirectToPayment(String phoneNumber, double amount, String cause, String orphanageName) {
        // Create UPI payment intent
        String upiId = phoneNumber + "@upi"; // Assuming phone number is UPI ID
        String note = "Donation for " + cause + " - " + orphanageName;

        Uri uri = Uri.parse("upi://pay?pa=" + upiId +
                "&pn=" + orphanageName +
                "&am=" + amount +
                "&tn=" + note +
                "&cu=INR");

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);

        // Check if there's an app to handle the intent
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 101);
        } else {
            // Fallback: Show phone number and ask user to manually make payment
            Toast.makeText(this, "Please make payment to: " + phoneNumber, Toast.LENGTH_LONG).show();
            // You can also copy to clipboard
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText("Phone Number", phoneNumber);
            clipboard.setPrimaryClip(clip);

            Toast.makeText(this, "Phone number copied to clipboard", Toast.LENGTH_SHORT).show();

            // Proceed with donation submission
            submitDonationToServer(cause, amount,
                    spinnerLocation.getSelectedItem().toString(),
                    editName.getText().toString().trim(),
                    editContact.getText().toString().trim(),
                    orphanageName);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101) {
            if (resultCode == RESULT_OK) {
                // Payment successful
                submitDonationToServer(
                        spinnerCause.getSelectedItem().toString(),
                        Double.parseDouble(editCustomAmount.getText().toString()),
                        spinnerLocation.getSelectedItem().toString(),
                        editName.getText().toString().trim(),
                        editContact.getText().toString().trim(),
                        spinnerOrphanage.getSelectedItem().toString()
                );
            } else {
                Toast.makeText(this, "Payment cancelled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void submitDonationToServer(String cause, double amount, String location,
                                        String name, String contact, String orphanageName) {
        progressDialog.show();
        btnSubmit.setEnabled(false);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int userId = prefs.getInt("user_id", 0);

        MonetaryDonationRequest request = new MonetaryDonationRequest(
                cause, amount, name, contact, orphanageName, location, userId
        );

        Call<DonationResponse> call = apiService.sendMonetaryDonation(request);
        call.enqueue(new Callback<DonationResponse>() {
            @Override
            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
                progressDialog.dismiss();
                btnSubmit.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    DonationResponse donationResponse = response.body();
                    if (donationResponse.isSuccess()) {
                        showSuccess(donationResponse.getMessage());
                    } else {
                        showError(donationResponse.getMessage());
                    }
                } else {
                    showError("Server error. Please try again.");
                }
            }

            @Override
            public void onFailure(Call<DonationResponse> call, Throwable t) {
                progressDialog.dismiss();
                btnSubmit.setEnabled(true);
                showError("Network error: " + t.getMessage());
            }
        });
    }

    private void showSuccess(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        clearForm();
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void clearForm() {
        spinnerCause.setSelection(0);
        spinnerLocation.setSelection(0);
        spinnerOrphanage.setSelection(0);
        editCustomAmount.setText("");
        editName.setText("");
        editContact.setText("");
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Highlight the Donate button when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_donate);
        }
    }
}