package com.SIMATS.hope;

public class DonorInfo_Volunteer {
    private String full_name;
    private String email;
    private String phone;
    private String username;
    private int user_id;

    public String getFullName() { return full_name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getUsername() { return username; }
    public int getUserId() { return user_id; }
}
