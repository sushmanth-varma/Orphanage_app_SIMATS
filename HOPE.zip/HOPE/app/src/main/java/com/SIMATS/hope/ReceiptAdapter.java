//package com.SIMATS.hope;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//
//public class ReceiptAdapter extends RecyclerView.Adapter<ReceiptAdapter.ReceiptViewHolder> {
//
//    private Context context;
//    private List<ReceiptModel> receiptList;
//
//    public ReceiptAdapter(Context context, List<ReceiptModel> receiptList) {
//        this.context = context;
//        this.receiptList = receiptList;
//    }
//
//    public void updateList(List<ReceiptModel> newList) {
//        this.receiptList.clear();
//        this.receiptList.addAll(newList);
//        notifyDataSetChanged();
//    }
//
//    @NonNull
//    @Override
//    public ReceiptViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_receipt, parent, false);
//        return new ReceiptViewHolder(view);
//    }
// @Override
//    public void onBindViewHolder(@NonNull ReceiptViewHolder holder, int position) {
//        ReceiptModel receipt = receiptList.get(position);
//
//        holder.tvDonationType.setText(receipt.getDonationType());
//        holder.tvStatus.setText("Completed");
//        holder.tvCause.setText("Cause: " + receipt.getCause());
//
//        // Show either amount or item
//        if (receipt.getItemDescription() != null && !receipt.getItemDescription().equals("0")) {
//            holder.tvAmountOrItem.setText("Item: " + receipt.getItemDescription() +
//                    " (Qty: " + receipt.getQuantity() + ")");
//        } else {
//            holder.tvAmountOrItem.setText("Amount: ₹" + receipt.getAmountDonated());
//        }
//
//        holder.tvDonorInfo.setText("Purpose: " + receipt.getPurpose());
//        holder.tvVolunteerInfo.setText("Volunteer: " +
//                (receipt.getVolunteerName() != null ? receipt.getVolunteerName() : "N/A"));
//        holder.tvDate.setText("Collected: " + receipt.getCollectedAt());
//    }
//
//
//
//    @Override
//    public int getItemCount() {
//        return receiptList.size();
//    }
//
//    public static class ReceiptViewHolder extends RecyclerView.ViewHolder {
//        TextView tvDonationType, tvStatus, tvCause, tvAmountOrItem,
//                tvDonorInfo, tvOrphanage, tvLocation, tvVolunteerInfo, tvDate;
//        Button btnViewProof, btnDownloadPDF;
//
//        public ReceiptViewHolder(@NonNull View itemView) {
//            super(itemView);
//            tvDonationType = itemView.findViewById(R.id.tvDonationType);
//            tvStatus = itemView.findViewById(R.id.tvStatus);
//            tvCause = itemView.findViewById(R.id.tvCause);
//            tvAmountOrItem = itemView.findViewById(R.id.tvAmountOrItem);
//            tvDonorInfo = itemView.findViewById(R.id.tvDonorInfo);
//            tvOrphanage = itemView.findViewById(R.id.tvOrphanage);
//            tvLocation = itemView.findViewById(R.id.tvLocation);
//            tvVolunteerInfo = itemView.findViewById(R.id.tvVolunteerInfo);
//            tvDate = itemView.findViewById(R.id.tvDate);
//            btnViewProof = itemView.findViewById(R.id.btnViewProof);
//            btnDownloadPDF = itemView.findViewById(R.id.btnDownloadPDF);
//        }
//
//
//    }
//
//}
package com.SIMATS.hope;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReceiptAdapter extends RecyclerView.Adapter<ReceiptAdapter.ReceiptViewHolder> {

    private Context context;
    private List<ReceiptModel> receiptList;

    public ReceiptAdapter(Context context, List<ReceiptModel> receiptList) {
        this.context = context;
        this.receiptList = receiptList;
    }

    public void updateList(List<ReceiptModel> newList) {
        this.receiptList.clear();
        this.receiptList.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ReceiptViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_receipt, parent, false);
        return new ReceiptViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReceiptViewHolder holder, int position) {
        ReceiptModel receipt = receiptList.get(position);

        holder.tvDonationType.setText(receipt.getDonationType());
        holder.tvStatus.setText("Completed");
        holder.tvCause.setText("Cause: " + receipt.getCause());

        // Show either amount or item
        if (receipt.getItemDescription() != null && !receipt.getItemDescription().equals("0")) {
            holder.tvAmountOrItem.setText("Item: " + receipt.getItemDescription() +
                    " (Qty: " + receipt.getQuantity() + ")");
        } else {
            holder.tvAmountOrItem.setText("Amount: ₹" + receipt.getAmountDonated());
        }

        holder.tvDonorInfo.setText("Purpose: " + receipt.getPurpose());
        holder.tvVolunteerInfo.setText("Volunteer: " +
                (receipt.getVolunteerName() != null ? receipt.getVolunteerName() : "N/A"));
        holder.tvDate.setText("Collected: " + receipt.getCollectedAt());

        // ✅ Download PDF button
        holder.btnDownloadPDF.setOnClickListener(v -> {
            String pdfUrl = "https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/generate_receipt.php?receipt_id="
                    + receipt.getId();

            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(pdfUrl));
            request.setTitle("Donation Receipt");
            request.setDescription("Downloading receipt...");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    "donation_receipt_" + receipt.getId() + ".pdf");

            DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            if (downloadManager != null) {
                downloadManager.enqueue(request);
                Toast.makeText(context, "Downloading receipt...", Toast.LENGTH_SHORT).show();
            }
        });

        // ✅ View Proof button
        holder.btnViewProof.setOnClickListener(v -> {
            if (receipt.getProofUrl() != null && !receipt.getProofUrl().isEmpty()) {
                Uri proofUri = Uri.parse(receipt.getProofUrl());
                context.startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, proofUri));
            } else {
                Toast.makeText(context, "No proof available", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return receiptList.size();
    }

    public static class ReceiptViewHolder extends RecyclerView.ViewHolder {
        TextView tvDonationType, tvStatus, tvCause, tvAmountOrItem,
                tvDonorInfo, tvOrphanage, tvLocation, tvVolunteerInfo, tvDate;
        Button btnViewProof, btnDownloadPDF;

        public ReceiptViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDonationType = itemView.findViewById(R.id.tvDonationType);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvCause = itemView.findViewById(R.id.tvCause);
            tvAmountOrItem = itemView.findViewById(R.id.tvAmountOrItem);
            tvDonorInfo = itemView.findViewById(R.id.tvDonorInfo);
            tvOrphanage = itemView.findViewById(R.id.tvOrphanage);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvVolunteerInfo = itemView.findViewById(R.id.tvVolunteerInfo);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnViewProof = itemView.findViewById(R.id.btnViewProof);
            btnDownloadPDF = itemView.findViewById(R.id.btnDownloadPDF);
        }
    }
}
