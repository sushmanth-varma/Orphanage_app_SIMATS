package com.SIMATS.hope;

public class ProfileUpdateResponse {
    private String status;
    private String message;
    private ProfileData data;

    // Getters and setters
    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public ProfileData getData() {
        return data;
    }

    public static class ProfileData {
        private String name;
        private String profile_photo;
        private String profile_photo_url;

        // Getters
        public String getName() {
            return name;
        }

        public String getProfilePhoto() {
            return profile_photo;
        }

        public String getProfilePhotoUrl() {
            return profile_photo_url;
        }
    }
}