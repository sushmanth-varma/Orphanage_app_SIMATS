package com.SIMATS.hope;

import java.util.List;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class CityResponse {
    @SerializedName("status")
    private String status;

    @SerializedName("cities")
    private List<String> cities;

    @SerializedName("message")
    private String message;

    public String getStatus() {
        return status;
    }

    public List<String> getCities() {
        return cities;
    }

    public String getMessage() {
        return message;
    }
}
