package com.SIMATS.hope;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import java.util.List;

public class ReportAdapter_User extends RecyclerView.Adapter<ReportAdapter_User.ViewHolder> {
    private Context context;
    private List<ReportModel> reportList;
    private static final String BASE_URL = "https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/";

    public ReportAdapter_User(Context context, List<ReportModel> reportList) {
        this.context = context;
        this.reportList = reportList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_report_user, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReportModel report = reportList.get(position);

        // Set text fields
        holder.tvReportType.setText("Type: " + report.getType());
        holder.tvReportName.setText("Name: " + report.getName());
        holder.tvReportAge.setText("Age: " + report.getAge());
        holder.tvReportLocation.setText("Location: " + report.getGeneralLocation());
        holder.tvReportDetails.setText("Details: " + report.getDetails());
        holder.tvReportStatus.setText("Status: " + report.getStatus());
        holder.tvCreatedAt.setText("Submitted on: " + report.getCreatedAt());

        // Load image
        if (report.getPhotoPath() != null && !report.getPhotoPath().isEmpty()) {
            String imageUrl;

            // Check if path already contains base URL
            if (report.getPhotoPath().startsWith("http")) {
                imageUrl = report.getPhotoPath();
            } else {
                // Handle relative paths
                imageUrl = BASE_URL + report.getPhotoPath();

                // Ensure there are no double slashes
                imageUrl = imageUrl.replace("//uploads/", "/uploads/");
            }

            Log.d("IMAGE_LOAD", "Loading image from: " + imageUrl);

            Glide.with(context)
                    .load(imageUrl)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_error)
                    .into(holder.imgReportPhoto);
        } else {
            holder.imgReportPhoto.setImageResource(R.drawable.ic_error);
            Log.d("IMAGE_LOAD", "No photo available for this report");
        }
    }

    @Override
    public int getItemCount() {
        return reportList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgReportPhoto;
        TextView tvReportType, tvReportName, tvReportAge, tvReportLocation,
                tvReportDetails, tvReportStatus, tvCreatedAt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgReportPhoto = itemView.findViewById(R.id.imgReportPhoto);
            tvReportType = itemView.findViewById(R.id.tvReportType);
            tvReportName = itemView.findViewById(R.id.tvReportName);
            tvReportAge = itemView.findViewById(R.id.tvReportAge);
            tvReportLocation = itemView.findViewById(R.id.tvReportLocation);
            tvReportDetails = itemView.findViewById(R.id.tvReportDetails);
            tvReportStatus = itemView.findViewById(R.id.tvReportStatus);
            tvCreatedAt = itemView.findViewById(R.id.tvCreatedAt);
        }
    }
}