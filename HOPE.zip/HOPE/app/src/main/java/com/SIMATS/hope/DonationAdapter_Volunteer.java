//package com.SIMATS.hope;
//
//import android.content.Context;
//import android.content.Intent;
//import android.graphics.Paint;
//import android.net.Uri;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.TextView;
//import androidx.annotation.NonNull;
//import androidx.core.content.ContextCompat;
//import androidx.recyclerview.widget.RecyclerView;
//import java.util.ArrayList;
//
//public class DonationAdapter_Volunteer extends RecyclerView.Adapter<DonationAdapter_Volunteer.ViewHolder> {
//
//    private Context context;
//    private ArrayList<Donation_get_volunteer> donations;
//    private OnItemClickListener listener;
//    private OnUploadClickListener uploadClickListener;
//
//    public interface OnItemClickListener {
//        void onUpdateClick(int position);
//    }
//
//    public interface OnUploadClickListener {
//        void onUploadClick(int donationId);
//    }
//
//    public void setOnItemClickListener(OnItemClickListener listener) {
//        this.listener = listener;
//    }
//
//    public void setOnUploadClickListener(OnUploadClickListener listener) {
//        this.uploadClickListener = listener;
//    }
//
//    public DonationAdapter_Volunteer(Context context, ArrayList<Donation_get_volunteer> donations) {
//        this.context = context;
//        this.donations = donations;
//    }
//
//    @NonNull
//    @Override
//    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_donation_volunteer, parent, false);
//        return new ViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
//        Donation_get_volunteer donation = donations.get(position);
//
//        holder.tvDonationType.setText(donation.getDonationType());
//        holder.tvStatus.setText(donation.getStatus());
//        holder.tvCause.setText("For: " + donation.getCause());
//
//        if ("Material".equalsIgnoreCase(donation.getDonationType())) {
//            holder.tvDetails.setText(donation.getItemDescription() + " (Qty: " + donation.getQuantity() + ")");
//        } else {
//            holder.tvDetails.setText("Amount: ₹" + donation.getAmount());
//        }
//
//        // ✅ Donor info with phone click-to-call
//        String phone = donation.getDonorPhone();
//        if (!phone.equals("Not available")) {
//            holder.tvDonorInfo.setText(donation.getDonorNameWithPhone());
//            holder.tvDonorInfo.setTextColor(ContextCompat.getColor(context, R.color.primaryColor));
//            holder.tvDonorInfo.setPaintFlags(holder.tvDonorInfo.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
//            holder.tvDonorInfo.setOnClickListener(v -> {
//                Intent intent = new Intent(Intent.ACTION_DIAL);
//                intent.setData(Uri.parse("tel:" + phone));
//                context.startActivity(intent);
//            });
//        } else {
//            holder.tvDonorInfo.setText("Donor: Not available");
//            holder.tvDonorInfo.setTextColor(ContextCompat.getColor(context, R.color.textSecondary));
//            holder.tvDonorInfo.setPaintFlags(0);
//            holder.tvDonorInfo.setOnClickListener(null);
//        }
//
//        holder.tvOrphanage.setText(donation.getOrphanageName());
//        holder.tvLocation.setText(donation.getLocation());
//        holder.tvVolunteerInfo.setText("Volunteer: " + (donation.getVolunteerUsername() != null ? donation.getVolunteerUsername() : "assigned"));
//        holder.tvDate.setText("Assigned on: " + (donation.getDates() != null ? donation.getDates().getCreatedAt() : "N/A"));
//
//        // Update button text based on status
//        if ("Completed".equalsIgnoreCase(donation.getStatus())) {
//            holder.btnAction.setText("Mark as Assigned");
//            holder.btnAction.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.colorAccent));
//        } else {
//            holder.btnAction.setText("Mark as Completed");
//            holder.btnAction.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.primaryColor));
//        }
//
//        holder.btnAction.setOnClickListener(v -> {
//            if (listener != null) listener.onUpdateClick(position);
//        });
//
//        // Upload Receipt button click listener
//        holder.btnGoToUpload.setOnClickListener(v -> {
//            if (uploadClickListener != null) {
//                uploadClickListener.onUploadClick(donation.getId());
//            }
//        });
//    }
//
//    @Override
//    public int getItemCount() {
//        return donations.size();
//    }
//
//    public static class ViewHolder extends RecyclerView.ViewHolder {
//        TextView tvDonationType, tvStatus, tvCause, tvDetails, tvDonorInfo, tvOrphanage, tvLocation, tvVolunteerInfo, tvDate;
//        Button btnAction, btnGoToUpload;
//
//        public ViewHolder(@NonNull View itemView) {
//            super(itemView);
//            tvDonationType = itemView.findViewById(R.id.tvDonationType);
//            tvStatus = itemView.findViewById(R.id.tvStatus);
//            tvCause = itemView.findViewById(R.id.tvCause);
//            tvDetails = itemView.findViewById(R.id.tvDetails);
//            tvDonorInfo = itemView.findViewById(R.id.tvDonorInfo);
//            tvOrphanage = itemView.findViewById(R.id.tvOrphanage);
//            tvLocation = itemView.findViewById(R.id.tvLocation);
//            tvVolunteerInfo = itemView.findViewById(R.id.tvVolunteerInfo);
//            tvDate = itemView.findViewById(R.id.tvDate);
//            btnAction = itemView.findViewById(R.id.btnAction);
//            btnGoToUpload = itemView.findViewById(R.id.btnGoToUpload);
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DonationAdapter_Volunteer extends RecyclerView.Adapter<DonationAdapter_Volunteer.ViewHolder> {

    private Context context;
    private ArrayList<Donation_get_volunteer> donations;
    private OnItemClickListener listener;
    private OnUploadClickListener uploadClickListener;

    public interface OnItemClickListener {
        void onUpdateClick(int position);
    }

    public interface OnUploadClickListener {
        void onUploadClick(int donationId);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setOnUploadClickListener(OnUploadClickListener listener) {
        this.uploadClickListener = listener;
    }

    public DonationAdapter_Volunteer(Context context, ArrayList<Donation_get_volunteer> donations) {
        this.context = context;
        this.donations = donations;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_donation_volunteer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Donation_get_volunteer donation = donations.get(position);

        holder.tvDonationType.setText(donation.getDonationType());
        holder.tvStatus.setText(donation.getStatus());
        holder.tvCause.setText("For: " + donation.getCause());

        if ("Material".equalsIgnoreCase(donation.getDonationType())) {
            holder.tvDetails.setText(donation.getItemDescription() + " (Qty: " + donation.getQuantity() + ")");
        } else {
            holder.tvDetails.setText("Amount: ₹" + donation.getAmount());
        }

        // ✅ Donor info with phone click-to-call
        String phone = donation.getDonorPhone();
        if (!phone.equals("Not available")) {
            holder.tvDonorInfo.setText(donation.getDonorNameWithPhone());
            holder.tvDonorInfo.setTextColor(ContextCompat.getColor(context, R.color.primaryColor));
            holder.tvDonorInfo.setPaintFlags(holder.tvDonorInfo.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
            holder.tvDonorInfo.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + phone));
                context.startActivity(intent);
            });
        } else {
            holder.tvDonorInfo.setText("Donor: Not available");
            holder.tvDonorInfo.setTextColor(ContextCompat.getColor(context, R.color.textSecondary));
            holder.tvDonorInfo.setPaintFlags(0);
            holder.tvDonorInfo.setOnClickListener(null);
        }

        holder.tvOrphanage.setText(donation.getOrphanageName());
        holder.tvLocation.setText(donation.getLocation());
        holder.tvVolunteerInfo.setText("Volunteer: " + (donation.getVolunteerUsername() != null ? donation.getVolunteerUsername() : "assigned"));
        holder.tvDate.setText("Assigned on: " + (donation.getDates() != null ? donation.getDates().getCreatedAt() : "N/A"));

        // Update button text based on status
        if ("Completed".equalsIgnoreCase(donation.getStatus())) {
            holder.btnAction.setText("Mark as Assigned");
            holder.btnAction.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.colorAccent));
        } else {
            holder.btnAction.setText("Mark as Completed");
            holder.btnAction.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.primaryColor));
        }

        holder.btnAction.setOnClickListener(v -> {
            if (listener != null) listener.onUpdateClick(position);
        });

        // Upload Receipt button click listener
        holder.btnGoToUpload.setOnClickListener(v -> {
            if (uploadClickListener != null) {
                uploadClickListener.onUploadClick(donation.getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return donations.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDonationType, tvStatus, tvCause, tvDetails, tvDonorInfo, tvOrphanage, tvLocation, tvVolunteerInfo, tvDate;
        Button btnAction, btnGoToUpload;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDonationType = itemView.findViewById(R.id.tvDonationType);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvCause = itemView.findViewById(R.id.tvCause);
            tvDetails = itemView.findViewById(R.id.tvDetails);
            tvDonorInfo = itemView.findViewById(R.id.tvDonorInfo);
            tvOrphanage = itemView.findViewById(R.id.tvOrphanage);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvVolunteerInfo = itemView.findViewById(R.id.tvVolunteerInfo);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnAction = itemView.findViewById(R.id.btnAction);
            btnGoToUpload = itemView.findViewById(R.id.btnGoToUpload);
        }
    }
}