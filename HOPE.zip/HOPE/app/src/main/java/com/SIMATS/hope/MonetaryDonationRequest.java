package com.SIMATS.hope;
public class MonetaryDonationRequest {
    private String donation_type;
    private String cause;
    private double amount;
    private String full_name;
    private String phone;
    private String orphanage_name;
    private String location;
    private int user_id;

    public MonetaryDonationRequest(String cause, double amount, String full_name,
                                   String phone, String orphanage_name, String location,int user_id) {
        this.donation_type = "Monetary";
        this.cause = cause;
        this.amount = amount;
        this.full_name = full_name;
        this.phone = phone;
        this.orphanage_name = orphanage_name;
        this.location = location;
        this.user_id = user_id; // Set if you have user authentication
    }

    // Getters and Setters
    public String getDonation_type() { return donation_type; }
    public String getCause() { return cause; }
    public double getAmount() { return amount; }
    public String getFull_name() { return full_name; }
    public String getPhone() { return phone; }
    public String getOrphanage_name() { return orphanage_name; }
    public String getLocation() { return location; }
    public int getUser_id() { return user_id; }
}
