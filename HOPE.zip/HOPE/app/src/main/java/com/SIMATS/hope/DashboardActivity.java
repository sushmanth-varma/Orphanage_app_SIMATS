//package com.SIMATS.hope;
////import android.content.Intent;
////import android.os.Bundle;
////import android.view.View;
////import android.widget.Button;
////import android.widget.ImageButton;
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.drawerlayout.widget.DrawerLayout;
////
////public class DashboardActivity extends AppCompatActivity {
////
////    DrawerLayout drawerLayout;
////    ImageButton btnReportChild, btnDonate, btnTrackCase;
////    Button btnLogout;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_dashboard);
////
////        // Initialize Views
////        drawerLayout = findViewById(R.id.drawerLayout);
////        btnReportChild = findViewById(R.id.btnReportChild);
////        btnDonate = findViewById(R.id.btnDonate);
////        btnTrackCase = findViewById(R.id.btnTrackCase);
////        btnLogout = findViewById(R.id.btnLogout);
////
////        // Quick Action Buttons
////        btnReportChild.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                Intent intent = new Intent(DashboardActivity.this, ReportChildActivity.class);
////                startActivity(intent);
////            }
////        });
////
////        btnDonate.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                // For now show message; replace with actual DonateActivity
////                Intent intent = new Intent(DashboardActivity.this, DonateActivity.class);
////                startActivity(intent);
////            }
////        });
////
////        btnTrackCase.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                // For now show message; replace with actual TrackCaseActivity
////                Intent intent = new Intent(DashboardActivity.this, TrackCaseActivity.class);
////                startActivity(intent);
////            }
////        });
////
////        btnLogout.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                finish(); // or implement logout logic
////            }
////        });
////    }
////}
////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.os.Bundle;
////import android.view.View;
////import android.widget.Button;
////import android.widget.ImageButton;
////import android.widget.TextView;
////import android.widget.Toast;
////
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.drawerlayout.widget.DrawerLayout;
////
////public class DashboardActivity extends AppCompatActivity {
////
////    DrawerLayout drawerLayout;
////    ImageButton btnReportChild, btnDonate, btnTrackCase;
////    Button btnLogout;
////
////    TextView tvProfile, tvDashboard, tvReportChild, tvDonate, tvTrackCase, tvResources, tvVolunteer, tvSettings;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_dashboard);
////
////        // Drawer setup
////        drawerLayout = findViewById(R.id.drawerLayout);
////
////        // Quick Action buttons
////        btnReportChild = findViewById(R.id.btnReportChild);
////        btnDonate = findViewById(R.id.btnDonate);
////        btnTrackCase = findViewById(R.id.btnTrackCase);
////
////        // Logout button
////        btnLogout = findViewById(R.id.btnLogout);
////
////        // Drawer menu items
////        tvProfile = findViewById(R.id.navDrawer).findViewWithTag("Profile");
////        tvDashboard = findViewById(R.id.navDrawer).findViewWithTag("Dashboard");
////        tvReportChild = findViewById(R.id.navDrawer).findViewWithTag("Report Child");
////        tvDonate = findViewById(R.id.navDrawer).findViewWithTag("Donate");
////        tvTrackCase = findViewById(R.id.navDrawer).findViewWithTag("Track Case");
////        tvResources = findViewById(R.id.navDrawer).findViewWithTag("Resources");
////        tvVolunteer = findViewById(R.id.navDrawer).findViewWithTag("Volunteer");
////        tvSettings = findViewById(R.id.navDrawer).findViewWithTag("Settings");
////
////        // Set listeners for quick action buttons
////        btnReportChild.setOnClickListener(v -> {
////            startActivity(new Intent(this, ReportChildActivity.class));
////        });
////
////        btnDonate.setOnClickListener(v -> {
////            startActivity(new Intent(this, DonateActivity.class));
////        });
////
////        btnTrackCase.setOnClickListener(v -> {
////            startActivity(new Intent(this, TrackCaseActivity.class));
////        });
////
////        // Set listeners for drawer items
////        setDrawerClick(tvProfile, "Profile");
////        setDrawerClick(tvDashboard, "Dashboard");
////        setDrawerClick(tvReportChild, "Report Child", ReportChildActivity.class);
////        setDrawerClick(tvDonate, "Donate", DonateActivity.class);
////        setDrawerClick(tvTrackCase, "Track Case", TrackCaseActivity.class);
////        setDrawerClick(tvResources, "Resources");
////        setDrawerClick(tvVolunteer, "Volunteer");
////        setDrawerClick(tvSettings, "Settings");
////
////        btnLogout.setOnClickListener(v -> {
////            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
////            finish(); // Replace with logout logic
////        });
////    }
////
////    // Method to show a toast on click
////    private void setDrawerClick(TextView textView, String label) {
////        if (textView != null) {
////            textView.setOnClickListener(v -> Toast.makeText(this, label + " clicked", Toast.LENGTH_SHORT).show());
////        }
////    }
////
////    // Overloaded to open new activity
////    private void setDrawerClick(TextView textView, String label, Class<?> activityClass) {
////        if (textView != null) {
////            textView.setOnClickListener(v -> startActivity(new Intent(this, activityClass)));
////        }
////    }
////}
////    package com.SIMATS.hope;
////import android.os.Bundle;
////import android.view.MenuItem;
////import android.view.View;
////import android.widget.LinearLayout;
////import android.widget.TextView;
////import android.widget.Toast;
////
////import androidx.appcompat.app.ActionBarDrawerToggle;
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.drawerlayout.widget.DrawerLayout;
////
////public class DashboardActivity extends AppCompatActivity {
////
////    DrawerLayout drawerLayout;
////    ActionBarDrawerToggle toggle;
////
////    LinearLayout layoutReport, layoutDonate, layoutTrackCase;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_dashboard);
////
////        drawerLayout = findViewById(R.id.drawerLayout);
////        layoutReport = findViewById(R.id.layoutReport);
////        layoutDonate = findViewById(R.id.layoutDonate);
////        layoutTrackCase = findViewById(R.id.layoutTrackCase);
////
////        // Set up drawer toggle
////        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
////        drawerLayout.addDrawerListener(toggle);
////        toggle.syncState();
////        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
////
////        layoutReport.setOnClickListener(v -> Toast.makeText(this, "Report Clicked", Toast.LENGTH_SHORT).show());
////        layoutDonate.setOnClickListener(v -> Toast.makeText(this, "Donate Clicked", Toast.LENGTH_SHORT).show());
////        layoutTrackCase.setOnClickListener(v -> Toast.makeText(this, "Track Case Clicked", Toast.LENGTH_SHORT).show());
////
////        // Navigation drawer item click example
////        TextView navProfile = findViewById(R.id.navProfile);
////        navProfile.setOnClickListener(v -> Toast.makeText(this, "Profile Clicked", Toast.LENGTH_SHORT).show());
////    }
////
////    @Override
////    public boolean onOptionsItemSelected(MenuItem item) {
////        return toggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
////    }
////}
////
////
//
////import android.content.Intent;
////import android.os.Bundle;
////import android.view.MenuItem;
////import android.widget.LinearLayout;
////import android.widget.TextView;
////import android.widget.Toast;
////
////import androidx.appcompat.app.ActionBarDrawerToggle;
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.appcompat.widget.Toolbar;
////import androidx.drawerlayout.widget.DrawerLayout;
////
////public class DashboardActivity extends AppCompatActivity {
////
////    DrawerLayout drawerLayout;
////    ActionBarDrawerToggle toggle;
////    Toolbar toolbar;
////
////    LinearLayout layoutReport, layoutDonate, layoutTrackCase;
////
////    TextView navProfile, navDashboard, navReport, navDonate, navTrack, navResources, navVolunteer, navSettings;
////    TextView btnLogout;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_dashboard);
////
////        // 1. Setup Toolbar
////        toolbar = findViewById(R.id.toolbar);
////        setSupportActionBar(toolbar);
////
////        // 2. Setup DrawerLayout + Toggle (Hamburger)
////        drawerLayout = findViewById(R.id.drawerLayout);
////        toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
////        drawerLayout.addDrawerListener(toggle);
////        toggle.syncState();
////
////        // 3. Quick Actions
////        layoutReport = findViewById(R.id.layoutReport);
////        layoutDonate = findViewById(R.id.layoutDonate);
////        layoutTrackCase = findViewById(R.id.layoutTrackCase);
////
////        layoutReport.setOnClickListener(v -> startActivity(new Intent(this, ReportChildActivity.class)));
////        layoutDonate.setOnClickListener(v -> Toast.makeText(this, "Donate Clicked", Toast.LENGTH_SHORT).show());
////        layoutTrackCase.setOnClickListener(v -> Toast.makeText(this, "Track Case Clicked", Toast.LENGTH_SHORT).show());
////
////        // 4. Navigation Drawer Items
////        navProfile = findViewById(R.id.navProfile);
////        navDashboard = findViewById(R.id.navDashboard);
////        navReport = findViewById(R.id.navReport);
////        navDonate = findViewById(R.id.navDonate);
////        navTrack = findViewById(R.id.navTrack);
////        //navResources = findViewById(R.id.navResources);
////        //navVolunteer = findViewById(R.id.navVolunteer);
////        //navSettings = findViewById(R.id.navSettings);
////        //btnLogout = findViewById(R.id.btnLogout);
////
////        setNavClick(navProfile, "Profile");
////        setNavClick(navDashboard, "Dashboard");
////        setNavClick(navReport, "Report Child", ReportChildActivity.class);
////        setNavClick(navDonate, "Donate");
////        setNavClick(navTrack, "Track Case");
////        setNavClick(navResources, "Resources");
////        setNavClick(navVolunteer, "Volunteer");
////        setNavClick(navSettings, "Settings");
////
////        btnLogout.setOnClickListener(v -> {
////            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
////            finish();
////        });
////    }
////
////    private void setNavClick(TextView tv, String label) {
////        if (tv != null) {
////            tv.setOnClickListener(v -> Toast.makeText(this, label + " Clicked", Toast.LENGTH_SHORT).show());
////        }
////    }
////
////    private void setNavClick(TextView tv, String label, Class<?> activityClass) {
////        if (tv != null) {
////            tv.setOnClickListener(v -> startActivity(new Intent(this, activityClass)));
////        }
////    }
////
////    @Override
////    public boolean onOptionsItemSelected(MenuItem item) {
////        return toggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
////    }
////}
//
////import android.content.Intent;
////import android.os.Bundle;
////import android.view.View;
////import android.widget.LinearLayout;
////import android.widget.TextView;
////
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.drawerlayout.widget.DrawerLayout;
////import androidx.appcompat.widget.Toolbar;
////
////public class DashboardActivity extends AppCompatActivity {
////
////    DrawerLayout drawerLayout;
////    LinearLayout layoutReport, layoutDonate, layoutTrackCase;
////    TextView navProfile, navDashboard, navReport, navDonate, navTrack;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_dashboard);
////
////        // Initialize toolbar
////        Toolbar toolbar = findViewById(R.id.toolbar);
////        setSupportActionBar(toolbar);
////
////        // Initialize drawer layout
////        drawerLayout = findViewById(R.id.drawerLayout);
////
////        // Navigation menu items
////        navProfile = findViewById(R.id.navProfile);
////        navDashboard = findViewById(R.id.navDashboard);
////        navReport = findViewById(R.id.navReport);
////        navDonate = findViewById(R.id.navDonate);
////        navTrack = findViewById(R.id.navTrack);
////
////        // Handle clicks on drawer navigation items
////        navProfile.setOnClickListener(v -> {
////            // Navigate to ProfileActivity
////            startActivity(new Intent(this, EditProfileActivity.class));
////        });
////
////        navDashboard.setOnClickListener(v -> {
////            // Already on Dashboard
////            drawerLayout.closeDrawers();
////        });
////
////        navReport.setOnClickListener(v -> {
////            startActivity(new Intent(this, ReportChildActivity.class));
////        });
////
////        navDonate.setOnClickListener(v -> {
////            startActivity(new Intent(this, DonateActivity.class));
////        });
////
////        navTrack.setOnClickListener(v -> {
////            startActivity(new Intent(this, TrackReportsActivity.class));
////        });
////
////        // Dashboard grid buttons
////        layoutReport = findViewById(R.id.layoutReport);
////        layoutDonate = findViewById(R.id.layoutDonate);
////        layoutTrackCase = findViewById(R.id.layoutTrackCase);
////
////        layoutReport.setOnClickListener(v -> {
////            startActivity(new Intent(this,ReportChildActivity.class));
////        });
////
////        layoutDonate.setOnClickListener(v -> {
////            startActivity(new Intent(this, DonateActivity.class));
////        });
////
////        layoutTrackCase.setOnClickListener(v -> {
////            startActivity(new Intent(this, TrackReportsActivity.class));
////
////        });
////        LinearLayout layoutSettings = findViewById(R.id.layoutSettings);
////        layoutSettings.setOnClickListener(v -> {
////            startActivity(new Intent(this, SettingsActivity.class));
////        });
////
////
////    }
////}
////    import android.content.Intent;
////    import android.os.Bundle;
////    import android.widget.Button;
////    import android.widget.LinearLayout;
////    import android.widget.TextView;
////
////    import androidx.appcompat.app.AppCompatActivity;
////    import androidx.appcompat.widget.Toolbar;
////    import androidx.drawerlayout.widget.DrawerLayout;
////
////    public class DashboardActivity extends AppCompatActivity {
////
////        DrawerLayout drawerLayout;
////        LinearLayout layoutReport, layoutDonate, layoutTrackCase, layoutSettings, layoutVolunteer;
////        TextView navProfile, navDashboard, navReport, navDonate, navTrack;
////
////        @Override
////        protected void onCreate(Bundle savedInstanceState) {
////            super.onCreate(savedInstanceState);
////            setContentView(R.layout.activity_dashboard);
////
////            // Toolbar setup
////            Toolbar toolbar = findViewById(R.id.toolbar);
////            setSupportActionBar(toolbar);
////
////            // Drawer layout
////            drawerLayout = findViewById(R.id.drawerLayout);
////
////            // Initialize drawer menu TextViews
////            navProfile = findViewById(R.id.navProfile);
////            navDashboard = findViewById(R.id.navDashboard);
////            navReport = findViewById(R.id.navReport);
////            navDonate = findViewById(R.id.navDonate);
////            navTrack = findViewById(R.id.navTrack);
////
////            // Drawer item clicks
////            navProfile.setOnClickListener(v -> startActivity(new Intent(this, EditProfileActivity.class)));
////            navDashboard.setOnClickListener(v -> drawerLayout.closeDrawers()); // Close drawer
////            navReport.setOnClickListener(v -> startActivity(new Intent(this, ReportChildActivity.class)));
////            navDonate.setOnClickListener(v -> startActivity(new Intent(this, DonateActivity.class)));
////
////            // Dashboard grid actions
////            layoutReport = findViewById(R.id.layoutReport);
////            layoutDonate = findViewById(R.id.layoutDonate);
////            layoutTrackCase = findViewById(R.id.layoutTrackCase);
////            layoutSettings = findViewById(R.id.layoutSettings);
////            layoutVolunteer = findViewById(R.id.layoutVolunteer);
////
////            layoutReport.setOnClickListener(v -> startActivity(new Intent(this, ReportChildActivity.class)));
////            layoutDonate.setOnClickListener(v -> startActivity(new Intent(this, DonateActivity.class)));
////            layoutSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
////            layoutVolunteer.setOnClickListener(v -> startActivity(new Intent(this, VolunteerActivity.class)));
////            layoutTrackCase.setOnClickListener(v -> startActivity(new Intent(this, UserTrackCaseActivity.class)));
////
////        }
////    }
////    import android.content.Intent;
////    import android.os.Bundle;
////    import android.os.Handler;
////    import android.view.MenuItem;
////    import android.view.View;
////    import android.view.animation.Animation;
////    import android.view.animation.AnimationUtils;
////
////    import androidx.annotation.NonNull;
////    import androidx.appcompat.app.AppCompatActivity;
////    import androidx.cardview.widget.CardView;
////    import androidx.core.view.GravityCompat;
////    import androidx.drawerlayout.widget.DrawerLayout;
////
////    import com.google.android.material.appbar.MaterialToolbar;
////    import com.google.android.material.navigation.NavigationView;
////
////    public class DashboardActivity extends AppCompatActivity {
////
////        private DrawerLayout drawerLayout;
////        private MaterialToolbar toolbar;
////        private NavigationView navigationView;
////
////        @Override
////        protected void onCreate(Bundle savedInstanceState) {
////            super.onCreate(savedInstanceState);
////            setContentView(R.layout.activity_dashboard);
////
////            // Initialize views
////            drawerLayout = findViewById(R.id.drawerLayout);
////            toolbar = findViewById(R.id.toolbar);
////            navigationView = findViewById(R.id.navigationView);
////
////            // Setup toolbar
////            setSupportActionBar(toolbar);
////            toolbar.setNavigationOnClickListener(view ->
////                    drawerLayout.openDrawer(GravityCompat.START));
////
////            // Setup drawer navigation
////            navigationView.setNavigationItemSelectedListener(item -> {
////                handleDrawerItemClick(item.getItemId());
////                return true;
////            });
////
////            // Initialize dashboard cards
////            CardView reportCard = findViewById(R.id.layoutReport);
////            CardView donateCard = findViewById(R.id.layoutDonate);
////            CardView trackCaseCard = findViewById(R.id.layoutTrackCase);
////            CardView settingsCard = findViewById(R.id.layoutSettings);
////            CardView volunteerCard = findViewById(R.id.layoutVolunteer);
////
////            // Set click listeners with animations
////            setCardClickListener(reportCard, ReportChildActivity.class);
////            setCardClickListener(donateCard, DonateActivity.class);
////            setCardClickListener(trackCaseCard, UserTrackCaseActivity.class);
////            setCardClickListener(settingsCard, SettingsActivity.class);
////            setCardClickListener(volunteerCard, VolunteerActivity.class);
////        }
////
////        private void setCardClickListener(CardView card, Class<?> activityClass) {
////            card.setOnClickListener(view -> {
////                Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_click1);
////                card.startAnimation(anim);
////
////                new Handler().postDelayed(() -> {
////                    startActivity(new Intent(this, activityClass));
////                    overridePendingTransition(R.anim.slide_in_right1, R.anim.slide_out_left1);
////                }, 200);
////            });
////        }
////
////        private void handleDrawerItemClick(int itemId) {
////            drawerLayout.closeDrawer(GravityCompat.START);
////
////            new Handler().postDelayed(() -> {
////                Intent intent = null;
////
////                if (itemId == R.id.navProfile) {
////                    intent = new Intent(this, EditProfileActivity.class);
////                } else if (itemId == R.id.navDashboard) {
////                    return; // already on dashboard
////                } else if (itemId == R.id.navReport) {
////                    intent = new Intent(this, ReportChildActivity.class);
////                } else if (itemId == R.id.navDonate) {
////                    intent = new Intent(this, DonateActivity.class);
////                } else if (itemId == R.id.navTrack) {
////                    intent = new Intent(this, UserTrackCaseActivity.class);
////                }
////
////                if (intent != null) {
////                    startActivity(intent);
////                    overridePendingTransition(R.anim.slide_in_right1, R.anim.slide_out_left1);
////                }
////            }, 200);
////        }
////
////        @Override
////        public void onBackPressed() {
////            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
////                drawerLayout.closeDrawer(GravityCompat.START);
////            } else {
////                super.onBackPressed();
////            }
////        }
////    }
////
//
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//import android.view.View;
//import android.view.animation.Animation;
//import android.view.animation.AnimationUtils;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.cardview.widget.CardView;
//import androidx.core.view.GravityCompat;
//import androidx.drawerlayout.widget.DrawerLayout;
//
//import com.google.android.material.appbar.MaterialToolbar;
//import com.google.android.material.navigation.NavigationView;
//
//public class DashboardActivity extends AppCompatActivity {
//
//    private DrawerLayout drawerLayout;
//    private MaterialToolbar toolbar;
//    private NavigationView navigationView;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_dashboard);
//
//        // Initialize views
//        drawerLayout = findViewById(R.id.drawerLayout);
//        toolbar = findViewById(R.id.toolbar);
//        navigationView = findViewById(R.id.navigationView);
//
//        // Setup toolbar
//        setSupportActionBar(toolbar);
//        toolbar.setNavigationOnClickListener(view ->
//                drawerLayout.openDrawer(GravityCompat.START));
//
//        // Setup drawer navigation
//        navigationView.setNavigationItemSelectedListener(item -> {
//            int id = item.getItemId();
//
//            // Apply click animation
//            View menuItemView = navigationView.getMenu().findItem(id).getActionView();
//            if (menuItemView != null) {
//                Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_click1);
//                menuItemView.startAnimation(anim);
//            }
//
//            // Handle navigation after animation
//            new Handler().postDelayed(() -> {
//                handleNavigation(id);
//            }, 200);
//
//            drawerLayout.closeDrawer(GravityCompat.START);
//            return true;
//        });
//
//        // Initialize dashboard cards
//        CardView reportCard = findViewById(R.id.layoutReport);
//        CardView donateCard = findViewById(R.id.layoutDonate);
//        CardView trackCaseCard = findViewById(R.id.layoutTrackCase);
//        CardView settingsCard = findViewById(R.id.layoutSettings);
//        CardView volunteerCard = findViewById(R.id.layoutVolunteer);
//        CardView myDonationsCard = findViewById(R.id.layoutMyDonations);
//
//        // Set click listeners with animations
//        setCardClickListener(reportCard, R.id.navReport);
//        setCardClickListener(donateCard, R.id.navDonate);
//        setCardClickListener(trackCaseCard, R.id.navTrack);
//        setCardClickListener(settingsCard, R.id.navSettings);
//        setCardClickListener(volunteerCard, R.id.navVolunteer);
//        setCardClickListener(myDonationsCard, R.id.nav_my_donations);
//    }
//
//    private void setCardClickListener(CardView card, final int menuItemId) {
//        card.setOnClickListener(view -> {
//            Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_click1);
//            card.startAnimation(anim);
//
//            new Handler().postDelayed(() -> {
//                handleNavigation(menuItemId);
//            }, 200);
//        });
//    }
//
//    private void handleNavigation(int itemId) {
//        Intent intent = null;
//
//        if (itemId == R.id.navProfile) {
//            intent = new Intent(this, EditProfileActivity.class);
//        } else if (itemId == R.id.navDashboard) {
//            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
//                drawerLayout.closeDrawer(GravityCompat.START);
//            }
//            return;
//        } else if (itemId == R.id.navReport) {
//            intent = new Intent(this, ReportChildActivity.class);
//        } else if (itemId == R.id.navDonate) {
//            intent = new Intent(this, DonateActivity.class);
//        } else if (itemId == R.id.navTrack) {
//            intent = new Intent(this, UserTrackCaseActivity.class);
//        } else if (itemId == R.id.navSettings) {
//            intent = new Intent(this, SettingsActivity.class);
//        } else if (itemId == R.id.navVolunteer) {
//            intent = new Intent(this, VolunteerRequestActivity.class);
//        } else if (itemId == R.id.nav_my_donations) {
//            intent = new Intent(this, MyDonationsActivity.class);
//        }
//
//        if (intent != null) {
//            startActivity(intent);
//            overridePendingTransition(R.anim.slide_in_right1, R.anim.slide_out_left1);
//        }
//    }
//
//    @Override
//    public void onBackPressed() {
//        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
//            drawerLayout.closeDrawer(GravityCompat.START);
//        } else {
//            super.onBackPressed();
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DashboardActivity extends AppCompatActivity {

    private MaterialToolbar toolbar;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize views
        toolbar = findViewById(R.id.toolbar);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Setup toolbar
        setSupportActionBar(toolbar);

        // Setup bottom navigation
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    // Already on home/dashboard
                    return true;
                } else if (itemId == R.id.nav_donate) {
                    startActivity(new Intent(DashboardActivity.this, DonateActivity.class));
                    return true;
                } else if (itemId == R.id.nav_report) {
                    startActivity(new Intent(DashboardActivity.this, ReportChildActivity.class));
                    return true;
                } else if (itemId == R.id.nav_volunteer) {
                    startActivity(new Intent(DashboardActivity.this, VolunteerRequestActivity.class));
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(DashboardActivity.this, SettingsActivity.class));
                    return true;
                }
                return false;
            }
        });

        // Set home as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        // Initialize dashboard cards
        CardView reportCard = findViewById(R.id.layoutReport);
        CardView donateCard = findViewById(R.id.layoutDonate);
        CardView trackCaseCard = findViewById(R.id.layoutTrackCase);
        CardView settingsCard = findViewById(R.id.layoutSettings);
        CardView volunteerCard = findViewById(R.id.layoutVolunteer);
        CardView myDonationsCard = findViewById(R.id.layoutMyDonations);

        // Set click listeners with animations
        setCardClickListener(reportCard, ReportChildActivity.class);
        setCardClickListener(donateCard, DonateActivity.class);
        setCardClickListener(trackCaseCard, UserTrackCaseActivity.class);
        setCardClickListener(settingsCard, SettingsActivity.class); // Changed to profile
        setCardClickListener(volunteerCard, VolunteerRequestActivity.class);
        setCardClickListener(myDonationsCard, MyDonationsActivity.class);
    }

    private void setCardClickListener(CardView card, final Class<?> activityClass) {
        card.setOnClickListener(view -> {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_click1);
            card.startAnimation(anim);

            new Handler().postDelayed(() -> {
                startActivity(new Intent(this, activityClass));
                overridePendingTransition(R.anim.slide_in_right1, R.anim.slide_out_left1);
            }, 200);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reset to home tab when returning to this activity
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
    }
}