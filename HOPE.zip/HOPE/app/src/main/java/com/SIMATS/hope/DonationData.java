package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class DonationData {
    @SerializedName("id")
    private Integer id;

    @SerializedName("donation_type")
    private String donation_type;

    @SerializedName("cause")
    private String cause;

    @SerializedName("amount")
    private Double amount;

    @SerializedName("item_description")
    private String item_description;

    @SerializedName("quantity")
    private Integer quantity;

    @SerializedName("full_name")
    private String full_name;

    @SerializedName("phone")
    private String phone;

    @SerializedName("orphanage_name")
    private String orphanage_name;

    @SerializedName("status")
    private String status;

    @SerializedName("created_at")
    private String created_at;

    // Getters
    public Integer getId() { return id; }
    public String getDonation_type() { return donation_type; }
    public String getCause() { return cause; }
    public Double getAmount() { return amount; }
    public String getItem_description() { return item_description; }
    public Integer getQuantity() { return quantity; }
    public String getFull_name() { return full_name; }
    public String getPhone() { return phone; }
    public String getOrphanage_name() { return orphanage_name; }
    public String getStatus() { return status; }
    public String getCreated_at() { return created_at; }
}