////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.os.Bundle;
////import android.os.Handler;
////import android.view.animation.Animation;
////import android.view.animation.AnimationUtils;
////import android.widget.ImageView;
////import androidx.appcompat.app.AppCompatActivity;
////
////public class SplashActivity extends AppCompatActivity {
////
////    private static final int SPLASH_DELAY = 2200; // 2.2 seconds
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_splash);
////
////        // Load animations with error handling
////        try {
////            Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in1);
////            Animation floatUp = AnimationUtils.loadAnimation(this, R.anim.float_up1);
////
////            ImageView birdIcon = findViewById(R.id.bird_Icon);
////            birdIcon.startAnimation(floatUp);
////
////            findViewById(R.id.hopeText).startAnimation(fadeIn);
////            findViewById(R.id.handshake_icon).startAnimation(fadeIn);
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////        new Handler().postDelayed(() -> {
////            startActivity(new Intent(SplashActivity.this, Splash1_activity.class));
////            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
////            finish();
////        }, SPLASH_DELAY);
////    }
////
////    @Override
////    protected void onPause() {
////        super.onPause();
////        // Clear animations to prevent memory leaks
////        findViewById(R.id.bird_Icon).clearAnimation();
////        findViewById(R.id.hopeText).clearAnimation();
////        findViewById(R.id.handshake_icon).clearAnimation();
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//import android.view.animation.Animation;
//import android.view.animation.AnimationUtils;
//import android.widget.ImageView;
//import androidx.appcompat.app.AppCompatActivity;
//
//public class SplashActivity extends AppCompatActivity {
//
//    private static final int SPLASH_DELAY = 2200; // 2.2 seconds
//    private PrefManager prefManager;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_splash);
//
//        prefManager = new PrefManager(this);
//
//        // Load animations with error handling
//        try {
//            Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in1);
//            Animation floatUp = AnimationUtils.loadAnimation(this, R.anim.float_up1);
//
//            ImageView birdIcon = findViewById(R.id.bird_Icon);
//            if (birdIcon != null) {
//                birdIcon.startAnimation(floatUp);
//            }
//
//            if (findViewById(R.id.hopeText) != null) {
//                findViewById(R.id.hopeText).startAnimation(fadeIn);
//            }
//
//            if (findViewById(R.id.handshake_icon) != null) {
//                findViewById(R.id.handshake_icon).startAnimation(fadeIn);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        new Handler().postDelayed(() -> {
//            checkLoginStatus();
//        }, SPLASH_DELAY);
//    }
//
//    private void checkLoginStatus() {
//        if (prefManager.isLoggedIn()) {
//            // User is already logged in, redirect to MonetaryDonationActivity
//            Intent intent = new Intent(SplashActivity.this, ReportChildActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
//            finish();
//        } else {
//            // No one is logged in, go to Splash1_activity
//            startActivity(new Intent(SplashActivity.this, Splash1_activity.class));
//            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
//            finish();
//        }
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        // Clear animations to prevent memory leaks
//        try {
//            if (findViewById(R.id.bird_Icon) != null) {
//                findViewById(R.id.bird_Icon).clearAnimation();
//            }
//            if (findViewById(R.id.hopeText) != null) {
//                findViewById(R.id.hopeText).clearAnimation();
//            }
//            if (findViewById(R.id.handshake_icon) != null) {
//                findViewById(R.id.handshake_icon).clearAnimation();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.messaging.FirebaseMessaging;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DELAY = 2200; // 2.2 seconds
    private PrefManager prefManager;
    private static final String TAG = "SplashActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        prefManager = new PrefManager(this);

        // Initialize FCM and get token
        setupFCM();

        // Load animations with error handling
        try {
            Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in1);
            Animation floatUp = AnimationUtils.loadAnimation(this, R.anim.float_up1);

            ImageView birdIcon = findViewById(R.id.bird_Icon);
            if (birdIcon != null) {
                birdIcon.startAnimation(floatUp);
            }

            if (findViewById(R.id.hopeText) != null) {
                findViewById(R.id.hopeText).startAnimation(fadeIn);
            }

            if (findViewById(R.id.handshake_icon) != null) {
                findViewById(R.id.handshake_icon).startAnimation(fadeIn);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        new Handler().postDelayed(() -> {
            checkLoginStatus();
        }, SPLASH_DELAY);
    }

    private void setupFCM() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();
                    Log.d(TAG, "FCM Token: " + token);

                    // Save token locally
                    prefManager.setFcmToken(token);

                    // Send token to server if user is logged in
                    if (prefManager.isLoggedIn()) {
                        sendFcmTokenToServer(token);
                    }
                });
    }

    private void sendFcmTokenToServer(String token) {
        int userId = prefManager.getUserId();

        if (userId != 0 && token != null) {
            ApiService apiService = ApiClient.getClient().create(ApiService.class);
            Call<BaseResponse> call = apiService.updateFcmToken(userId, token);
            call.enqueue(new Callback<BaseResponse>() {
                @Override
                public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        Log.d(TAG, "FCM token updated successfully");
                    } else {
                        Log.e(TAG, "Failed to update FCM token: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<BaseResponse> call, Throwable t) {
                    Log.e(TAG, "Failed to update FCM token: " + t.getMessage());
                }
            });
        }
    }
    private void checkLoginStatus() {
        if (prefManager.isLoggedIn()) {
            // User is already logged in, redirect to MonetaryDonationActivity
            Intent intent = new Intent(SplashActivity.this, ReportChildActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            finish();
        } else {
            // No one is logged in, go to Splash1_activity
            startActivity(new Intent(SplashActivity.this, Splash1_activity.class));
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
            finish();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Clear animations to prevent memory leaks
        try {
            if (findViewById(R.id.bird_Icon) != null) {
                findViewById(R.id.bird_Icon).clearAnimation();
            }
            if (findViewById(R.id.hopeText) != null) {
                findViewById(R.id.hopeText).clearAnimation();
            }
            if (findViewById(R.id.handshake_icon) != null) {
                findViewById(R.id.handshake_icon).clearAnimation();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}