//////package com.SIMATS.hope;
//////
//////import android.content.SharedPreferences;
//////import android.os.Bundle;
//////import android.view.View;
//////import android.widget.ImageView;
//////import android.widget.ProgressBar;
//////import android.widget.TextView;
//////import android.widget.Toast;
//////
//////import androidx.appcompat.app.AppCompatActivity;
//////import androidx.recyclerview.widget.LinearLayoutManager;
//////import androidx.recyclerview.widget.RecyclerView;
//////
//////import java.util.ArrayList;
//////
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////
//////public class MyDonationsActivity extends AppCompatActivity {
//////
//////    private ImageView ivBack;
//////    private ProgressBar progressBar;
//////    private TextView tvError;
//////    private DonationAdapter donationAdapter;
//////    private RecyclerView recyclerView;
//////    private int userId = 0; // Example static user ID
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.activity_my_donations);
//////
//////        initializeViews();
//////        loadDonationData();
//////
//////        ivBack.setOnClickListener(v -> finish());
//////    }
//////
//////    private void initializeViews() {
//////        ivBack = findViewById(R.id.ivBack);
//////        progressBar = findViewById(R.id.progressBar);
//////        tvError = findViewById(R.id.tvError);
//////        recyclerView = findViewById(R.id.rvDonations);
//////
//////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//////        donationAdapter = new DonationAdapter(this, new ArrayList<>());
//////        recyclerView.setAdapter(donationAdapter);
//////    }
//////
//////    private void loadDonationData() {
//////        progressBar.setVisibility(View.VISIBLE);
//////        tvError.setVisibility(View.GONE);
//////
//////
//////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////        userId = prefs.getInt("user_id",0);
//////
//////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////        Call<DonationListResponse> call = apiService.getUserDonations(userId);
//////
//////        call.enqueue(new Callback<DonationListResponse>() {
//////            @Override
//////            public void onResponse(Call<DonationListResponse> call, Response<DonationListResponse> response) {
//////                progressBar.setVisibility(View.GONE);
//////
//////                if (response.isSuccessful() && response.body() != null) {
//////                    DonationListResponse apiResponse = response.body();
//////
//////                    if (apiResponse.isStatus() && apiResponse.getData() != null && !apiResponse.getData().isEmpty()) {
//////                        donationAdapter.updateList(apiResponse.getData());
//////                    } else {
//////                        showError(apiResponse.getMessage() != null ?
//////                                apiResponse.getMessage() : "No donations found");
//////                    }
//////                } else {
//////                    showError("Something went wrong. Please try again.");
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<DonationListResponse> call, Throwable t) {
//////                progressBar.setVisibility(View.GONE);
//////                showError("Error: " + t.getMessage());
//////            }
//////        });
//////    }
//////
//////    private void showError(String message) {
//////        tvError.setText(message);
//////        tvError.setVisibility(View.VISIBLE);
//////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//////    }
//////}
////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.content.SharedPreferences;
////import android.os.Bundle;
////import android.view.MenuItem;
////import android.view.View;
////import android.widget.Button;
////import android.widget.ImageView;
////import android.widget.ProgressBar;
////import android.widget.TextView;
////import android.widget.Toast;
////
////import androidx.annotation.NonNull;
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.recyclerview.widget.LinearLayoutManager;
////import androidx.recyclerview.widget.RecyclerView;
////
////import com.google.android.material.bottomnavigation.BottomNavigationView;
////
////import java.util.ArrayList;
////
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class MyDonationsActivity extends AppCompatActivity {
////
////    private ImageView ivBack;
////    private Button btnReceipts;
////
////    private ProgressBar progressBar;
////    private TextView tvError;
////    private DonationAdapter donationAdapter;
////    private RecyclerView recyclerView;
////    private BottomNavigationView bottomNavigationView;
////    private int userId = 0;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_my_donations);
////
////        initializeViews();
////        setupBottomNavigation();
////        loadDonationData();
////
////        ivBack.setOnClickListener(v -> finish());
////    }
////
////    private void initializeViews() {
////        ivBack = findViewById(R.id.ivBack);
////        progressBar = findViewById(R.id.progressBar);
////        tvError = findViewById(R.id.tvError);
////        recyclerView = findViewById(R.id.rvDonations);
////        bottomNavigationView = findViewById(R.id.bottomNavigationView);
////
////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
////        donationAdapter = new DonationAdapter(this, new ArrayList<>());
////        recyclerView.setAdapter(donationAdapter);
////    }
////
////    private void setupBottomNavigation() {
////        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
////            @Override
////            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
////                int itemId = item.getItemId();
////
////                if (itemId == R.id.nav_home) {
////                    startActivity(new Intent(MyDonationsActivity.this, DashboardActivity.class));
////                    return true;
////                } else if (itemId == R.id.nav_donate) {
////                    startActivity(new Intent(MyDonationsActivity.this, DonateActivity.class));
////                    return true;
////                } else if (itemId == R.id.nav_report) {
////                    startActivity(new Intent(MyDonationsActivity.this, ReportChildActivity.class));
////                    return true;
////                } else if (itemId == R.id.nav_volunteer) {
////                    startActivity(new Intent(MyDonationsActivity.this, VolunteerRequestActivity.class));
////                    return true;
////                } else if (itemId == R.id.nav_profile) {
////                    // Already in a profile-related activity, no need to navigate
////                    return true;
////                }
////                return false;
////            }
////        });
////
////        // Highlight the Profile button since this is a profile-related activity
////        bottomNavigationView.setSelectedItemId(R.id.nav_profile);
////    }
////
////    private void loadDonationData() {
////        progressBar.setVisibility(View.VISIBLE);
////        tvError.setVisibility(View.GONE);
////
////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////        userId = prefs.getInt("user_id", 0);
////
////        if (userId == 0) {
////            progressBar.setVisibility(View.GONE);
////            showError("Please login to view your donations");
////            return;
////        }
////
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<DonationListResponse> call = apiService.getUserDonations(userId);
////
////        call.enqueue(new Callback<DonationListResponse>() {
////            @Override
////            public void onResponse(Call<DonationListResponse> call, Response<DonationListResponse> response) {
////                progressBar.setVisibility(View.GONE);
////
////                if (response.isSuccessful() && response.body() != null) {
////                    DonationListResponse apiResponse = response.body();
////
////                    if (apiResponse.isStatus() && apiResponse.getData() != null && !apiResponse.getData().isEmpty()) {
////                        donationAdapter.updateList(apiResponse.getData());
////                    } else {
////                        showError(apiResponse.getMessage() != null ?
////                                apiResponse.getMessage() : "No donations found");
////                    }
////                } else {
////                    showError("Something went wrong. Please try again.");
////                }
////            }
////
////            @Override
////            public void onFailure(Call<DonationListResponse> call, Throwable t) {
////                progressBar.setVisibility(View.GONE);
////                showError("Error: " + t.getMessage());
////            }
////        });
////    }
////
////    private void showError(String message) {
////        tvError.setText(message);
////        tvError.setVisibility(View.VISIBLE);
////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
////    }
////
////    @Override
////    protected void onResume() {
////        super.onResume();
////        // Highlight the Profile button when returning to this activity
////        if (bottomNavigationView != null) {
////            bottomNavigationView.setSelectedItemId(R.id.nav_profile);
////        }
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.google.android.material.bottomnavigation.BottomNavigationView;
//
//import java.util.ArrayList;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class MyDonationsActivity extends AppCompatActivity {
//
//    private ImageView ivBack;
//    private Button btnReceipts;
//    private ProgressBar progressBar;
//    private TextView tvError;
//    private DonationAdapter donationAdapter;
//    private RecyclerView recyclerView;
//    private BottomNavigationView bottomNavigationView;
//    private int userId = 0;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_donations);
//
//        initializeViews();
//        setupBottomNavigation();
//        loadDonationData();
//
//        ivBack.setOnClickListener(v -> finish());
//
//        // Navigate to ReceiptsActivity when button is clicked
//        btnReceipts.setOnClickListener(v -> {
//            Intent intent = new Intent(MyDonationsActivity.this, ReceiptsActivity.class);
//            startActivity(intent);
//        });
//    }
//
//    private void initializeViews() {
//        ivBack = findViewById(R.id.ivBack);
//        btnReceipts = findViewById(R.id.btnReceipts);
//        progressBar = findViewById(R.id.progressBar);
//        tvError = findViewById(R.id.tvError);
//        recyclerView = findViewById(R.id.rvDonations);
//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        donationAdapter = new DonationAdapter(this, new ArrayList<>());
//        recyclerView.setAdapter(donationAdapter);
//    }
//
//    private void setupBottomNavigation() {
//        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
//            int itemId = item.getItemId();
//
//            if (itemId == R.id.nav_home) {
//                startActivity(new Intent(MyDonationsActivity.this, DashboardActivity.class));
//                return true;
//            } else if (itemId == R.id.nav_donate) {
//                startActivity(new Intent(MyDonationsActivity.this, DonateActivity.class));
//                return true;
//            } else if (itemId == R.id.nav_report) {
//                startActivity(new Intent(MyDonationsActivity.this, ReportChildActivity.class));
//                return true;
//            } else if (itemId == R.id.nav_volunteer) {
//                startActivity(new Intent(MyDonationsActivity.this, VolunteerRequestActivity.class));
//                return true;
//            } else if (itemId == R.id.nav_profile) {
//                return true; // Already on profile/donations page
//            }
//            return false;
//        });
//
//        // Highlight the Profile button
//        bottomNavigationView.setSelectedItemId(R.id.nav_profile);
//    }
//
//    private void loadDonationData() {
//        progressBar.setVisibility(View.VISIBLE);
//        tvError.setVisibility(View.GONE);
//
//        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//        userId = prefs.getInt("user_id", 0);
//
//        if (userId == 0) {
//            progressBar.setVisibility(View.GONE);
//            showError("Please login to view your donations");
//            return;
//        }
//
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<DonationListResponse> call = apiService.getUserDonations(userId);
//
//        call.enqueue(new Callback<DonationListResponse>() {
//            @Override
//            public void onResponse(Call<DonationListResponse> call, Response<DonationListResponse> response) {
//                progressBar.setVisibility(View.GONE);
//
//                if (response.isSuccessful() && response.body() != null) {
//                    DonationListResponse apiResponse = response.body();
//
//                    if (apiResponse.isStatus() && apiResponse.getData() != null && !apiResponse.getData().isEmpty()) {
//                        donationAdapter.updateList(apiResponse.getData());
//                    } else {
//                        showError(apiResponse.getMessage() != null ?
//                                apiResponse.getMessage() : "No donations found");
//                    }
//                } else {
//                    showError("Something went wrong. Please try again.");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<DonationListResponse> call, Throwable t) {
//                progressBar.setVisibility(View.GONE);
//                showError("Error: " + t.getMessage());
//            }
//        });
//    }
//
//    private void showError(String message) {
//        tvError.setText(message);
//        tvError.setVisibility(View.VISIBLE);
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        if (bottomNavigationView != null) {
//            bottomNavigationView.setSelectedItemId(R.id.nav_profile);
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyDonationsActivity extends AppCompatActivity {

    private ImageView ivBack;
    private Button btnReceipts;
    private ProgressBar progressBar;
    private TextView tvError;
    private DonationAdapter donationAdapter;
    private RecyclerView recyclerView;
    private BottomNavigationView bottomNavigationView;
    private int userId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_donations);

        initializeViews();
        setupBottomNavigation();
        loadDonationData();

        ivBack.setOnClickListener(v -> finish());

        // Navigate to ReceiptsActivity when button is clicked
        btnReceipts.setOnClickListener(v -> {
            Intent intent = new Intent(MyDonationsActivity.this, ReceiptsActivity.class);
            startActivity(intent);
        });
    }

    private void initializeViews() {
        ivBack = findViewById(R.id.ivBack);
        btnReceipts = findViewById(R.id.btnReceipts);
        progressBar = findViewById(R.id.progressBar);
        tvError = findViewById(R.id.tvError);
        recyclerView = findViewById(R.id.rvDonations);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        donationAdapter = new DonationAdapter(this, new ArrayList<>());
        recyclerView.setAdapter(donationAdapter);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                startActivity(new Intent(MyDonationsActivity.this, DashboardActivity.class));
                return true;
            } else if (itemId == R.id.nav_donate) {
                startActivity(new Intent(MyDonationsActivity.this, DonateActivity.class));
                return true;
            } else if (itemId == R.id.nav_report) {
                startActivity(new Intent(MyDonationsActivity.this, ReportChildActivity.class));
                return true;
            } else if (itemId == R.id.nav_volunteer) {
                startActivity(new Intent(MyDonationsActivity.this, VolunteerRequestActivity.class));
                return true;
            } else if (itemId == R.id.nav_profile) {
                return true; // Already on profile/donations page
            }
            return false;
        });

        // Highlight the Profile button
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);
    }

    private void loadDonationData() {
        progressBar.setVisibility(View.VISIBLE);
        tvError.setVisibility(View.GONE);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        userId = prefs.getInt("user_id", 0);

        if (userId == 0) {
            progressBar.setVisibility(View.GONE);
            showError("Please login to view your donations");
            return;
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<DonationListResponse> call = apiService.getUserDonations(userId);

        call.enqueue(new Callback<DonationListResponse>() {
            @Override
            public void onResponse(Call<DonationListResponse> call, Response<DonationListResponse> response) {
                progressBar.setVisibility(View.GONE);

                if (response.isSuccessful() && response.body() != null) {
                    DonationListResponse apiResponse = response.body();

                    if (apiResponse.isStatus() && apiResponse.getData() != null && !apiResponse.getData().isEmpty()) {
                        donationAdapter.updateList(apiResponse.getData());
                    } else {
                        showError(apiResponse.getMessage() != null ?
                                apiResponse.getMessage() : "No donations found");
                    }
                } else {
                    showError("Something went wrong. Please try again.");
                }
            }

            @Override
            public void onFailure(Call<DonationListResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                showError("Error: " + t.getMessage());
            }
        });
    }

    private void showError(String message) {
        tvError.setText(message);
        tvError.setVisibility(View.VISIBLE);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_profile);
        }
    }
}