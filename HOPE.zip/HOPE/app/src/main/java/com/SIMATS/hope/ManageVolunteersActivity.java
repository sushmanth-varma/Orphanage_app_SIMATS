package com.SIMATS.hope;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// import android.widget.Toast;
// import com.android.volley.Request;
// import com.android.volley.RequestQueue;
// import com.android.volley.toolbox.JsonObjectRequest;
// import com.android.volley.toolbox.Volley;
// import org.json.JSONArray;
// import org.json.JSONObject;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ManageVolunteersActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<Volunteer_admin> volunteerList;
    VolunteerAdapter_admin adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_volunteers_admin);

        recyclerView = findViewById(R.id.volunteerRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        volunteerList = new ArrayList<>();

        adapter = new VolunteerAdapter_admin(this, volunteerList);
        recyclerView.setAdapter(adapter);

        fetchVolunteers();
    }

    private void fetchVolunteers() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<VolunteerResponse> call = apiService.getAllVolunteers();

        call.enqueue(new Callback<VolunteerResponse>() {
            @Override
            public void onResponse(Call<VolunteerResponse> call, Response<VolunteerResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    volunteerList.clear();
                    volunteerList.addAll(response.body().getData());
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<VolunteerResponse> call, Throwable t) {
                Toast.makeText(ManageVolunteersActivity.this, "Failed to load volunteers", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
