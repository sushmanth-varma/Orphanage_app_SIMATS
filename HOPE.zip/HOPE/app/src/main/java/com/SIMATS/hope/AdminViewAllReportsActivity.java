package com.SIMATS.hope;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminViewAllReportsActivity extends AppCompatActivity {

    private RecyclerView recyclerViewReports;
    private ReportAdapter_Admin reportsAdapter;
    private ArrayList<ReportModel_Admin> reportList = new ArrayList<>();
    private ApiService apiService;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_all_reports);

        initializeViews();
        setupRecyclerView();
        setupApiService();
        fetchReports();
        setupSwipeRefresh();
    }

    private void initializeViews() {
        recyclerViewReports = findViewById(R.id.recyclerViewReports);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
    }

    private void setupRecyclerView() {
        recyclerViewReports.setLayoutManager(new LinearLayoutManager(this));
        reportsAdapter = new ReportAdapter_Admin(reportList, this);
        recyclerViewReports.setAdapter(reportsAdapter);
    }

    private void setupApiService() {
        apiService = ApiClient.getClient().create(ApiService.class);
    }

    private void setupSwipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(this::fetchReports);
    }

    public void fetchReports() {
        swipeRefreshLayout.setRefreshing(true);

        apiService.getAllReports().enqueue(new Callback<ApiResponseViewReportsAdmin>() {
            @Override
            public void onResponse(Call<ApiResponseViewReportsAdmin> call,
                                   Response<ApiResponseViewReportsAdmin> response) {
                swipeRefreshLayout.setRefreshing(false);
                handleApiResponse(response);
            }

            @Override
            public void onFailure(Call<ApiResponseViewReportsAdmin> call, Throwable t) {
                swipeRefreshLayout.setRefreshing(false);
                showToast("Network error: " + t.getMessage());
            }
        });
    }

    private void handleApiResponse(Response<ApiResponseViewReportsAdmin> response) {
        if (response.isSuccessful() && response.body() != null) {
            ApiResponseViewReportsAdmin apiResponse = response.body();
            if ("success".equals(apiResponse.getStatus())) {
                updateReportList(new ArrayList<>(apiResponse.getData())); // Convert List to ArrayList
            } else {
                showToast("No reports found");
            }
        } else {
            showToast("Failed to fetch reports");
        }
    }

    private void updateReportList(ArrayList<ReportModel_Admin> newReports) {
        reportList.clear();
        reportList.addAll(newReports);
        reportsAdapter.notifyDataSetChanged();
    }

    public void refreshAfterAssignment() {
        fetchReports();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}