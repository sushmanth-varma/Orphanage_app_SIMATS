package com.SIMATS.hope;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class OrphanageAdapter extends ArrayAdapter<Orphanage> {

    private Context context;
    private List<Orphanage> orphanages;

    public OrphanageAdapter(Context context, List<Orphanage> orphanages) {
        super(context, 0, orphanages);
        this.context = context;
        this.orphanages = orphanages;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return createView(position, convertView, parent);
    }

    private View createView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(android.R.layout.simple_spinner_dropdown_item, parent, false);
        }

        TextView textView = convertView.findViewById(android.R.id.text1);

        if (position == 0) {
            // First item is the hint
            textView.setText("Select an orphanage (Optional)");
        } else {
            // Orphanage items
            Orphanage orphanage = orphanages.get(position - 1);
            textView.setText(orphanage.getDisplayText());
        }

        return convertView;
    }

    @Override
    public int getCount() {
        return orphanages.size() + 1; // +1 for the hint item
    }
}