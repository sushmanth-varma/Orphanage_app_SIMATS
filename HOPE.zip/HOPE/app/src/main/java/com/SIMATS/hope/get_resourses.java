package com.SIMATS.hope;

import java.util.List;

public class get_resourses {
    private List<Resource> resources;
    private List<Helpline> helplines;

    public List<Resource> getResources() {
        return resources;
    }

    public List<Helpline> getHelplines() {
        return helplines;
    }
}
