package com.SIMATS.hope;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewDonationsActivity_admin extends AppCompatActivity {

    private static final String TAG = "ViewDonationsActivity";
    ListView donationsListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_donations_admin);

        donationsListView = findViewById(R.id.donationsListView);
        fetchDonationsFromServer();
    }

    private void fetchDonationsFromServer() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<DonationResponse_get_Admin> call = apiService.getDonations();

        call.enqueue(new Callback<DonationResponse_get_Admin>() {
            @Override
            public void onResponse(Call<DonationResponse_get_Admin> call, Response<DonationResponse_get_Admin> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ArrayList<HashMap<String, String>> donationList = new ArrayList<>();

                    for (Donation_get_Admin donation : response.body().getDonations()) {
                        HashMap<String, String> donationItem = new HashMap<>();

                        // Donation ID
                        donationItem.put("id", "ID: #" + donation.getId());

                        // Donor information
                        donationItem.put("donor", "Donor: " + donation.getDonor_name());

                        // Contact information
                        donationItem.put("phone", "Phone: " + (donation.getPhone() != null ? donation.getPhone() : "Not provided"));
                        donationItem.put("location", "Location: " + (donation.getLocation() != null ? donation.getLocation() : "Not specified"));

                        // Donation details
                        donationItem.put("type", "Type: " + donation.getDonation_type());

                        if ("Monetary".equalsIgnoreCase(donation.getDonation_type())) {
                            donationItem.put("amount", "Amount: ₹" + donation.getAmount());
                        } else {
                            String items = donation.getItem_description();
                            String quantity = donation.getQuantity();
                            donationItem.put("amount", "Items: " + items + (quantity != null ? " (Qty: " + quantity + ")" : ""));
                        }

                        // Status and dates
                        donationItem.put("status", "Status: " + donation.getStatus());
                        donationItem.put("date", "Date: " + donation.getCreated_at());

                        // Volunteer assignment
                        donationItem.put("volunteer", "Volunteer: " +
                                (donation.getVolunteer_name() != null ? donation.getVolunteer_name() : "Unassigned"));

                        donationList.add(donationItem);
                    }

                    // Update UI
                    SimpleAdapter adapter = new SimpleAdapter(
                            ViewDonationsActivity_admin.this,
                            donationList,
                            R.layout.donation_item_admin,
                            new String[]{"id", "donor", "phone", "location", "type", "amount", "status", "date", "volunteer"},
                            new int[]{R.id.donationId, R.id.donorName, R.id.donorPhone, R.id.donationLocation,
                                    R.id.donationType, R.id.donationAmount, R.id.donationStatus,
                                    R.id.textDate}
                    );

                    donationsListView.setAdapter(adapter);
                } else {
                    Log.e(TAG, "API Error: " + response.code() + " - " + response.message());
                    Toast.makeText(ViewDonationsActivity_admin.this,
                            "Failed to load donations", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DonationResponse_get_Admin> call, Throwable t) {
                Log.e(TAG, "API Failure", t);
                Toast.makeText(ViewDonationsActivity_admin.this,
                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}