package com.SIMATS.hope;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class OtpVerificationActivity extends AppCompatActivity {

    EditText otp1, otp2, otp3, otp4;
    Button continueBtn, backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_verification);

        otp1 = findViewById(R.id.otp1);
        otp2 = findViewById(R.id.otp2);
        otp3 = findViewById(R.id.otp3);
        otp4 = findViewById(R.id.otp4);
        continueBtn = findViewById(R.id.continueBtn);
        backBtn = findViewById(R.id.backBtn);

        continueBtn.setOnClickListener(v -> {
            String code = otp1.getText().toString() + otp2.getText().toString()
                    + otp3.getText().toString() + otp4.getText().toString();
            if (code.length() == 4) {
                // TODO: Verify OTP
                Toast.makeText(this, "OTP Verified!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Enter full 4-digit OTP", Toast.LENGTH_SHORT).show();
            }
        });

        backBtn.setOnClickListener(v -> finish());
    }
}
