package com.SIMATS.hope;
public class ChangePasswordRequest {
    private String phone;
    private String current_password;
    private String new_password;
    private String confirm_password;

    public ChangePasswordRequest(String phone, String currentPassword,
                                 String newPassword, String confirmPassword) {
        this.phone = phone;
        this.current_password = currentPassword;
        this.new_password = newPassword;
        this.confirm_password = confirmPassword;
    }

    // Getters
    public String getPhone() { return phone; }
    public String getCurrent_password() { return current_password; }
    public String getNew_password() { return new_password; }
    public String getConfirm_password() { return confirm_password; }
}
