package com.SIMATS.hope;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VolunteerAdapter_admin extends RecyclerView.Adapter<VolunteerAdapter_admin.VolunteerViewHolder> {

    private Context context;
    private List<Volunteer_admin> volunteerList;

    public VolunteerAdapter_admin(Context context, List<Volunteer_admin> volunteerList) {
        this.context = context;
        this.volunteerList = volunteerList;
    }

    @NonNull
    @Override
    public VolunteerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.volunteer_item_admin, parent, false);
        return new VolunteerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VolunteerViewHolder holder, int position) {
        Volunteer_admin volunteer = volunteerList.get(position);
        holder.nameTextView.setText("Name: " + volunteer.getFull_name());
        holder.emailTextView.setText("Email: " + volunteer.getEmail());
        holder.phoneTextView.setText("Phone: " + volunteer.getPhone());
        holder.reasonTextView.setText("Reason: " + volunteer.getReason());

        holder.approveButton.setOnClickListener(v -> {
            // Create dialog to enter password
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Enter Password for Volunteer");

            final EditText input = new EditText(context);
            input.setHint("Enter password");
            input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
            builder.setView(input);

            builder.setPositiveButton("Approve", (dialog, which) -> {
                String password = input.getText().toString().trim();
                if (password.isEmpty()) {
                    Toast.makeText(context, "Password cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                ApproveRequest request = new ApproveRequest(volunteer.getEmail(), password);

                ApiService apiService = ApiClient.getClient().create(ApiService.class);
                apiService.approveVolunteer(request).enqueue(new Callback<ApproveResponse>() {
                    @Override
                    public void onResponse(Call<ApproveResponse> call, Response<ApproveResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            volunteerList.remove(position);
                            notifyItemRemoved(position);
                        } else {
                            Toast.makeText(context, "Approval failed", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<ApproveResponse> call, Throwable t) {
                        Toast.makeText(context, "Network Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

            builder.show();
        });
    }

    @Override
    public int getItemCount() {
        return volunteerList.size();
    }

    public static class VolunteerViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView, emailTextView, phoneTextView, reasonTextView;
        Button approveButton;

        public VolunteerViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            emailTextView = itemView.findViewById(R.id.emailTextView);
            phoneTextView = itemView.findViewById(R.id.phoneTextView);
            reasonTextView = itemView.findViewById(R.id.reasonTextView);
            approveButton = itemView.findViewById(R.id.approveButton);
        }
    }
}
