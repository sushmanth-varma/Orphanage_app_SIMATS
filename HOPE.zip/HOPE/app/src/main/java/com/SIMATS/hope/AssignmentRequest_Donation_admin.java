package com.SIMATS.hope;

public class AssignmentRequest_Donation_admin {
    private int donation_id;
    private int volunteer_id;

    public AssignmentRequest_Donation_admin(int donation_id, int volunteer_id) {
        this.donation_id = donation_id;
        this.volunteer_id = volunteer_id;
    }

    // Getters
    public int getDonation_id() {
        return donation_id;
    }

    public int getVolunteer_id() {
        return volunteer_id;
    }
}