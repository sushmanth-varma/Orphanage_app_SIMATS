package com.SIMATS.hope;

public class Donation {
    private int id;
    private String donation_type;
    private String cause;
    private Double amount;
    private String item_description;
    private String quantity;
    private String full_name;
    private String phone;
    private String orphanage_name;
    private String location;
    private String status;
    private String created_at;

    // Getters and Setters
    public int getId() { return id; }
    public String getDonation_type() { return donation_type; }
    public String getCause() { return cause; }
    public Double getAmount() { return amount; }
    public String getItem_description() { return item_description; }
    public String getQuantity() { return quantity; }
    public String getFull_name() { return full_name; }
    public String getPhone() { return phone; }
    public String getOrphanage_name() { return orphanage_name; }
    public String getLocation() { return location; }
    public String getStatus() { return status; }
    public String getCreated_at() { return created_at; }
}