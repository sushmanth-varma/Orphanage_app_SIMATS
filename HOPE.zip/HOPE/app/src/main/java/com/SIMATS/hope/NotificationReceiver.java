package com.SIMATS.hope;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class NotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("RECEIPTS_REFRESH_ACTION".equals(intent.getAction())) {
            // Show a toast or refresh the receipts list
            Toast.makeText(context, "New receipt available!", Toast.LENGTH_SHORT).show();

            // You can also send a local broadcast to refresh your ReceiptsActivity
            Intent refreshIntent = new Intent("REFRESH_RECEIPTS_LIST");
            context.sendBroadcast(refreshIntent);
        }
    }
}