package com.SIMATS.hope;

public class UpdateStatusResponse_Volunteer {
    private String status;
    private String message;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
