package com.SIMATS.hope;

public class Helpline {
    private int id;
    private String name;
    private String number;
    private String description;

    public int getId() { return id; }
    public String getName() { return name; }
    public String getNumber() { return number; }
    public String getDescription() { return description; }
}