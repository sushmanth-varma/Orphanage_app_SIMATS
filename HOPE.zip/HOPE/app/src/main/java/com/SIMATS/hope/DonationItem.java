package com.SIMATS.hope;

public class DonationItem {
    private String category;
    private String item;
    private int quantity;
    private String unit;

    public DonationItem(String category, String item, int quantity, String unit) {
        this.category = category;
        this.item = item;
        this.quantity = quantity;
        this.unit = unit;
    }

    public String getCategory() {
        return category;
    }

    public String getItem() {
        return item;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getUnit() {
        return unit;
    }

    @Override
    public String toString() {
        return category + " - " + item + " (" + quantity + " " + unit + ")";
    }
}