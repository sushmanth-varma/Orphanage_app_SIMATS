package com.SIMATS.hope;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DonationAdapter_Volunteer_get extends RecyclerView.Adapter<DonationAdapter_Volunteer_get.ViewHolder> {

    private Context context;
    private ArrayList<Donation_get_volunteer> donations;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onUpdateClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public DonationAdapter_Volunteer_get(Context context, ArrayList<Donation_get_volunteer> donations) {
        this.context = context;
        this.donations = donations;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_donation_volunteer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Donation_get_volunteer donation = donations.get(position);

        holder.tvDonationType.setText(donation.getDonationType());
        holder.tvStatus.setText(donation.getStatus());
        holder.tvCause.setText("For: " + donation.getCause());

        if (donation.getDonationType().equals("Material")) {
            holder.tvDetails.setText(String.format("%s (Qty: %d)",
                    donation.getItemDescription(),
                    donation.getQuantity()));
        } else {
            holder.tvDetails.setText(String.format("Amount: ₹%s", donation.getAmount()));
        }

        holder.tvOrphanage.setText(donation.getOrphanageName());
        holder.tvLocation.setText(donation.getLocation());
        holder.tvDate.setText("Assigned on: " + donation.getDates().getCreatedAt());

        // Set status background color
        switch(donation.getStatus().toLowerCase()) {
            case "assigned":
                holder.tvStatus.setBackgroundResource(R.drawable.status_background_assigned);
                break;
            case "collected":
                holder.tvStatus.setBackgroundResource(R.drawable.status_background_collected);
                break;
            case "completed":
                holder.tvStatus.setBackgroundResource(R.drawable.status_background_completed);
                break;
            default:
                holder.tvStatus.setBackgroundResource(R.drawable.ic_launcher_background);
        }

        holder.btnAction.setOnClickListener(v -> {
            if (listener != null) {
                listener.onUpdateClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return donations.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDonationType, tvStatus, tvCause, tvDetails, tvOrphanage, tvLocation, tvDate;
        Button btnAction;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDonationType = itemView.findViewById(R.id.tvDonationType);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvCause = itemView.findViewById(R.id.tvCause);
            tvDetails = itemView.findViewById(R.id.tvDetails);
            tvOrphanage = itemView.findViewById(R.id.tvOrphanage);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvDate = itemView.findViewById(R.id.tvDate);
            btnAction = itemView.findViewById(R.id.btnAction);
        }
    }
}