package com.SIMATS.hope;

public class ApproveRequest {
    private String email;
    private String password;

    public ApproveRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
