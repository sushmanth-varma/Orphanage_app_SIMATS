//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.widget.Button;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class UploadReceiptActivity extends AppCompatActivity {
//
//    private Button btnBackToDonations;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.upload_receipt_volunteer);
//
//        // Initialize the button - THIS WAS MISSING!
//        btnBackToDonations = findViewById(R.id.btnBackToDonations);
//
//        btnBackToDonations.setOnClickListener(v -> {
//            // Navigate back to DonationListActivity_volunteer
//            Intent intent = new Intent(UploadReceiptActivity.this, DonationListActivity_volunteer.class);
//            startActivity(intent);
//            finish(); // Close current activity
//        });
//
//        // Get the donation ID passed from DonationListActivity_volunteer
//        Intent intent = getIntent();
//        if (intent != null && intent.hasExtra("donation_id")) {
//            int donationId = intent.getIntExtra("donation_id", -1);
//            // You can use this donationId to pre-fill fields or for API calls
//        }
//    }
//
//    @Override
//    public void onBackPressed() {
//        // Override back button to navigate back to DonationListActivity_volunteer
//        Intent intent = new Intent(this, DonationListActivity_volunteer.class);
//        startActivity(intent);
//        finish();
//        super.onBackPressed();
//    }
//}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.net.Uri;
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.SIMATS.hope.R;
//
//import java.io.File;
//import java.io.IOException;
//
//import okhttp3.MediaType;
//import okhttp3.MultipartBody;
//import okhttp3.RequestBody;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class UploadReceiptActivity extends AppCompatActivity {
//
//    private Button btnBackToDonations, btnUpload, btnSelectFile;
//    private EditText etDonationId, etPurpose, etRemarks, etAmountDonated, etAmountUsed, etItemDescription, etQuantity;
//    private TextView tvSelectedFileName;
//    private PrefManager prefManager;
//    private ApiService apiService;
//
//    private int donationId;
//    private int volunteerId;
//    private int userId;
//
//    private Uri fileUri;
//    private static final int PICK_FILE_REQUEST = 1;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.upload_receipt_volunteer);
//
//        prefManager = new PrefManager(this);
//        apiService = ApiClient.getClient().create(ApiService.class);
//
//        // Initialize views
//        initViews();
//
//        // Get the donation ID passed from DonationListActivity_volunteer
//        Intent intent = getIntent();
//        if (intent != null && intent.hasExtra("donation_id")) {
//            donationId = intent.getIntExtra("donation_id", -1);
//            etDonationId.setText(String.valueOf(donationId));
//            etDonationId.setEnabled(false);
//        }
//
//        // Get volunteer ID and user ID from shared preferences
//        volunteerId = prefManager.getVolunteerId();
//        userId = prefManager.getUserId();
//
//        // Set up button listeners
//        btnSelectFile.setOnClickListener(v -> selectFile());
//        btnUpload.setOnClickListener(v -> uploadReceipt());
//
//        btnBackToDonations.setOnClickListener(v -> {
//            Intent backIntent = new Intent(UploadReceiptActivity.this, DonationListActivity_volunteer.class);
//            startActivity(backIntent);
//            finish();
//        });
//    }
//
//    private void initViews() {
//        btnBackToDonations = findViewById(R.id.btnBackToDonations);
//        btnUpload = findViewById(R.id.btnUpload);
//        btnSelectFile = findViewById(R.id.btnSelectFile);
//        etDonationId = findViewById(R.id.etDonationId);
//        etPurpose = findViewById(R.id.etPurpose);
//        etRemarks = findViewById(R.id.etRemarks);
//        etAmountDonated = findViewById(R.id.etAmountDonated);
//        etAmountUsed = findViewById(R.id.etAmountUsed);
//        etItemDescription = findViewById(R.id.etItemDescription);
//        etQuantity = findViewById(R.id.etQuantity);
//        tvSelectedFileName = findViewById(R.id.tvSelectedFileName);
//    }
//
//    private void selectFile() {
//        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
//        intent.setType("image/*");
//        intent.addCategory(Intent.CATEGORY_OPENABLE);
//        startActivityForResult(Intent.createChooser(intent, "Select Proof Image"), PICK_FILE_REQUEST);
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null) {
//            fileUri = data.getData();
//            if (fileUri != null) {
//                String fileName = getFileNameFromUri(fileUri);
//                tvSelectedFileName.setText(fileName);
//            }
//        }
//    }
//
//    private String getFileNameFromUri(Uri uri) {
//        String result = null;
//        if (uri.getScheme().equals("content")) {
//            try (var cursor = getContentResolver().query(uri, null, null, null, null)) {
//                if (cursor != null && cursor.moveToFirst()) {
//                    result = cursor.getString(cursor.getColumnIndexOrThrow("_display_name"));
//                }
//            }
//        }
//        if (result == null) {
//            result = uri.getPath();
//            int cut = result.lastIndexOf('/');
//            if (cut != -1) {
//                result = result.substring(cut + 1);
//            }
//        }
//        return result;
//    }
//
//    private void uploadReceipt() {
//        String purpose = etPurpose.getText().toString().trim();
//        String remarks = etRemarks.getText().toString().trim();
//        String amountDonatedStr = etAmountDonated.getText().toString().trim();
//        String amountUsedStr = etAmountUsed.getText().toString().trim();
//        String itemDescription = etItemDescription.getText().toString().trim();
//        String quantityStr = etQuantity.getText().toString().trim();
//
//        // Validate required fields
//        if (purpose.isEmpty()) {
//            etPurpose.setError("Purpose is required");
//            etPurpose.requestFocus();
//            return;
//        }
//
//        if (fileUri == null) {
//            Toast.makeText(this, "Please select a proof image", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Parse numeric values
//        double amountDonated = 0;
//        double amountUsed = 0;
//        int quantity = 0;
//
//        try {
//            if (!amountDonatedStr.isEmpty()) amountDonated = Double.parseDouble(amountDonatedStr);
//            if (!amountUsedStr.isEmpty()) amountUsed = Double.parseDouble(amountUsedStr);
//            if (!quantityStr.isEmpty()) quantity = Integer.parseInt(quantityStr);
//        } catch (NumberFormatException e) {
//            Toast.makeText(this, "Please enter valid numeric values", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Create RequestBody objects for text fields
//        RequestBody donationIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(donationId));
//        RequestBody volunteerIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(volunteerId));
//        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(userId));
//        RequestBody purposeBody = RequestBody.create(MediaType.parse("text/plain"), purpose);
//        RequestBody remarksBody = RequestBody.create(MediaType.parse("text/plain"), remarks);
//        RequestBody amountDonatedBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(amountDonated));
//        RequestBody amountUsedBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(amountUsed));
//        RequestBody itemDescriptionBody = RequestBody.create(MediaType.parse("text/plain"), itemDescription);
//        RequestBody quantityBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(quantity));
//
//        // Prepare file for upload
//        MultipartBody.Part filePart;
//        try {
//            File file = new File(getRealPathFromURI(fileUri));
//            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
//            filePart = MultipartBody.Part.createFormData("receipt_file", file.getName(), requestFile);
//        } catch (Exception e) {
//            Toast.makeText(this, "Error preparing file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Show loading
//        btnUpload.setEnabled(false);
//        btnUpload.setText("Uploading...");
//
//        // Make API call
//        Call<UploadResponse> call = apiService.uploadReceipt(
//                donationIdBody, volunteerIdBody, userIdBody, purposeBody, remarksBody,
//                amountDonatedBody, amountUsedBody, itemDescriptionBody, quantityBody,
//                filePart
//        );
//
//        call.enqueue(new Callback<UploadResponse>() {
//            @Override
//            public void onResponse(Call<UploadResponse> call, Response<UploadResponse> response) {
//                btnUpload.setEnabled(true);
//                btnUpload.setText("Upload Receipt");
//
//                if (response.isSuccessful() && response.body() != null) {
//                    UploadResponse uploadResponse = response.body();
//                    if ("success".equals(uploadResponse.getStatus())) {
//                        Toast.makeText(UploadReceiptActivity.this, uploadResponse.getMessage(), Toast.LENGTH_SHORT).show();
//
//                        // Navigate back to donations list
//                        Intent intent = new Intent(UploadReceiptActivity.this, DonationListActivity_volunteer.class);
//                        startActivity(intent);
//                        finish();
//                    } else {
//                        Toast.makeText(UploadReceiptActivity.this, uploadResponse.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    // Handle non-JSON response or server errors
//                    try {
//                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
//                        Log.e("UploadError", "Server response: " + errorBody);
//                        Toast.makeText(UploadReceiptActivity.this, "Server error: " + response.code(), Toast.LENGTH_SHORT).show();
//                    } catch (IOException e) {
//                        Toast.makeText(UploadReceiptActivity.this, "Upload failed", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<UploadResponse> call, Throwable t) {
//                btnUpload.setEnabled(true);
//                btnUpload.setText("Upload Receipt");
//                Log.e("UploadError", "Network error: " + t.getMessage());
//                Toast.makeText(UploadReceiptActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private String getRealPathFromURI(Uri fileUri) {
//    }
//
//    @Override
//    public void onBackPressed() {
//        Intent intent = new Intent(this, DonationListActivity_volunteer.class);
//        startActivity(intent);
//        finish();
//        super.onBackPressed();
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UploadReceiptActivity extends AppCompatActivity {

    private Button btnBackToDonations, btnUpload, btnSelectFile;
    private EditText etDonationId, etPurpose, etRemarks, etAmountDonated, etAmountUsed, etItemDescription, etQuantity;
    private TextView tvSelectedFileName;
    private PrefManager prefManager;
    private ApiService apiService;

    private int donationId;
    private int volunteerId;
    private int userId;

    private Uri fileUri;
    private static final int PICK_FILE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload_receipt_volunteer);

        prefManager = new PrefManager(this);
        apiService = ApiClient.getClient().create(ApiService.class);

        // Initialize views
        initViews();

        // Get the donation ID passed from DonationListActivity_volunteer
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("donation_id")) {
            donationId = intent.getIntExtra("donation_id", -1);
            etDonationId.setText(String.valueOf(donationId));
            etDonationId.setEnabled(false);
        }

        // Get volunteer ID and user ID from shared preferences
        volunteerId = prefManager.getVolunteerId();
        userId = prefManager.getUserId();

        // Set up button listeners
        btnSelectFile.setOnClickListener(v -> selectFile());
        btnUpload.setOnClickListener(v -> uploadReceipt());

        btnBackToDonations.setOnClickListener(v -> {
            Intent backIntent = new Intent(UploadReceiptActivity.this, DonationListActivity_volunteer.class);
            startActivity(backIntent);
            finish();
        });
    }

    private void initViews() {
        btnBackToDonations = findViewById(R.id.btnBackToDonations);
        btnUpload = findViewById(R.id.btnUpload);
        btnSelectFile = findViewById(R.id.btnSelectFile);
        etDonationId = findViewById(R.id.etDonationId);
        etPurpose = findViewById(R.id.etPurpose);
        etRemarks = findViewById(R.id.etRemarks);
        etAmountDonated = findViewById(R.id.etAmountDonated);
        etAmountUsed = findViewById(R.id.etAmountUsed);
        etItemDescription = findViewById(R.id.etItemDescription);
        etQuantity = findViewById(R.id.etQuantity);
        tvSelectedFileName = findViewById(R.id.tvSelectedFileName);
    }

    private void selectFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Select Proof Image"), PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK && data != null) {
            fileUri = data.getData();
            if (fileUri != null) {
                String fileName = getFileNameFromUri(fileUri);
                tvSelectedFileName.setText(fileName);
            }
        }
    }

    private String getFileNameFromUri(Uri uri) {
        String result = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int displayNameIndex = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
                    if (displayNameIndex != -1) {
                        result = cursor.getString(displayNameIndex);
                    }
                }
            } catch (Exception e) {
                Log.e("UploadError", "Error getting file name: " + e.getMessage());
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }

    private String getRealPathFromURI(Uri uri) {
        String path = null;
        try {
            // Try to get the path using ContentResolver
            String[] projection = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(uri, projection, null, null, null);

            if (cursor != null && cursor.moveToFirst()) {
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                path = cursor.getString(column_index);
                cursor.close();
            }

            // If still null, try to get the path from the URI directly
            if (path == null) {
                path = uri.getPath();
            }
        } catch (Exception e) {
            Log.e("UploadError", "Error getting file path: " + e.getMessage());
            path = uri.getPath(); // Fallback to URI path
        }
        return path;
    }

private void uploadReceipt() {
        String purpose = etPurpose.getText().toString().trim();
        String remarks = etRemarks.getText().toString().trim();
        String amountDonatedStr = etAmountDonated.getText().toString().trim();
        String amountUsedStr = etAmountUsed.getText().toString().trim();
        String itemDescription = etItemDescription.getText().toString().trim();
        String quantityStr = etQuantity.getText().toString().trim();

        // Validate required fields
        if (purpose.isEmpty()) {
            etPurpose.setError("Purpose is required");
            etPurpose.requestFocus();
            return;
        }

        if (fileUri == null) {
            Toast.makeText(this, "Please select a proof image", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse numeric values
        double amountDonated = 0;
        double amountUsed = 0;
        int quantity = 0;

        try {
            if (!amountDonatedStr.isEmpty()) amountDonated = Double.parseDouble(amountDonatedStr);
            if (!amountUsedStr.isEmpty()) amountUsed = Double.parseDouble(amountUsedStr);
            if (!quantityStr.isEmpty()) quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numeric values", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create RequestBody objects for text fields
        // NOTE: We're NOT sending user_id anymore - PHP will get it from the donation
        RequestBody donationIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(donationId));
        RequestBody volunteerIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(volunteerId));
        RequestBody purposeBody = RequestBody.create(MediaType.parse("text/plain"), purpose);
        RequestBody remarksBody = RequestBody.create(MediaType.parse("text/plain"), remarks);
        RequestBody amountDonatedBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(amountDonated));
        RequestBody amountUsedBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(amountUsed));
        RequestBody itemDescriptionBody = RequestBody.create(MediaType.parse("text/plain"), itemDescription);
        RequestBody quantityBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(quantity));

        // Prepare file for upload
        MultipartBody.Part filePart;
        try {
            String filePath = getRealPathFromURI(fileUri);
            if (filePath == null) {
                Toast.makeText(this, "Could not get file path", Toast.LENGTH_SHORT).show();
                return;
            }

            File file = new File(filePath);
            if (!file.exists()) {
                Toast.makeText(this, "File does not exist", Toast.LENGTH_SHORT).show();
                return;
            }

            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
            filePart = MultipartBody.Part.createFormData("receipt_file", file.getName(), requestFile);
        } catch (Exception e) {
            Toast.makeText(this, "Error preparing file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading
        btnUpload.setEnabled(false);
        btnUpload.setText("Uploading...");

        // Make API call - NOTE: We're NOT sending user_id anymore
        Call<UploadResponse> call = apiService.uploadReceipt(
                donationIdBody, volunteerIdBody, purposeBody, remarksBody,
                amountDonatedBody, amountUsedBody, itemDescriptionBody, quantityBody,
                filePart
        );

        call.enqueue(new Callback<UploadResponse>() {
            @Override
            public void onResponse(Call<UploadResponse> call, Response<UploadResponse> response) {
                btnUpload.setEnabled(true);
                btnUpload.setText("Upload Receipt");

                if (response.isSuccessful() && response.body() != null) {
                    UploadResponse uploadResponse = response.body();
                    if ("success".equals(uploadResponse.getStatus())) {
                        Toast.makeText(UploadReceiptActivity.this, uploadResponse.getMessage(), Toast.LENGTH_SHORT).show();

                        // Navigate back to donations list
                        Intent intent = new Intent(UploadReceiptActivity.this, DonationListActivity_volunteer.class);
                        startActivity(intent);
                        finish();
                    } else {
                        // Show specific error message from server
                        String errorMessage = uploadResponse.getMessage();
                        Toast.makeText(UploadReceiptActivity.this, errorMessage, Toast.LENGTH_LONG).show();

                        // Log the error for debugging
                        Log.e("UploadError", "Server error: " + errorMessage);
                    }
                } else {
                    // Handle non-JSON response or server errors
                    try {
                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
                        Log.e("UploadError", "Server response: " + errorBody);

                        if (errorBody.contains("foreign key") || errorBody.contains("constraint")) {
                            Toast.makeText(UploadReceiptActivity.this, "Database error: Invalid IDs detected. Please contact administrator.", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(UploadReceiptActivity.this, "Server error: " + response.code(), Toast.LENGTH_SHORT).show();
                        }
                    } catch (IOException e) {
                        Toast.makeText(UploadReceiptActivity.this, "Upload failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<UploadResponse> call, Throwable t) {
                btnUpload.setEnabled(true);
                btnUpload.setText("Upload Receipt");
                Log.e("UploadError", "Network error: " + t.getMessage());
                Toast.makeText(UploadReceiptActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, DonationListActivity_volunteer.class);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }
}