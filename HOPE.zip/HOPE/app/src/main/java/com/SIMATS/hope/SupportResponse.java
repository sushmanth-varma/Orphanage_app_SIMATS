package com.SIMATS.hope;

public class SupportResponse {
    private String status;
    private String message;
    private int support_id;

    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public int getSupportId() { return support_id; }
}