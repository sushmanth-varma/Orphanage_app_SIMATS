package com.SIMATS.hope;

public class Orphanage {
    private int id;
    private String name;
    private String address;
    private String city;
    private String phone; // Make sure this field exists
    private double distance;

    public int getId() { return id; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getCity() { return city; }
    public String getPhone() { return phone; } // Ensure getter exists
    public double getDistance() { return distance; }

    public void setDistance(double distance) { this.distance = distance; }

    public String getDisplayText() {
        return name + " - " + address;
    }

    public boolean hasPhoneNumber() {
        return phone != null && !phone.trim().isEmpty();
    }
}