package com.SIMATS.hope;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReportAdapter_Admin extends RecyclerView.Adapter<ReportAdapter_Admin.ReportViewHolder> {

    private final ArrayList<ReportModel_Admin> reports;
    private final Context context;
    private final ApiService apiService;

    public ReportAdapter_Admin(ArrayList<ReportModel_Admin> reports, Context context) {
        this.reports = reports;
        this.context = context;
        this.apiService = ApiClient.getClient().create(ApiService.class);
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.report_item_layout, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        ReportModel_Admin report = reports.get(position);
        bindReportData(holder, report);
        setupAssignButton(holder, report);
    }

    private void bindReportData(ReportViewHolder holder, ReportModel_Admin report) {
        holder.textViewReportId.setText("Report ID: " + report.getId());
        holder.textViewType.setText("Type: " + report.getType());
        holder.textViewName.setText(getNameText(report));
        holder.textViewLocation.setText("Location: " + report.getGeneralLocation());
        holder.textViewStatus.setText("Status: " + report.getStatus());
        holder.textViewVolunteer.setText(getVolunteerText(report));
        holder.buttonAssignVolunteer.setVisibility(
                (report.getVolunteerName() != null && !report.getVolunteerName().isEmpty())
                        ? View.GONE : View.VISIBLE);
    }

    private String getNameText(ReportModel_Admin report) {
        return "1".equals(report.getIsAnonymous())
                ? "Name: Anonymous (Age: " + report.getAge() + ")"
                : "Name: " + report.getName() + " (Age: " + report.getAge() + ")";
    }

    private String getVolunteerText(ReportModel_Admin report) {
        return (report.getVolunteerName() != null && !report.getVolunteerName().isEmpty())
                ? "Assigned To: " + report.getVolunteerName()
                : "Not assigned";
    }

    private void setupAssignButton(ReportViewHolder holder, ReportModel_Admin report) {
        holder.buttonAssignVolunteer.setOnClickListener(v ->
                showAssignmentDialog(report.getId()));
    }

    private void showAssignmentDialog(String reportId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Assign Volunteer");
        builder.setMessage("Enter Volunteer ID:");

        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(input);

        builder.setPositiveButton("Assign", (dialog, which) ->
                handleVolunteerAssignment(input.getText().toString().trim(), reportId));
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void handleVolunteerAssignment(String volunteerIdStr, String reportId) {
        if (volunteerIdStr.isEmpty()) {
            Toast.makeText(context, "Please enter Volunteer ID", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int volunteerId = Integer.parseInt(volunteerIdStr);
            assignVolunteer(reportId, volunteerId);
        } catch (NumberFormatException e) {
            Toast.makeText(context, "Please enter a valid Volunteer ID", Toast.LENGTH_SHORT).show();
        }
    }

    private void assignVolunteer(String reportId, int volunteerId) {
        AssignVolunteerRequest request = new AssignVolunteerRequest(
                Integer.parseInt(reportId), volunteerId);

        apiService.assignVolunteer(request).enqueue(new Callback<AssignVolunteerResponse>() {
            @Override
            public void onResponse(Call<AssignVolunteerResponse> call,
                                   Response<AssignVolunteerResponse> response) {
                handleAssignmentResponse(response);
            }

            @Override
            public void onFailure(Call<AssignVolunteerResponse> call, Throwable t) {
                Toast.makeText(context, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleAssignmentResponse(Response<AssignVolunteerResponse> response) {
        if (response.isSuccessful() && response.body() != null) {
            AssignVolunteerResponse apiResponse = response.body();
            if (apiResponse.isSuccess()) {
                Toast.makeText(context, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                refreshActivity();
            } else {
                String errorMsg = apiResponse.getMessage();
                if (apiResponse.getError() != null) {
                    errorMsg += "\n" + apiResponse.getError();
                }
                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(context, "Assignment failed", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshActivity() {
        if (context instanceof AdminViewAllReportsActivity) {
            ((AdminViewAllReportsActivity) context).refreshAfterAssignment();
        }
    }

    @Override
    public int getItemCount() {
        return reports.size();
    }

    static class ReportViewHolder extends RecyclerView.ViewHolder {
        final TextView textViewReportId;
        final TextView textViewType;
        final TextView textViewName;
        final TextView textViewLocation;
        final TextView textViewStatus;
        final TextView textViewVolunteer;
        final Button buttonAssignVolunteer;

        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewReportId = itemView.findViewById(R.id.textViewReportId);
            textViewType = itemView.findViewById(R.id.textViewType);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewLocation = itemView.findViewById(R.id.textViewLocation);
            textViewStatus = itemView.findViewById(R.id.textViewStatus);
            textViewVolunteer = itemView.findViewById(R.id.textViewVolunteer);
            buttonAssignVolunteer = itemView.findViewById(R.id.buttonAssignVolunteer);
        }
    }
}