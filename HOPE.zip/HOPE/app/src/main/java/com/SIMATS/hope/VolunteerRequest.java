// VolunteerRequest.java
package com.SIMATS.hope;

public class VolunteerRequest {
    private String full_name;
    private String email;
    private String phone;
    private String place;
    private String reason;

    public VolunteerRequest(String full_name, String email, String phone, String place, String reason) {
        this.full_name = full_name;
        this.email = email;
        this.phone = phone;
        this.place = place;
        this.reason = reason;
    }

    // Getters and setters
    public String getFull_name() { return full_name; }
    public void setFull_name(String full_name) { this.full_name = full_name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getPlace() { return place; }
    public void setPlace(String place) { this.place = place; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}