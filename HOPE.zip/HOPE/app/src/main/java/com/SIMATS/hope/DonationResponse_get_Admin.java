package com.SIMATS.hope;

import java.util.List;

public class DonationResponse_get_Admin {
    private String status;
    private List<Donation_get_Admin> donations;

    public String getStatus() { return status; }
    public List<Donation_get_Admin> getDonations() { return donations; }
}