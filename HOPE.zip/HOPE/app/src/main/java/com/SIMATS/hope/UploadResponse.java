package com.SIMATS.hope;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.SerializedName;

public class UploadResponse {
    @SerializedName("status")
    private String status;

    @SerializedName("message")
    private String message;

    @SerializedName("data")
    private JsonElement data; // Use JsonElement to handle both object and array

    // Getters and setters
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public JsonElement getData() { return data; }
    public void setData(JsonElement data) { this.data = data; }

    // Helper method to extract receipt ID
    public int getReceiptId() {
        if (data != null && data.isJsonObject()) {
            JsonObject dataObject = data.getAsJsonObject();
            if (dataObject.has("receipt_id")) {
                return dataObject.get("receipt_id").getAsInt();
            }
        } else if (data != null && data.isJsonArray()) {
            JsonArray dataArray = data.getAsJsonArray();
            if (dataArray.size() > 0) {
                JsonObject firstItem = dataArray.get(0).getAsJsonObject();
                if (firstItem.has("receipt_id")) {
                    return firstItem.get("receipt_id").getAsInt();
                }
            }
        }
        return -1;
    }

    // Helper method to extract proof URL
    public String getProofUrl() {
        if (data != null && data.isJsonObject()) {
            JsonObject dataObject = data.getAsJsonObject();
            if (dataObject.has("proof_url")) {
                return dataObject.get("proof_url").getAsString();
            }
        } else if (data != null && data.isJsonArray()) {
            JsonArray dataArray = data.getAsJsonArray();
            if (dataArray.size() > 0) {
                JsonObject firstItem = dataArray.get(0).getAsJsonObject();
                if (firstItem.has("proof_url")) {
                    return firstItem.get("proof_url").getAsString();
                }
            }
        }
        return null;
    }
}