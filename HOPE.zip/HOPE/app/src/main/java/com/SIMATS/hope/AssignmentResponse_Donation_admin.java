package com.SIMATS.hope;

public class AssignmentResponse_Donation_admin {
    private String status;
    private String message;

    // Getters
    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}