package com.SIMATS.hope;

public class Donation_Volunteer {
    private int id;
    private String type;
    private String cause;
    private String description;
    private int quantity;
    private String status;
    private String date;

    // Constructor and getters remain the same
    public Donation_Volunteer(int id, String type, String cause, String description,
                    int quantity, String status, String date) {
        this.id = id;
        this.type = type;
        this.cause = cause;
        this.description = description;
        this.quantity = quantity;
        this.status = status;
        this.date = date;
    }

    // Getters
    public int getId() { return id; }
    public String getType() { return type; }
    public String getCause() { return cause; }
    public String getDescription() { return description; }
    public int getQuantity() { return quantity; }
    public String getStatus() { return status; }
    public String getDate() { return date; }
}