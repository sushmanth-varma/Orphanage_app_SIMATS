//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//import androidx.appcompat.app.AppCompatActivity;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class VolunteerActivity extends AppCompatActivity {
//
//    EditText editName, editEmail, editPhone, editPlace, editReason, editOtp;
//    Button btnSendOtp, btnVerifyOtp, btnSubmit;
//    ApiService apiService;
//    String generatedOtp;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_volunteer_request); // Use your OTP layout
//
//        // Initialize views - make sure these match your XML IDs
//        editName = findViewById(R.id.fullName);
//        editEmail = findViewById(R.id.email);
//        editPhone = findViewById(R.id.phone);
//        editPlace = findViewById(R.id.place);
//        editReason = findViewById(R.id.reason);
//        btnSendOtp = findViewById(R.id.sendOtpBtn);
//        btnSubmit = findViewById(R.id.submitBtn);
//
//        // Initially hide OTP and submit sections
//        editOtp.setVisibility(View.GONE);
//        btnVerifyOtp.setVisibility(View.GONE);
//        btnSubmit.setVisibility(View.GONE);
//
//        apiService = ApiClient.getClient().create(ApiService.class);
//
//        btnSendOtp.setOnClickListener(v -> {
//            String name = editName.getText().toString().trim();
//            String mail = editEmail.getText().toString().trim();
//            String ph = editPhone.getText().toString().trim();
//            String userPlace = editPlace.getText().toString().trim();
//            String why = editReason.getText().toString().trim();
//
//            if (name.isEmpty() || mail.isEmpty() || ph.isEmpty() || userPlace.isEmpty() || why.isEmpty()) {
//                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
//            } else {
//                // Send only phone number for OTP request
//                requestOtp(ph);
//            }
//        });
//
//        btnVerifyOtp.setOnClickListener(v -> {
//            String enteredOtp = editOtp.getText().toString().trim();
//            if (enteredOtp.isEmpty() || enteredOtp.length() != 6) {
//                Toast.makeText(this, "Please enter valid 6-digit OTP", Toast.LENGTH_SHORT).show();
//            } else {
//                verifyOtp(enteredOtp);
//            }
//        });
//
//        btnSubmit.setOnClickListener(v -> {
//            submitVolunteerData();
//        });
//    }
//
//    private void requestOtp(String phoneNumber) {
//        // Create request with only phone number
//        VolunteerRequest otpRequest = new VolunteerRequest(phoneNumber);
//        Call<Volunteer_OtpResponse> call = apiService.requestOtp(otpRequest);
//
//        call.enqueue(new Callback<Volunteer_OtpResponse>() {
//            @Override
//            public void onResponse(Call<Volunteer_OtpResponse> call, Response<Volunteer_OtpResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    Volunteer_OtpResponse otpResponse = response.body();
//                    if ("otp_required".equals(otpResponse.getStatus())) {
//                        generatedOtp = otpResponse.getOtp();
//                        Toast.makeText(VolunteerActivity.this,
//                                "OTP sent: " + generatedOtp, Toast.LENGTH_LONG).show();
//
//                        // Show OTP fields
//                        editOtp.setVisibility(View.VISIBLE);
//                        btnVerifyOtp.setVisibility(View.VISIBLE);
//                        btnSendOtp.setEnabled(false);
//                    } else {
//                        Toast.makeText(VolunteerActivity.this,
//                                "Error: " + otpResponse.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Toast.makeText(VolunteerActivity.this,
//                            "Failed to send OTP", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<Volunteer_OtpResponse> call, Throwable t) {
//                Toast.makeText(VolunteerActivity.this,
//                        "Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        });
//    }
//
//    private void verifyOtp(String enteredOtp) {
//        if (enteredOtp.equals(generatedOtp)) {
//            Toast.makeText(this, "OTP verified successfully!", Toast.LENGTH_SHORT).show();
//            btnSubmit.setVisibility(View.VISIBLE);
//            btnVerifyOtp.setEnabled(false);
//            editOtp.setEnabled(false);
//        } else {
//            Toast.makeText(this, "Invalid OTP. Please try again.", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private void submitVolunteerData() {
//        String name = editName.getText().toString().trim();
//        String mail = editEmail.getText().toString().trim();
//        String ph = editPhone.getText().toString().trim();
//        String userPlace = editPlace.getText().toString().trim();
//        String why = editReason.getText().toString().trim();
//        String otp = editOtp.getText().toString().trim();
//
//        if (name.isEmpty() || mail.isEmpty() || ph.isEmpty() ||
//                userPlace.isEmpty() || why.isEmpty() || otp.isEmpty()) {
//            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        VolunteerRequest request = new VolunteerRequest(name, mail, ph, userPlace, why, otp);
//        Call<VolunteerResponse> call = apiService.submitVolunteerRequest(request);
//
//        call.enqueue(new Callback<VolunteerResponse>() {
//            @Override
//            public void onResponse(Call<VolunteerResponse> call, Response<VolunteerResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    VolunteerResponse volunteerResponse = response.body();
//                    if (volunteerResponse.isSuccess()) {
//                        Intent intent = new Intent(VolunteerActivity.this,
//                                VolunteerSuccessActivity.class);
//                        startActivity(intent);
//                        finish();
//                    } else {
//                        Toast.makeText(VolunteerActivity.this,
//                                "Failed: " + volunteerResponse.getMessage(), Toast.LENGTH_LONG).show();
//                    }
//                } else {
//                    Toast.makeText(VolunteerActivity.this,
//                            "Submission failed", Toast.LENGTH_LONG).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<VolunteerResponse> call, Throwable t) {
//                Toast.makeText(VolunteerActivity.this,
//                        "Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        });
//    }
//}