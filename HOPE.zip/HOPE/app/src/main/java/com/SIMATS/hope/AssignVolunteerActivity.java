package com.SIMATS.hope;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AssignVolunteerActivity extends AppCompatActivity {

    private EditText reportIdInput, volunteerIdInput;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_volunteer);

        // Initialize UI components
//        reportIdInput = findViewById(R.id.reportIdInput);
//        volunteerIdInput = findViewById(R.id.volunteerIdInput);
//        submitButton = findViewById(R.id.submitButton);

        // Set button click listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleAssignment();
            }
        });
    }

    private void handleAssignment() {
        // Get input values
        String reportIdStr = reportIdInput.getText().toString().trim();
        String volunteerIdStr = volunteerIdInput.getText().toString().trim();

        // Validate inputs
        if (reportIdStr.isEmpty() || volunteerIdStr.isEmpty()) {
            showToast("Please enter both Report ID and Volunteer ID");
            return;
        }

        try {
            // Parse IDs
            int reportId = Integer.parseInt(reportIdStr);
            int volunteerId = Integer.parseInt(volunteerIdStr);

            // Here you would normally call your API
            // For demonstration, we'll just show a success message
            showToast("Assigning Volunteer " + volunteerId + " to Report " + reportId);

            // Simulate successful assignment
            showToast("Assignment successful!");
            finish(); // Close the activity

        } catch (NumberFormatException e) {
            showToast("Please enter valid numbers for IDs");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}