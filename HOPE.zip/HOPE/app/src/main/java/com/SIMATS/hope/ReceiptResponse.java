package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class ReceiptResponse {
    @SerializedName("status")
    private String status;

    @SerializedName("message")
    private String message;

    @SerializedName("receipt_id")
    private int receiptId;

    @SerializedName("proof_url")
    private String proofUrl;

    @SerializedName("pdf_url")
    private String pdfUrl;

    public boolean isSuccess() {
        return "success".equals(status);
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public int getReceiptId() {
        return receiptId;
    }

    public String getProofUrl() {
        return proofUrl;
    }

    public String getPdfUrl() {
        return pdfUrl;
    }
}