package com.SIMATS.hope;
public class Report {
    public String type;
    public String name;
    public String age;
    public String city;
    public String details;
    public boolean anonymous;
    public String timestamp;

    public Report() {
        // Default constructor required for Firebase and deserialization
    }

    public Report(String type, String name, String age, String city, String details, boolean anonymous, String timestamp) {
        this.type = type;
        this.name = name;
        this.age = age;
        this.city = city;
        this.details = details;
        this.anonymous = anonymous;
        this.timestamp = timestamp;
    }
}
