package com.SIMATS.hope;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UpdateReportStatusActivity_Volunteer extends AppCompatActivity {

    private EditText edtReportId;
    private Spinner spinnerStatus;
    private Button btnSubmit;
    private ApiService apiService;

    private PrefManager prefManager;
    private int volunteerId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_report_status_volunteer);

        edtReportId = findViewById(R.id.edtReportId);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        btnSubmit = findViewById(R.id.btnSubmitStatus);

        // Initialize PrefManager
        prefManager = new PrefManager(this);
        volunteerId = prefManager.getVolunteerId();

        if (volunteerId == -1) {
            Toast.makeText(this, "Volunteer not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Spinner setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.report_status_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(adapter);

        // Retrofit initialization
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/") // Replace with your base URL
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(ApiService.class);

        btnSubmit.setOnClickListener(v -> updateStatus());
    }

    private void updateStatus() {
        String reportIdStr = edtReportId.getText().toString().trim();
        String selectedStatus = spinnerStatus.getSelectedItem().toString();

        if (reportIdStr.isEmpty() || selectedStatus.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int reportId = Integer.parseInt(reportIdStr);

            // Send volunteer_id as well
            UpdateStatusRequest_Volunteer request =
                    new UpdateStatusRequest_Volunteer(reportId, selectedStatus, volunteerId);

            Call<UpdateStatusResponse_Volunteer> call = apiService.updateReportStatus_Volunteer(request);
            call.enqueue(new Callback<UpdateStatusResponse_Volunteer>() {
                @Override
                public void onResponse(Call<UpdateStatusResponse_Volunteer> call, Response<UpdateStatusResponse_Volunteer> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        Toast.makeText(UpdateReportStatusActivity_Volunteer.this,
                                response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    } else {
                        try {
                            String errorBody = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
                            Log.e("SERVER_ERROR", errorBody);
                            Toast.makeText(UpdateReportStatusActivity_Volunteer.this,
                                    "Server error: " + errorBody, Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(UpdateReportStatusActivity_Volunteer.this,
                                    "Server error (no details)", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                @Override
                public void onFailure(Call<UpdateStatusResponse_Volunteer> call, Throwable t) {
                    Toast.makeText(UpdateReportStatusActivity_Volunteer.this,
                            "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("NETWORK_ERROR", t.getMessage(), t);
                }
            });

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid Report ID", Toast.LENGTH_SHORT).show();
        }
    }
}
