package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;

public class ApiResponseAssignedReports {
    @SerializedName("status")
    private String status;

    @SerializedName("message")  // Add this annotation
    private String message;

    @SerializedName("data")
    private ArrayList<AssignedReport_Volunteer> data;

    public String getStatus() {
        return status;
    }

    // Add this getter method
    public String getMessage() {
        return message;
    }

    public ArrayList<AssignedReport_Volunteer> getData() {
        return data;
    }

    public boolean isSuccess() {
        return "success".equals(status);
    }
}