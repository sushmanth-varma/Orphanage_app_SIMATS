package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class AssignedReport_Volunteer {
    @SerializedName("id") public String id;
    @SerializedName("type") public String type;
    @SerializedName("name") public String name;
    @SerializedName("age") public String age;
    @SerializedName("generalLocation") public String generalLocation;
    @SerializedName("exactLocation") public String exactLocation;
    @SerializedName("details") public String details;
    @SerializedName("status") public String status;
    @SerializedName("isAnonymous") public String isAnonymous;
    @SerializedName("volunteerName") public String volunteerName;
    @SerializedName("volunteerPhone") public String volunteerPhone;
    @SerializedName("photoPath") public String photoPath;

    public boolean hasValidCoordinates() {
        if (exactLocation == null || exactLocation.isEmpty()) return false;

        String[] parts = exactLocation.split(",");
        if (parts.length != 2) return false;

        try {
            Double.parseDouble(parts[0].trim());
            Double.parseDouble(parts[1].trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public double[] getCoordinates() {
        if (!hasValidCoordinates()) return null;

        String[] parts = exactLocation.split(",");
        return new double[]{
                Double.parseDouble(parts[0].trim()),
                Double.parseDouble(parts[1].trim())
        };
    }

    public String getFormattedCoordinates() {
        return hasValidCoordinates() ? exactLocation.replace(",", ", ") : "No coordinates";
    }

    public String getFormattedId() {
        return "ID: " + (id != null ? id : "N/A");
    }
}