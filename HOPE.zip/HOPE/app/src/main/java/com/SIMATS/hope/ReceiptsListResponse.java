package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class ReceiptsListResponse {
    @SerializedName("success")
    private boolean success;

    @SerializedName("message")
    private String message;

    @SerializedName("receipts")
    private List<ReceiptModel> receipts;

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public List<ReceiptModel> getReceipts() { return receipts; }
}
