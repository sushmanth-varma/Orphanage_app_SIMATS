package com.SIMATS.hope;

import android.content.BroadcastReceiver;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReceiptsActivity extends AppCompatActivity {

    private TextView ivBack;
    private RecyclerView rvReceipts;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ReceiptAdapter receiptAdapter;
    private int userId;

    private BroadcastReceiver refreshReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_recipts_users);

        initializeViews();
        setupRecyclerView();
        setupSwipeRefresh();

        Log.d("ReceiptsActivity", "Activity created");

        ivBack.setOnClickListener(v -> {
            Log.d("ReceiptsActivity", "Back button clicked, finishing activity");
            finish();
        });

        loadReceipts();

    }

    private void initializeViews() {
        ivBack = findViewById(R.id.ivBack);
        rvReceipts = findViewById(R.id.rvReceipts);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty = findViewById(R.id.tvEmpty);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        Log.d("ReceiptsActivity", "Views initialized");
    }

    private void setupRecyclerView() {
        rvReceipts.setLayoutManager(new LinearLayoutManager(this));
        receiptAdapter = new ReceiptAdapter(this, new ArrayList<>());
        rvReceipts.setAdapter(receiptAdapter);
    }

    private void setupSwipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(() -> {
            Log.d("ReceiptsActivity", "Swipe to refresh triggered");
            loadReceipts();
        });
    }

    private void loadReceipts() {
        progressBar.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);
        swipeRefreshLayout.setRefreshing(true);

        // Get user_id from PrefManager instead of SharedPreferences
        PrefManager prefManager = new PrefManager(this);
        userId = prefManager.getUserId();

        if (userId == 0) {
            progressBar.setVisibility(View.GONE);
            swipeRefreshLayout.setRefreshing(false);
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Please login to view receipts");
            return;
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ReceiptsListResponse> call = apiService.getUserReceipts(userId); // Use ReceiptListResponse

        call.enqueue(new Callback<ReceiptsListResponse>() {
            @Override
            public void onResponse(Call<ReceiptsListResponse> call, Response<ReceiptsListResponse> response) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);

                if (response.isSuccessful() && response.body() != null) {
                    ReceiptsListResponse apiResponse = response.body(); // Use ReceiptListResponse

                    if (apiResponse.isSuccess() && apiResponse.getReceipts() != null) {
                        if (!apiResponse.getReceipts().isEmpty()) {
                            receiptAdapter.updateList(apiResponse.getReceipts());
                            tvEmpty.setVisibility(View.GONE);
                            Log.d("ReceiptsActivity", "Loaded " + apiResponse.getReceipts().size() + " receipts");
                        } else {
                            tvEmpty.setVisibility(View.VISIBLE);
                            tvEmpty.setText("No receipts found");
                            Log.d("ReceiptsActivity", "No receipts found for user: " + userId);
                        }
                    } else {
                        tvEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText(apiResponse.getMessage() != null ?
                                apiResponse.getMessage() : "Failed to load receipts");
                        Log.e("ReceiptsActivity", "API response not successful: " + apiResponse.getMessage());
                    }
                } else {
                    tvEmpty.setVisibility(View.VISIBLE);
                    String errorMessage = "Server error: " + response.code();
                    if (response.errorBody() != null) {
                        try {
                            errorMessage += " - " + response.errorBody().string();
                        } catch (Exception e) {
                            errorMessage += " - Error reading response";
                        }
                    }
                    tvEmpty.setText(errorMessage);
                    Log.e("ReceiptsActivity", errorMessage);
                }
            }

            @Override
            public void onFailure(Call<ReceiptsListResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefreshLayout.setRefreshing(false);
                tvEmpty.setVisibility(View.VISIBLE);
                String errorMessage = "Network error: " + t.getMessage();
                tvEmpty.setText(errorMessage);
                Log.e("ReceiptsActivity", errorMessage);
                t.printStackTrace();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ReceiptsActivity", "Activity resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("ReceiptsActivity", "Activity paused");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("ReceiptsActivity", "Activity destroyed");
    }
}