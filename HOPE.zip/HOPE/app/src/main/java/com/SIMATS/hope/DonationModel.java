//package com.SIMATS.hope;
//
//import com.google.gson.annotations.SerializedName;
//
//public class DonationModel {
//
//    @SerializedName("id")
//    private int id;
//
//    @SerializedName("donation_type")
//    private String donationType;
//
//    @SerializedName("orphanage_confirmation")
//    private String orphanageConfirmation;
//    @SerializedName("donor_name")
//    private String donorName;
//
//    @SerializedName("donor_contact")
//    private String donorContact;
//
//    @SerializedName("donor_email")
//    private String donorEmail;
//    @SerializedName("cause")
//    private String cause;
//
//    @SerializedName("amount_donated")
//    private String amountDonated;
//
//    @SerializedName("amount_used")
//    private String amountUsed;
//
//    @SerializedName("item_description")
//    private String itemDescription;
//
//    @SerializedName("quantity")
//    private int quantity;
//
//    @SerializedName("purpose")
//    private String purpose;
//
//    @SerializedName("remarks")
//    private String remarks;
//
//    @SerializedName("orphanage_name")
//    private String orphanageName;
//
//    @SerializedName("volunteer_name")
//    private String volunteerName;
//
//    @SerializedName("collected_at")
//    private String collectedAt;
//
//    @SerializedName("created_at")
//    private String createdAt;
//
//    @SerializedName("proof_url")
//    private String proofUrl;
//
//
//    // Getters and Setters
//    public int getId() {
//        return id;
//    }
//    public String getDonorName() {
//        return donorName;
//    }
//
//    public void setDonorName(String donorName) {
//        this.donorName = donorName;
//    }
//
//    public String getDonorContact() {
//        return donorContact;
//    }
//
//    public void setDonorContact(String donorContact) {
//        this.donorContact = donorContact;
//    }
//
//    public String getDonorEmail() {
//        return donorEmail;
//    }
//
//    public void setDonorEmail(String donorEmail) {
//        this.donorEmail = donorEmail;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }
//
//    public String getDonationType() {
//        return donationType;
//    }
//
//    public void setDonationType(String donationType) {
//        this.donationType = donationType;
//    }
//
//    public String getOrphanageConfirmation() {
//        return orphanageConfirmation;
//    }
//
//    public void setOrphanageConfirmation(String orphanageConfirmation) {
//        this.orphanageConfirmation = orphanageConfirmation;
//    }
//
//    public String getCause() {
//        return cause;
//    }
//
//    public void setCause(String cause) {
//        this.cause = cause;
//    }
//
//    public String getAmountDonated() {
//        return amountDonated;
//    }
//
//    public void setAmountDonated(String amountDonated) {
//        this.amountDonated = amountDonated;
//    }
//
//    public String getAmountUsed() {
//        return amountUsed;
//    }
//
//    public void setAmountUsed(String amountUsed) {
//        this.amountUsed = amountUsed;
//    }
//
//    public String getItemDescription() {
//        return itemDescription;
//    }
//
//    public void setItemDescription(String itemDescription) {
//        this.itemDescription = itemDescription;
//    }
//
//    public int getQuantity() {
//        return quantity;
//    }
//
//    public void setQuantity(int quantity) {
//        this.quantity = quantity;
//    }
//
//    public String getPurpose() {
//        return purpose;
//    }
//
//    public void setPurpose(String purpose) {
//        this.purpose = purpose;
//    }
//
//    public String getRemarks() {
//        return remarks;
//    }
//
//    public void setRemarks(String remarks) {
//        this.remarks = remarks;
//    }
//
//    public String getOrphanageName() {
//        return orphanageName;
//    }
//
//    public void setOrphanageName(String orphanageName) {
//        this.orphanageName = orphanageName;
//    }
//
//    public String getVolunteerName() {
//        return volunteerName;
//    }
//
//    public void setVolunteerName(String volunteerName) {
//        this.volunteerName = volunteerName;
//    }
//
//    public String getCollectedAt() {
//        return collectedAt;
//    }
//
//    public void setCollectedAt(String collectedAt) {
//        this.collectedAt = collectedAt;
//    }
//
//    public String getCreatedAt() {
//        return createdAt;
//    }
//
//    public void setCreatedAt(String createdAt) {
//        this.createdAt = createdAt;
//    }
//
//    public String getProofUrl() {
//        return proofUrl;
//    }
//
//    public void setProofUrl(String proofUrl) {
//        this.proofUrl = proofUrl;
//    }
//
//}
package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class DonationModel {

    @SerializedName("id")
    private int id;

    @SerializedName("donation_type")
    private String donationType;

    @SerializedName("status") // Changed from orphanage_confirmation to status
    private String status;

    @SerializedName("full_name") // Changed from donor_name to full_name
    private String fullName;

    @SerializedName("phone") // Changed from donor_contact to phone
    private String phone;

    @SerializedName("email") // Changed from donor_email to email
    private String email;

    @SerializedName("cause")
    private String cause;

    @SerializedName("amount") // Changed from amount_donated to amount
    private String amount;

    @SerializedName("amount_used")
    private String amountUsed;

    @SerializedName("item_description")
    private String itemDescription;

    @SerializedName("quantity")
    private int quantity;

    @SerializedName("purpose")
    private String purpose;

    @SerializedName("remarks")
    private String remarks;

    @SerializedName("orphanage_name")
    private String orphanageName;

    @SerializedName("volunteer_name")
    private String volunteerName;

    @SerializedName("collected_at")
    private String collectedAt;

    @SerializedName("created_at")
    private String createdAt;

    @SerializedName("proof_url")
    private String proofUrl;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDonationType() {
        return donationType;
    }

    public void setDonationType(String donationType) {
        this.donationType = donationType;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getAmountUsed() {
        return amountUsed;
    }

    public void setAmountUsed(String amountUsed) {
        this.amountUsed = amountUsed;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getOrphanageName() {
        return orphanageName;
    }

    public void setOrphanageName(String orphanageName) {
        this.orphanageName = orphanageName;
    }

    public String getVolunteerName() {
        return volunteerName;
    }

    public void setVolunteerName(String volunteerName) {
        this.volunteerName = volunteerName;
    }

    public String getCollectedAt() {
        return collectedAt;
    }

    public void setCollectedAt(String collectedAt) {
        this.collectedAt = collectedAt;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getProofUrl() {
        return proofUrl;
    }

    public void setProofUrl(String proofUrl) {
        this.proofUrl = proofUrl;
    }
}