package com.SIMATS.hope;

public class UpdateStatusRequest_donation {
    private int donation_id;
    private String status;

    public UpdateStatusRequest_donation(int donation_id, String status) {
        this.donation_id = donation_id;
        this.status = status;
    }
}