package com.SIMATS.hope;

public class StatusUpdateRequest_Volunteer {
    private int donation_id;
    private String status;
    private int volunteer_id;

    public StatusUpdateRequest_Volunteer(int donation_id, String status, int volunteer_id) {
        this.donation_id = donation_id;
        this.status = status;
        this.volunteer_id = volunteer_id;
    }
}
