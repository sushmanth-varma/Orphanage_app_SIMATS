// ReportRequest.java
package com.SIMATS.hope;

public class ReportRequest {
    private int user_id;

    public ReportRequest(int userId) {
        this.user_id = userId;
    }

    // Add getter
    public int getUser_id() {
        return user_id;
    }
}