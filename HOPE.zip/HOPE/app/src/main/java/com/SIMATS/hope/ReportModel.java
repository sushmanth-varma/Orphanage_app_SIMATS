// Report.java
package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class ReportModel {
    @SerializedName("id")
    private int id;

    @SerializedName("type")
    private String type;

    @SerializedName("name")
    private String name;

    @SerializedName("age")
    private String age;

    @SerializedName("general_location")
    private String generalLocation;

    @SerializedName("exact_location")
    private String exactLocation;

    @SerializedName("photo_path")
    private String photoPath;

    @SerializedName("details")
    private String details;

    @SerializedName("status")
    private String status;

    @SerializedName("created_at")
    private String createdAt;

    // Getters
    public int getId() { return id; }
    public String getType() { return type; }
    public String getName() { return name; }
    public String getAge() { return age; }
    public String getGeneralLocation() { return generalLocation; }
    public String getExactLocation() { return exactLocation; }
    public String getPhotoPath() { return photoPath; }
    public String getDetails() { return details; }
    public String getStatus() { return status; }
    public String getCreatedAt() { return createdAt; }
}