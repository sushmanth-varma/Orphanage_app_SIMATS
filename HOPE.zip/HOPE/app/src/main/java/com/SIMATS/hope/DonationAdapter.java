//package com.SIMATS.hope;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.List;
//
//public class DonationAdapter extends RecyclerView.Adapter<DonationAdapter.DonationViewHolder> {
//
//    private Context context;
//    private List<DonationModel> donationList;
//
//    public DonationAdapter(Context context, List<DonationModel> donationList) {
//        this.context = context;
//        this.donationList = donationList;
//    }
//
//    @NonNull
//    @Override
//    public DonationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(context).inflate(R.layout.item_donation, parent, false);
//        return new DonationViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull DonationViewHolder holder, int position) {
//        DonationModel donation = donationList.get(position);
//
//        // Donation ID
//        holder.tvDonationId.setText(String.valueOf(donation.getId()));
//
//        // Donation Type
//        holder.tvType.setText(donation.getDonationType() != null ? donation.getDonationType() : "N/A");
//
//        // Cause
//        holder.tvCause.setText(donation.getCause() != null ? donation.getCause() : "N/A");
//
//        // Item Description
//        holder.tvItemDescription.setText(donation.getItemDescription() != null ? donation.getItemDescription() : "N/A");
//
//        // Amount Donated
//        String amount = donation.getAmountDonated() != null ? "₹" + donation.getAmountDonated() : "N/A";
//        holder.tvAmount.setText(amount);
//
//        // Orphanage Name
//        holder.tvOrphanage.setText(donation.getOrphanageName() != null ? donation.getOrphanageName() : "N/A");
//
//        // Status (Orphanage Confirmation)
//        String status = donation.getOrphanageConfirmation() != null ? donation.getOrphanageConfirmation() : "Pending";
//        holder.tvStatus.setText(status);
//
//        // Date (Created At)
//        holder.tvDate.setText(donation.getCreatedAt() != null ? donation.getCreatedAt() : "N/A");
//
//        // NOTE: No fullName / phone fields in DonationModel → skip binding
//        holder.tvFullName.setText("Not Available");
//        holder.tvPhone.setText("Not Available");
//    }
//
//    @Override
//    public int getItemCount() {
//        return donationList.size();
//    }
//
//    public void updateList(List<DonationModel> newList) {
//        donationList = newList;
//        notifyDataSetChanged();
//    }
//
//    static class DonationViewHolder extends RecyclerView.ViewHolder {
//
//        TextView tvDonationId, tvType, tvCause, tvItemDescription,
//                tvAmount, tvFullName, tvPhone, tvOrphanage, tvStatus, tvDate;
//
//        public DonationViewHolder(@NonNull View itemView) {
//            super(itemView);
//
//            tvDonationId = itemView.findViewById(R.id.item_tvDonationId);
//            tvType = itemView.findViewById(R.id.item_tvType);
//            tvCause = itemView.findViewById(R.id.item_tvCause);
//            tvItemDescription = itemView.findViewById(R.id.item_tvItemDescription);
//            tvAmount = itemView.findViewById(R.id.item_tvAmount);
//            tvFullName = itemView.findViewById(R.id.item_tvFullName);
//            tvPhone = itemView.findViewById(R.id.item_tvPhone);
//            tvOrphanage = itemView.findViewById(R.id.item_tvOrphanage);
//            tvStatus = itemView.findViewById(R.id.item_tvStatus);
//            tvDate = itemView.findViewById(R.id.item_tvDate);
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DonationAdapter extends RecyclerView.Adapter<DonationAdapter.DonationViewHolder> {

    private Context context;
    private List<DonationModel> donationList;

    public DonationAdapter(Context context, List<DonationModel> donationList) {
        this.context = context;
        this.donationList = donationList;
    }

    @NonNull
    @Override
    public DonationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_donation, parent, false);
        return new DonationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DonationViewHolder holder, int position) {
        DonationModel donation = donationList.get(position);

        // Debug logging to see actual data
        Log.d("DonationAdapter", "ID: " + donation.getId() +
                ", Amount: " + donation.getAmount() +
                ", Name: " + donation.getFullName() +
                ", Phone: " + donation.getPhone());

        // Donation ID
        holder.tvDonationId.setText(String.valueOf(donation.getId()));

        // Donation Type
        holder.tvType.setText(donation.getDonationType() != null ? donation.getDonationType() : "N/A");

        // Cause
        holder.tvCause.setText(donation.getCause() != null ? donation.getCause() : "N/A");

        // Item Description - Handle null for monetary donations
        String itemDescription = donation.getItemDescription();
        if (itemDescription == null || itemDescription.isEmpty() || "null".equals(itemDescription)) {
            itemDescription = "Monetary Donation";
        }
        holder.tvItemDescription.setText(itemDescription);

        // Amount Donated - Use getAmount() instead of getAmountDonated()
        String amountText = "N/A";
        String amountValue = donation.getAmount();
        if (amountValue != null && !amountValue.isEmpty() && !"null".equals(amountValue)) {
            try {
                // Format the amount with ₹ symbol
                amountText = "₹" + amountValue;
            } catch (Exception e) {
                amountText = "₹" + amountValue;
            }
        }
        holder.tvAmount.setText(amountText);

        // Orphanage Name
        holder.tvOrphanage.setText(donation.getOrphanageName() != null ? donation.getOrphanageName() : "N/A");

        // Status - Use getStatus() from API
        String status = donation.getStatus() != null ? donation.getStatus() : "Pending";
        holder.tvStatus.setText(status);

        // Date (Created At)
        holder.tvDate.setText(donation.getCreatedAt() != null ? donation.getCreatedAt() : "N/A");

        // Donor Information - Use the actual fields from API
        String fullName = donation.getFullName() != null ? donation.getFullName() : "Not Available";
        holder.tvFullName.setText(fullName);

        // Contact information - prefer phone over email
        String contactInfo = "Not Available";
        if (donation.getPhone() != null && !donation.getPhone().isEmpty() && !"null".equals(donation.getPhone())) {
            contactInfo = donation.getPhone();
        } else if (donation.getEmail() != null && !donation.getEmail().isEmpty() && !"null".equals(donation.getEmail())) {
            contactInfo = donation.getEmail();
        }
        holder.tvPhone.setText(contactInfo);
    }

    @Override
    public int getItemCount() {
        return donationList != null ? donationList.size() : 0;
    }

    public void updateList(List<DonationModel> newList) {
        donationList = newList;
        notifyDataSetChanged();
    }

    static class DonationViewHolder extends RecyclerView.ViewHolder {

        TextView tvDonationId, tvType, tvCause, tvItemDescription,
                tvAmount, tvFullName, tvPhone, tvOrphanage, tvStatus, tvDate;

        public DonationViewHolder(@NonNull View itemView) {
            super(itemView);

            tvDonationId = itemView.findViewById(R.id.item_tvDonationId);
            tvType = itemView.findViewById(R.id.item_tvType);
            tvCause = itemView.findViewById(R.id.item_tvCause);
            tvItemDescription = itemView.findViewById(R.id.item_tvItemDescription);
            tvAmount = itemView.findViewById(R.id.item_tvAmount);
            tvFullName = itemView.findViewById(R.id.item_tvFullName);
            tvPhone = itemView.findViewById(R.id.item_tvPhone);
            tvOrphanage = itemView.findViewById(R.id.item_tvOrphanage);
            tvStatus = itemView.findViewById(R.id.item_tvStatus);
            tvDate = itemView.findViewById(R.id.item_tvDate);
        }
    }
}
