package com.SIMATS.hope;

public class VolunteerAdapter {
}
