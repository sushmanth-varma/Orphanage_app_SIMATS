// ApiResponse.java
package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ApiResponse_user {
    @SerializedName("success")
    private boolean success;

    @SerializedName("message")
    private String message;

    @SerializedName("data")
    private List<ReportModel> data;

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public List<ReportModel> getData() {
        return data;
    }
}