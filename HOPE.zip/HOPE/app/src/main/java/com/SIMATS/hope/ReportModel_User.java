//package com.SIMATS.hope;
//
//public class ReportModel_User {
//    private String type, name, age, general_location, exact_location, photo_path, details, status, created_at;
//
//    public ReportModel_User(String type, String name, String age, String general_location,
//                       String exact_location, String photo_path, String details, String status, String created_at) {
//        this.type = type;
//        this.name = name;
//        this.age = age;
//        this.general_location = general_location;
//        this.exact_location = exact_location;
//        this.photo_path = photo_path;
//        this.details = details;
//        this.status = status;
//        this.created_at = created_at;
//    }
//
//    public String getType() { return type; }
//    public String getName() { return name; }
//    public String getAge() { return age; }
//    public String getGeneral_location() { return general_location; }
//    public String getExact_location() { return exact_location; }
//    public String getPhoto_path() { return photo_path; }
//    public String getDetails() { return details; }
//    public String getStatus() { return status; }
//    public String getCreated_at() { return created_at;
package com.SIMATS.hope;

public class ReportModel_User {
    private String type, name, age, generalLocation, exactLocation, photoPath, details, status, createdAt;

    public ReportModel_User(String type, String name, String age, String generalLocation,
                       String exactLocation, String photoPath, String details, String status, String createdAt) {
        this.type = type;
        this.name = name;
        this.age = age;
        this.generalLocation = generalLocation;
        this.exactLocation = exactLocation;
        this.photoPath = photoPath;
        this.details = details;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getType() { return type; }
    public String getName() { return name; }
    public String getAge() { return age; }
    public String getGeneralLocation() { return generalLocation; }
    public String getExactLocation() { return exactLocation; }
    public String getPhotoPath() { return photoPath; }
    public String getDetails() { return details; }
    public String getStatus() { return status; }
    public String getCreatedAt() { return createdAt; }
}
