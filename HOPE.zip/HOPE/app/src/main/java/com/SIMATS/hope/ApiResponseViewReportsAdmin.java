package com.SIMATS.hope;

import java.util.ArrayList;
import java.util.List;

public class ApiResponseViewReportsAdmin {
    private String status;
    private ArrayList<ReportModel_Admin> data; // Change from List to ArrayList

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ArrayList<ReportModel_Admin> getData() { // Change return type to ArrayList
        return data;
    }

    public void setData(ArrayList<ReportModel_Admin> data) { // Change parameter type to ArrayList
        this.data = data;
    }
}