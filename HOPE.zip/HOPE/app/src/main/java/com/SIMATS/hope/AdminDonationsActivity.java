package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class AdminDonationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_donations);

        CardView cardGetDonations = findViewById(R.id.layoutGetDonations);
        CardView cardAssignVolunteer = findViewById(R.id.layoutAssignVolunteer);
        CardView cardUpdateStatus = findViewById(R.id.layoutUpdateStatus);

        // Set click listeners with ripple effect
        cardGetDonations.setOnClickListener(v -> {
            v.setPressed(true);
            v.postDelayed(() -> {
                v.setPressed(false);
                startActivity(new Intent(AdminDonationsActivity.this, ViewDonationsActivity_admin.class));
            }, 200);
        });

        cardAssignVolunteer.setOnClickListener(v -> {
            v.setPressed(true);
            v.postDelayed(() -> {
                v.setPressed(false);
                startActivity(new Intent(AdminDonationsActivity.this, AssignVolunteerActivity_admin.class));
            }, 200);
        });

        cardUpdateStatus.setOnClickListener(v -> {
            v.setPressed(true);
            v.postDelayed(() -> {
                v.setPressed(false);
                startActivity(new Intent(AdminDonationsActivity.this, UpdateStatusActivity_admin.class));
            }, 200);
        });
    }
}