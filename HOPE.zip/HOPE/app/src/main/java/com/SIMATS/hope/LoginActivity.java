////////////package com.SIMATS.hope;
////////////
////////////import android.content.Intent;
////////////import android.content.SharedPreferences;
////////////import android.os.Bundle;
////////////import android.widget.Button;
////////////import android.widget.EditText;
////////////import android.widget.TextView;
////////////import android.widget.Toast;
////////////
////////////import androidx.annotation.NonNull;
////////////import androidx.appcompat.app.AppCompatActivity;
////////////
////////////import retrofit2.Call;
////////////import retrofit2.Callback;
////////////import retrofit2.Response;
////////////
////////////public class LoginActivity extends AppCompatActivity {
////////////
////////////    EditText phoneInput, passwordInput;
////////////    Button btnLogin;
////////////    TextView signUpLink, forgotPassword;
////////////
////////////    @Override
////////////    protected void onCreate(Bundle savedInstanceState) {
////////////        super.onCreate(savedInstanceState);
////////////        setContentView(R.layout.activity_login);
////////////
////////////        phoneInput = findViewById(R.id.phoneInput);
////////////        passwordInput = findViewById(R.id.passwordInput);
////////////        btnLogin = findViewById(R.id.btnLogin);
////////////        signUpLink = findViewById(R.id.signUpLink);
////////////        forgotPassword = findViewById(R.id.forgotPassword);
////////////
////////////        btnLogin.setOnClickListener(view -> loginUser());
////////////
////////////        signUpLink.setOnClickListener(view ->
////////////                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
////////////        );
////////////
////////////        forgotPassword.setOnClickListener(view ->
////////////                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
////////////        );
////////////    }
////////////
////////////    private void loginUser() {
////////////        String phone = phoneInput.getText().toString().trim();
////////////        String password = passwordInput.getText().toString().trim();
////////////
////////////        if (phone.isEmpty() || password.isEmpty()) {
////////////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
////////////            return;
////////////        }
////////////
////////////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////////////
////////////        LoginRequest requestBody = new LoginRequest(phone, password);
////////////        Call<LoginResponse> call = apiService.loginUser(requestBody);
////////////
////////////        call.enqueue(new Callback<LoginResponse>() {
////////////            @Override
////////////            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
////////////                if (response.isSuccessful() && response.body() != null &&
////////////                        "success".equalsIgnoreCase(response.body().getStatus())) {
////////////
////////////                    LoginResponse.User user = response.body().getUser();
////////////
////////////                    // Store user data in SharedPreferences
////////////                    SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////////////                    SharedPreferences.Editor editor = prefs.edit();
////////////                    editor.putInt("user_id", user.getId());
////////////
////////////                    // Store volunteer ID if available (assuming it's in the user object)
////////////                    if (user.getVolunteerId() > 0) {
////////////                        editor.putInt("volunteer_id", user.getVolunteerId());
////////////                    }
////////////                    editor.apply();
////////////
////////////                    Toast.makeText(LoginActivity.this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();
////////////
////////////                    // Role-based redirection
////////////                    if ("admin".equalsIgnoreCase(user.getRole())) {
////////////                        startActivity(new Intent(LoginActivity.this, NGODashboardActivity.class));
////////////                    } else if ("volunteer".equalsIgnoreCase(user.getRole())) {
////////////                        startActivity(new Intent(LoginActivity.this, VolunteerDashboardActivity.class));
////////////                    } else {
////////////                        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
////////////                    }
////////////
////////////                    finish();
////////////                } else {
////////////                    String errorMsg = (response.body() != null) ? response.body().getMessage() : "Invalid credentials or server error.";
////////////                    Toast.makeText(LoginActivity.this, "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
////////////                }
////////////            }
////////////
////////////            @Override
////////////            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
////////////                Toast.makeText(LoginActivity.this, "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////////////            }
////////////        });
////////////    }
////////////}
//////////package com.SIMATS.hope;
//////////
//////////import android.content.Intent;
//////////import android.content.SharedPreferences;
//////////import android.os.Bundle;
//////////import android.widget.Button;
//////////import android.widget.EditText;
//////////import android.widget.TextView;
//////////import android.widget.Toast;
//////////
//////////import androidx.annotation.NonNull;
//////////import androidx.appcompat.app.AppCompatActivity;
//////////
//////////import retrofit2.Call;
//////////import retrofit2.Callback;
//////////import retrofit2.Response;
//////////
//////////public class LoginActivity extends AppCompatActivity {
//////////
//////////    EditText phoneInput, passwordInput;
//////////    Button btnLogin;
//////////    TextView signUpLink, forgotPassword;
//////////
//////////    @Override
//////////    protected void onCreate(Bundle savedInstanceState) {
//////////        super.onCreate(savedInstanceState);
//////////        setContentView(R.layout.activity_login);
//////////
//////////        phoneInput = findViewById(R.id.phoneInput);
//////////        passwordInput = findViewById(R.id.passwordInput);
//////////        btnLogin = findViewById(R.id.btnLogin);
//////////        signUpLink = findViewById(R.id.signUpLink);
//////////        forgotPassword = findViewById(R.id.forgotPassword);
//////////
//////////        btnLogin.setOnClickListener(view -> loginUser());
//////////
//////////        signUpLink.setOnClickListener(view ->
//////////                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
//////////        );
//////////
//////////        forgotPassword.setOnClickListener(view ->
//////////                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
//////////        );
//////////    }
//////////
//////////    private void loginUser() {
//////////        String phone = phoneInput.getText().toString().trim();
//////////        String password = passwordInput.getText().toString().trim();
//////////
//////////        if (phone.isEmpty() || password.isEmpty()) {
//////////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
//////////            return;
//////////        }
//////////
//////////        // First try regular user login
//////////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////////        LoginRequest requestBody = new LoginRequest(phone, password);
//////////        Call<LoginResponse> call = apiService.loginUser(requestBody);
//////////
//////////        call.enqueue(new Callback<LoginResponse>() {
//////////            @Override
//////////            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
//////////                if (response.isSuccessful() && response.body() != null &&
//////////                        "success".equalsIgnoreCase(response.body().getStatus())) {
//////////                    // Regular user login successful
//////////                    handleSuccessfulLogin(response.body());
//////////                } else {
//////////                    // If regular login fails, try volunteer login
//////////                    tryVolunteerLogin(phone, password);
//////////                }
//////////            }
//////////
//////////            @Override
//////////            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
//////////                // If regular login fails, try volunteer login
//////////                tryVolunteerLogin(phone, password);
//////////            }
//////////        });
//////////    }
//////////
//////////    private void tryVolunteerLogin(String phone, String password) {
//////////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////////        VolunteerLoginRequest request = new VolunteerLoginRequest(phone, password);
//////////        Call<VolunteerLoginResponse> call = apiService.loginVolunteer(request);
//////////
//////////        call.enqueue(new Callback<VolunteerLoginResponse>() {
//////////            @Override
//////////            public void onResponse(@NonNull Call<VolunteerLoginResponse> call,
//////////                                   @NonNull Response<VolunteerLoginResponse> response) {
//////////                if (response.isSuccessful() && response.body() != null &&
//////////                        "success".equalsIgnoreCase(response.body().getStatus())) {
//////////                    // Volunteer login successful
//////////                    handleVolunteerLogin(response.body());
//////////                } else {
//////////                    String errorMsg = (response.body() != null) ?
//////////                            response.body().getMessage() : "Invalid credentials";
//////////                    Toast.makeText(LoginActivity.this,
//////////                            "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
//////////                }
//////////            }
//////////
//////////            @Override
//////////            public void onFailure(@NonNull Call<VolunteerLoginResponse> call,
//////////                                  @NonNull Throwable t) {
//////////                Toast.makeText(LoginActivity.this,
//////////                        "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////////            }
//////////        });
//////////    }
//////////
//////////    private void handleVolunteerLogin(VolunteerLoginResponse response) {
//////////        VolunteerLoginResponse.User user = response.getUser();
//////////
//////////        // Store volunteer data in SharedPreferences
//////////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////////        SharedPreferences.Editor editor = prefs.edit();
//////////        editor.putInt("user_id", user.getId());
//////////        editor.putInt("volunteer_id", user.getId());
//////////        editor.putString("user_name", user.getFull_name());
//////////        editor.putString("phone", user.getPhone());
//////////        editor.putString("role", "volunteer");
//////////        editor.apply();
//////////
//////////        Toast.makeText(this, "Welcome Volunteer " + user.getFull_name(), Toast.LENGTH_SHORT).show();
//////////        startActivity(new Intent(LoginActivity.this, VolunteerDashboardActivity.class));
//////////        finish();
//////////    }
//////////
//////////    private void handleSuccessfulLogin(LoginResponse response) {
//////////        LoginResponse.User user = response.getUser();
//////////
//////////        // Store user data in SharedPreferences
//////////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////////        SharedPreferences.Editor editor = prefs.edit();
//////////        editor.putInt("user_id", user.getId());
//////////        if (user.getVolunteerId() > 0) {
//////////            editor.putInt("volunteer_id", user.getVolunteerId());
//////////        }
//////////        editor.putString("user_name", user.getUsername());
//////////        editor.putString("role", user.getRole());
//////////        editor.apply();
//////////
//////////        Toast.makeText(this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();
//////////
//////////        // Role-based redirection
//////////        if ("admin".equalsIgnoreCase(user.getRole())) {
//////////            startActivity(new Intent(LoginActivity.this, NGODashboardActivity.class));
//////////        } else if ("volunteer".equalsIgnoreCase(user.getRole())) {
//////////            startActivity(new Intent(LoginActivity.this, VolunteerDashboardActivity.class));
//////////        } else {
//////////            startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
//////////        }
//////////
//////////        finish();
//////////    }
//////////}
////////package com.SIMATS.hope;
////////
////////import android.content.Intent;
////////import android.content.SharedPreferences;
////////import android.os.Bundle;
////////import android.widget.Button;
////////import android.widget.EditText;
////////import android.widget.TextView;
////////import android.widget.Toast;
////////
////////import androidx.annotation.NonNull;
////////import androidx.appcompat.app.AppCompatActivity;
////////
////////import retrofit2.Call;
////////import retrofit2.Callback;
////////import retrofit2.Response;
////////
////////public class LoginActivity extends AppCompatActivity {
////////
////////    EditText phoneInput, passwordInput;
////////    Button btnLogin;
////////    TextView signUpLink, forgotPassword;
////////    private String userRole = "user"; // Default role
////////
////////    @Override
////////    protected void onCreate(Bundle savedInstanceState) {
////////        super.onCreate(savedInstanceState);
////////        setContentView(R.layout.activity_login);
////////
////////        // Get the role from WelcomeActivity
////////        if (getIntent().hasExtra("role")) {
////////            userRole = getIntent().getStringExtra("role");
////////        }
////////
////////        phoneInput = findViewById(R.id.phoneInput);
////////        passwordInput = findViewById(R.id.passwordInput);
////////        btnLogin = findViewById(R.id.btnLogin);
////////        signUpLink = findViewById(R.id.signUpLink);
////////        forgotPassword = findViewById(R.id.forgotPassword);
////////
////////        btnLogin.setOnClickListener(view -> {
////////            if ("volunteer".equals(userRole)) {
////////                loginAsVolunteer();
////////            } else {
////////                loginUser();
////////            }
////////        });
////////
////////        signUpLink.setOnClickListener(view ->
////////                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
////////        );
////////
////////        forgotPassword.setOnClickListener(view ->
////////                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
////////        );
////////    }
////////
////////    private void loginUser() {
////////        String phone = phoneInput.getText().toString().trim();
////////        String password = passwordInput.getText().toString().trim();
////////
////////        if (phone.isEmpty() || password.isEmpty()) {
////////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
////////            return;
////////        }
////////
////////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////////        LoginRequest requestBody = new LoginRequest(phone, password);
////////        Call<LoginResponse> call = apiService.loginUser(requestBody);
////////
////////        call.enqueue(new Callback<LoginResponse>() {
////////            @Override
////////            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
////////                if (response.isSuccessful() && response.body() != null &&
////////                        "success".equalsIgnoreCase(response.body().getStatus())) {
////////                    handleUserLogin(response.body());
////////                } else {
////////                    String errorMsg = response.body() != null ?
////////                            response.body().getMessage() : "Invalid credentials";
////////                    Toast.makeText(LoginActivity.this, "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
////////                }
////////            }
////////
////////            @Override
////////            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
////////                Toast.makeText(LoginActivity.this, "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////////            }
////////        });
////////    }
////////
////////    private void loginAsVolunteer() {
////////        String phone = phoneInput.getText().toString().trim();
////////        String password = passwordInput.getText().toString().trim();
////////
////////        if (phone.isEmpty() || password.isEmpty()) {
////////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
////////            return;
////////        }
////////
////////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////////        VolunteerLoginRequest request = new VolunteerLoginRequest(phone, password);
////////        Call<VolunteerLoginResponse> call = apiService.loginVolunteer(request);
////////
////////        call.enqueue(new Callback<VolunteerLoginResponse>() {
////////            @Override
////////            public void onResponse(@NonNull Call<VolunteerLoginResponse> call,
////////                                   @NonNull Response<VolunteerLoginResponse> response) {
////////                if (response.isSuccessful() && response.body() != null &&
////////                        "success".equalsIgnoreCase(response.body().getStatus())) {
////////                    handleVolunteerLogin(response.body());
////////                } else {
////////                    String errorMsg = response.body() != null ?
////////                            response.body().getMessage() : "Invalid volunteer credentials";
////////                    Toast.makeText(LoginActivity.this, "Volunteer Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
////////                }
////////            }
////////
////////            @Override
////////            public void onFailure(@NonNull Call<VolunteerLoginResponse> call,
////////                                  @NonNull Throwable t) {
////////                Toast.makeText(LoginActivity.this, "Volunteer Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////////            }
////////        });
////////    }
////////
////////    private void handleUserLogin(LoginResponse response) {
////////        LoginResponse.User user = response.getUser();
////////
////////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////////        SharedPreferences.Editor editor = prefs.edit();
////////        editor.putInt("user_id", user.getId());
////////        editor.putString("user_name", user.getUsername());
////////        editor.putString("role", user.getRole());
////////
////////        if (user.getVolunteerId() > 0) {
////////            editor.putInt("volunteer_id", user.getVolunteerId());
////////        }
////////
////////        editor.apply();
////////
////////        Toast.makeText(this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();
////////
////////        // Role-based redirection
////////        if ("admin".equalsIgnoreCase(user.getRole())) {
////////            startActivity(new Intent(this, NGODashboardActivity.class));
////////        } else if ("volunteer".equalsIgnoreCase(user.getRole())) {
////////            startActivity(new Intent(this, VolunteerDashboardActivity.class));
////////        } else {
////////            startActivity(new Intent(this, DashboardActivity.class));
////////        }
////////        finish();
////////    }
////////
////////    private void handleVolunteerLogin(VolunteerLoginResponse response) {
////////        VolunteerLoginResponse.User user = response.getUser();
////////
////////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////////        SharedPreferences.Editor editor = prefs.edit();
////////        editor.putInt("user_id", user.getId());
////////        editor.putInt("volunteer_id", user.getId());
////////        editor.putString("user_name", user.getFull_name());
////////        editor.putString("phone", user.getPhone());
////////        editor.putString("role", "volunteer");
////////        editor.apply();
////////
////////        Toast.makeText(this, "Welcome Volunteer " + user.getFull_name(), Toast.LENGTH_SHORT).show();
////////        startActivity(new Intent(this, VolunteerDashboardActivity.class));
////////        finish();
////////    }
////////}
//////package com.SIMATS.hope;
//////
//////import android.content.Intent;
//////import android.os.Bundle;
//////import android.widget.Button;
//////import android.widget.EditText;
//////import android.widget.TextView;
//////import android.widget.Toast;
//////
//////import androidx.annotation.NonNull;
//////import androidx.appcompat.app.AppCompatActivity;
//////
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////
//////public class LoginActivity extends AppCompatActivity {
//////
//////    private EditText phoneInput, passwordInput;
//////    private Button btnLogin;
//////    private TextView signUpLink, forgotPassword;
//////    private String userRole = "user"; // Default role
//////    private PrefManager prefManager;
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.activity_login);
//////
//////        prefManager = new PrefManager(this);
//////
//////        // Get the role from WelcomeActivity
//////        if (getIntent().hasExtra("role")) {
//////            userRole = getIntent().getStringExtra("role");
//////        }
//////
//////        initializeViews();
//////        setupClickListeners();
//////    }
//////
//////    private void initializeViews() {
//////        phoneInput = findViewById(R.id.phoneInput);
//////        passwordInput = findViewById(R.id.passwordInput);
//////        btnLogin = findViewById(R.id.btnLogin);
//////        signUpLink = findViewById(R.id.signUpLink);
//////        forgotPassword = findViewById(R.id.forgotPassword);
//////    }
//////
//////    private void setupClickListeners() {
//////        btnLogin.setOnClickListener(view -> {
//////            if ("volunteer".equals(userRole)) {
//////                loginAsVolunteer();
//////            } else {
//////                loginUser();
//////            }
//////        });
//////
//////        signUpLink.setOnClickListener(view ->
//////                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
//////        );
//////
//////        forgotPassword.setOnClickListener(view ->
//////                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
//////        );
//////    }
//////
//////    private void loginUser() {
//////        String phone = phoneInput.getText().toString().trim();
//////        String password = passwordInput.getText().toString().trim();
//////
//////        if (phone.isEmpty() || password.isEmpty()) {
//////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
//////            return;
//////        }
//////
//////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////        Call<LoginResponse> call = apiService.loginUser(new LoginRequest(phone, password));
//////
//////        call.enqueue(new Callback<LoginResponse>() {
//////            @Override
//////            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
//////                if (response.isSuccessful() && response.body() != null) {
//////                    handleUserLogin(response.body());
//////                } else {
//////                    showLoginError(response);
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
//////                Toast.makeText(LoginActivity.this,
//////                        "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////            }
//////        });
//////    }
//////
//////    private void loginAsVolunteer() {
//////        String phone = phoneInput.getText().toString().trim();
//////        String password = passwordInput.getText().toString().trim();
//////
//////        if (phone.isEmpty() || password.isEmpty()) {
//////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
//////            return;
//////        }
//////
//////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////        Call<VolunteerLoginResponse> call = apiService.loginVolunteer(
//////                new VolunteerLoginRequest(phone, password));
//////
//////        call.enqueue(new Callback<VolunteerLoginResponse>() {
//////            @Override
//////            public void onResponse(@NonNull Call<VolunteerLoginResponse> call,
//////                                   @NonNull Response<VolunteerLoginResponse> response) {
//////                if (response.isSuccessful() && response.body() != null) {
//////                    handleVolunteerLogin(response.body());
//////                } else {
//////                    showVolunteerLoginError(response);
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(@NonNull Call<VolunteerLoginResponse> call,
//////                                  @NonNull Throwable t) {
//////                Toast.makeText(LoginActivity.this,
//////                        "Volunteer Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////            }
//////        });
//////    }
//////
//////    private void handleUserLogin(LoginResponse response) {
//////        if ("success".equalsIgnoreCase(response.getStatus())) {
//////            LoginResponse.User user = response.getUser();
//////            prefManager.createUserSession(
//////                    user.getId(),
//////                    user.getUsername(),
//////                    user.getRole(),
//////                    user.getVolunteerId()
//////            );
//////
//////            Toast.makeText(this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();
//////            redirectBasedOnRole(user.getRole());
//////        } else {
//////            Toast.makeText(this,
//////                    "Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
//////        }
//////    }
//////
//////    private void handleVolunteerLogin(VolunteerLoginResponse response) {
//////        if ("success".equalsIgnoreCase(response.getStatus())) {
//////            VolunteerLoginResponse.User user = response.getUser();
//////            prefManager.createVolunteerSession(
//////                    user.getId(),
//////                    user.getPhone(),
//////                    user.getFull_name()
//////            );
//////
//////            Toast.makeText(this,
//////                    "Welcome Volunteer " + user.getFull_name(), Toast.LENGTH_SHORT).show();
//////            startActivity(new Intent(this, VolunteerDashboardActivity.class));
//////            finish();
//////        } else {
//////            Toast.makeText(this,
//////                    "Volunteer Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
//////        }
//////    }
//////
//////    private void redirectBasedOnRole(String role) {
//////        Intent intent;
//////        if ("admin".equalsIgnoreCase(role)) {
//////            intent = new Intent(this, NGODashboardActivity.class);
//////        } else if ("volunteer".equalsIgnoreCase(role)) {
//////            intent = new Intent(this, VolunteerDashboardActivity.class);
//////        } else {
//////            intent = new Intent(this, DashboardActivity.class);
//////        }
//////        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//////        startActivity(intent);
//////        finish();
//////    }
//////
//////    private void showLoginError(Response<LoginResponse> response) {
//////        String errorMsg = response.body() != null ?
//////                response.body().getMessage() : "Invalid credentials";
//////        Toast.makeText(this, "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
//////    }
//////
//////    private void showVolunteerLoginError(Response<VolunteerLoginResponse> response) {
//////        String errorMsg = response.body() != null ?
//////                response.body().getMessage() : "Invalid volunteer credentials";
//////        Toast.makeText(this, "Volunteer Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
//////    }
//////}
////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.os.Bundle;
////import android.widget.Button;
////import android.widget.EditText;
////import android.widget.TextView;
////import android.widget.Toast;
////
////import androidx.annotation.NonNull;
////import androidx.appcompat.app.AppCompatActivity;
////
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class LoginActivity extends AppCompatActivity {
////
////    private EditText phoneInput, passwordInput;
////    private Button btnLogin;
////    private TextView signUpLink, forgotPassword;
////    private String userRole = "user"; // Default role
////    private PrefManager prefManager;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_login);
////
////        prefManager = new PrefManager(this);
////
////        // Get the role from WelcomeActivity
////        if (getIntent().hasExtra("role")) {
////            userRole = getIntent().getStringExtra("role");
////        }
////
////        initializeViews();
////        setupClickListeners();
////    }
////
////    private void initializeViews() {
////        phoneInput = findViewById(R.id.phoneInput);
////        passwordInput = findViewById(R.id.passwordInput);
////        btnLogin = findViewById(R.id.btnLogin);
////        signUpLink = findViewById(R.id.signUpLink);
////        forgotPassword = findViewById(R.id.forgotPassword);
////    }
////
////    private void setupClickListeners() {
////        btnLogin.setOnClickListener(view -> {
////            if ("volunteer".equals(userRole)) {
////                loginAsVolunteer();
////            } else {
////                loginUser();
////            }
////        });
////
////        signUpLink.setOnClickListener(view ->
////                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
////        );
////
////        forgotPassword.setOnClickListener(view ->
////                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
////        );
////    }
////
////    private void loginUser() {
////        String phone = phoneInput.getText().toString().trim();
////        String password = passwordInput.getText().toString().trim();
////
////        if (phone.isEmpty() || password.isEmpty()) {
////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
////            return;
////        }
////
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<LoginResponse> call = apiService.loginUser(new LoginRequest(phone, password));
////
////        call.enqueue(new Callback<LoginResponse>() {
////            @Override
////            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
////                if (response.isSuccessful() && response.body() != null) {
////                    handleUserLogin(response.body());
////                } else {
////                    showLoginError(response);
////                }
////            }
////
////            @Override
////            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
////                Toast.makeText(LoginActivity.this,
////                        "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////            }
////        });
////    }
////
////    private void loginAsVolunteer() {
////        String phone = phoneInput.getText().toString().trim();
////        String password = passwordInput.getText().toString().trim();
////
////        if (phone.isEmpty() || password.isEmpty()) {
////            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
////            return;
////        }
////
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<VolunteerLoginResponse> call = apiService.loginVolunteer(
////                new VolunteerLoginRequest(phone, password));
////
////        call.enqueue(new Callback<VolunteerLoginResponse>() {
////            @Override
////            public void onResponse(@NonNull Call<VolunteerLoginResponse> call,
////                                   @NonNull Response<VolunteerLoginResponse> response) {
////                if (response.isSuccessful() && response.body() != null) {
////                    handleVolunteerLogin(response.body());
////                } else {
////                    showVolunteerLoginError(response);
////                }
////            }
////
////            @Override
////            public void onFailure(@NonNull Call<VolunteerLoginResponse> call,
////                                  @NonNull Throwable t) {
////                Toast.makeText(LoginActivity.this,
////                        "Volunteer Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////            }
////        });
////    }
////
////    private void handleUserLogin(LoginResponse response) {
////        if ("success".equalsIgnoreCase(response.getStatus())) {
////            LoginResponse.User user = response.getUser();
////            prefManager.createUserSession(
////                    user.getId(),
////                    user.getUsername(),
////                    user.getRole(),
////                    user.getVolunteerId()
////            );
////
////            Toast.makeText(this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();
////
////            // Redirect to MonetaryDonationActivity instead of dashboard
////            Intent intent = new Intent(LoginActivity.this, MonetaryDonationActivity.class);
////            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
////            startActivity(intent);
////            finish();
////        } else {
////            Toast.makeText(this,
////                    "Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
////        }
////    }
////
////    private void handleVolunteerLogin(VolunteerLoginResponse response) {
////        if ("success".equalsIgnoreCase(response.getStatus())) {
////            VolunteerLoginResponse.User user = response.getUser();
////            prefManager.createVolunteerSession(
////                    user.getId(),
////                    user.getPhone(),
////                    user.getFull_name()
////            );
////
////            Toast.makeText(this,
////                    "Welcome Volunteer " + user.getFull_name(), Toast.LENGTH_SHORT).show();
////
////            // Redirect to MonetaryDonationActivity instead of VolunteerDashboardActivity
////            Intent intent = new Intent(LoginActivity.this, MonetaryDonationActivity.class);
////            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
////            startActivity(intent);
////            finish();
////        } else {
////            Toast.makeText(this,
////                    "Volunteer Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
////        }
////    }
////
////    private void showLoginError(Response<LoginResponse> response) {
////        String errorMsg = response.body() != null ?
////                response.body().getMessage() : "Invalid credentials";
////        Toast.makeText(this, "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
////    }
////
////    private void showVolunteerLoginError(Response<VolunteerLoginResponse> response) {
////        String errorMsg = response.body() != null ?
////                response.body().getMessage() : "Invalid volunteer credentials";
////        Toast.makeText(this, "Volunteer Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class LoginActivity extends AppCompatActivity {
//
//    private EditText phoneInput, passwordInput;
//    private Button btnLogin;
//    private TextView signUpLink, forgotPassword;
//    private String userRole = "user"; // Default role
//    private PrefManager prefManager;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_login);
//
//        prefManager = new PrefManager(this);
//
//        // Get the role from WelcomeActivity
//        if (getIntent().hasExtra("role")) {
//            userRole = getIntent().getStringExtra("role");
//        }
//
//        initializeViews();
//        setupClickListeners();
//    }
//
//    private void initializeViews() {
//        phoneInput = findViewById(R.id.phoneInput);
//        passwordInput = findViewById(R.id.passwordInput);
//        btnLogin = findViewById(R.id.btnLogin);
//        signUpLink = findViewById(R.id.signUpLink);
//        forgotPassword = findViewById(R.id.forgotPassword);
//    }
//
//    private void setupClickListeners() {
//        btnLogin.setOnClickListener(view -> {
//            if ("volunteer".equals(userRole)) {
//                loginAsVolunteer();
//            } else {
//                loginUser();
//            }
//        });
//
//        signUpLink.setOnClickListener(view ->
//                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
//        );
//
//        forgotPassword.setOnClickListener(view ->
//                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
//        );
//    }
//
//    private void loginUser() {
//        String phone = phoneInput.getText().toString().trim();
//        String password = passwordInput.getText().toString().trim();
//
//        if (phone.isEmpty() || password.isEmpty()) {
//            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<LoginResponse> call = apiService.loginUser(new LoginRequest(phone, password));
//
//        call.enqueue(new Callback<LoginResponse>() {
//            @Override
//            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    handleUserLogin(response.body());
//                } else {
//                    showLoginError(response);
//                }
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
//                Toast.makeText(LoginActivity.this,
//                        "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void loginAsVolunteer() {
//        String phone = phoneInput.getText().toString().trim();
//        String password = passwordInput.getText().toString().trim();
//
//        if (phone.isEmpty() || password.isEmpty()) {
//            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<VolunteerLoginResponse> call = apiService.loginVolunteer(
//                new VolunteerLoginRequest(phone, password));
//
//        call.enqueue(new Callback<VolunteerLoginResponse>() {
//            @Override
//            public void onResponse(@NonNull Call<VolunteerLoginResponse> call,
//                                   @NonNull Response<VolunteerLoginResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    handleVolunteerLogin(response.body());
//                } else {
//                    showVolunteerLoginError(response);
//                }
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<VolunteerLoginResponse> call,
//                                  @NonNull Throwable t) {
//                Toast.makeText(LoginActivity.this,
//                        "Volunteer Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void handleUserLogin(LoginResponse response) {
//        if ("success".equalsIgnoreCase(response.getStatus())) {
//            LoginResponse.User user = response.getUser();
//
//            // Convert int volunteerId to String
//            String volunteerIdStr = String.valueOf(user.getVolunteerId());
//
//            prefManager.createUserSession(
//                    user.getId(),
//                    user.getUsername(),
//                    user.getRole(),
//                    volunteerIdStr  // Pass as String
//            );
//            // ... rest of the code
//
//            Toast.makeText(this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();
//
//            // Redirect to MonetaryDonationActivity instead of dashboard
//            Intent intent = new Intent(LoginActivity.this, MonetaryDonationActivity.class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//            finish();
//        } else {
//            Toast.makeText(this,
//                    "Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private void handleVolunteerLogin(VolunteerLoginResponse response) {
//        if ("success".equalsIgnoreCase(response.getStatus())) {
//            VolunteerLoginResponse.User user = response.getUser();
//            prefManager.createVolunteerSession(
//                    user.getId(),
//                    user.getPhone(),
//                    user.getFull_name()
//            );
//
//            Toast.makeText(this,
//                    "Welcome Volunteer " + user.getFull_name(), Toast.LENGTH_SHORT).show();
//
//            // Redirect to MonetaryDonationActivity instead of VolunteerDashboardActivity
//            Intent intent = new Intent(LoginActivity.this, VolunteerDashboardActivity .class);
//            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
//            startActivity(intent);
//            finish();
//        } else {
//            Toast.makeText(this,
//                    "Volunteer Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    private void showLoginError(Response<LoginResponse> response) {
//        String errorMsg = response.body() != null ?
//                response.body().getMessage() : "Invalid credentials";
//        Toast.makeText(this, "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
//    }
//
//    private void showVolunteerLoginError(Response<VolunteerLoginResponse> response) {
//        String errorMsg = response.body() != null ?
//                response.body().getMessage() : "Invalid volunteer credentials";
//        Toast.makeText(this, "Volunteer Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.messaging.FirebaseMessaging;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText phoneInput, passwordInput;
    private Button btnLogin;
    private TextView signUpLink, forgotPassword;
    private String userRole = "user"; // Default role
    private PrefManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        prefManager = new PrefManager(this);

        // Get the role from WelcomeActivity
        if (getIntent().hasExtra("role")) {
            userRole = getIntent().getStringExtra("role");
        }

        initializeViews();
        setupClickListeners();
    }

    private void initializeViews() {
        phoneInput = findViewById(R.id.phoneInput);
        passwordInput = findViewById(R.id.passwordInput);
        btnLogin = findViewById(R.id.btnLogin);
        signUpLink = findViewById(R.id.signUpLink);
        forgotPassword = findViewById(R.id.forgotPassword);
    }

    private void setupClickListeners() {
        btnLogin.setOnClickListener(view -> {
            if ("volunteer".equals(userRole)) {
                loginAsVolunteer();
            } else {
                loginUser();
            }
        });

        signUpLink.setOnClickListener(view ->
                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
        );

        forgotPassword.setOnClickListener(view ->
                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class))
        );
    }

    private void loginUser() {
        String phone = phoneInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (phone.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<LoginResponse> call = apiService.loginUser(new LoginRequest(phone, password));

        call.enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(@NonNull Call<LoginResponse> call, @NonNull Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    handleUserLogin(response.body());
                } else {
                    showLoginError(response);
                }
            }

            @Override
            public void onFailure(@NonNull Call<LoginResponse> call, @NonNull Throwable t) {
                Toast.makeText(LoginActivity.this,
                        "Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loginAsVolunteer() {
        String phone = phoneInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (phone.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<VolunteerLoginResponse> call = apiService.loginVolunteer(
                new VolunteerLoginRequest(phone, password));

        call.enqueue(new Callback<VolunteerLoginResponse>() {
            @Override
            public void onResponse(@NonNull Call<VolunteerLoginResponse> call,
                                   @NonNull Response<VolunteerLoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    handleVolunteerLogin(response.body());
                } else {
                    showVolunteerLoginError(response);
                }
            }

            @Override
            public void onFailure(@NonNull Call<VolunteerLoginResponse> call,
                                  @NonNull Throwable t) {
                Toast.makeText(LoginActivity.this,
                        "Volunteer Login Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleUserLogin(LoginResponse response) {
        if ("success".equalsIgnoreCase(response.getStatus())) {
            LoginResponse.User user = response.getUser();

            // Convert int volunteerId to String
            String volunteerIdStr = String.valueOf(user.getVolunteerId());

            prefManager.createUserSession(
                    user.getId(),
                    user.getUsername(),
                    user.getRole(),
                    volunteerIdStr  // Pass as String
            );

            // Register FCM token after successful login
            registerFCMToken();

            Toast.makeText(this, "Welcome " + user.getUsername(), Toast.LENGTH_SHORT).show();

            // Redirect to MonetaryDonationActivity instead of dashboard
            Intent intent = new Intent(LoginActivity.this, MonetaryDonationActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this,
                    "Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void handleVolunteerLogin(VolunteerLoginResponse response) {
        if ("success".equalsIgnoreCase(response.getStatus())) {
            VolunteerLoginResponse.User user = response.getUser();
            prefManager.createVolunteerSession(
                    user.getId(),
                    user.getPhone(),
                    user.getFull_name()
            );

            // Register FCM token after successful login
            registerFCMToken();

            Toast.makeText(this,
                    "Welcome Volunteer " + user.getFull_name(), Toast.LENGTH_SHORT).show();

            // Redirect to MonetaryDonationActivity instead of VolunteerDashboardActivity
            Intent intent = new Intent(LoginActivity.this, VolunteerDashboardActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this,
                    "Volunteer Login Failed: " + response.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // Add FCM token registration methods
    private void registerFCMToken() {
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();

                    // Save token locally
                    prefManager.setFcmToken(token);

                    // Send token to server
                    sendFcmTokenToServer(token);
                });
    }

    private void sendFcmTokenToServer(String token) {
        int userId = prefManager.getUserId();

        if (userId != 0 && token != null) {
            ApiService apiService = ApiClient.getClient().create(ApiService.class);
            Call<BaseResponse> call = apiService.updateFcmToken(userId, token);
            call.enqueue(new Callback<BaseResponse>() {
                @Override
                public void onResponse(Call<BaseResponse> call, Response<BaseResponse> response) {
                    // Token sent successfully
                }

                @Override
                public void onFailure(Call<BaseResponse> call, Throwable t) {
                    // Failed to send token
                }
            });
        }
    }

    private void showLoginError(Response<LoginResponse> response) {
        String errorMsg = response.body() != null ?
                response.body().getMessage() : "Invalid credentials";
        Toast.makeText(this, "Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
    }

    private void showVolunteerLoginError(Response<VolunteerLoginResponse> response) {
        String errorMsg = response.body() != null ?
                response.body().getMessage() : "Invalid volunteer credentials";
        Toast.makeText(this, "Volunteer Login Failed: " + errorMsg, Toast.LENGTH_SHORT).show();
    }
}