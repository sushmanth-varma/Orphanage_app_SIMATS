////package com.SIMATS.hope;
////
////import android.content.Context;
////import android.content.SharedPreferences;
////
////public class PrefManager {
////    private static final String PREF_NAME = "UserPrefs";
////    private static final String KEY_USER_ID = "user_id";
////    private static final String KEY_VOLUNTEER_ID = "volunteer_id";
////    private static final String KEY_PHONE = "phone";
////    private static final String KEY_FULL_NAME = "full_name";
////    private static final String KEY_USERNAME = "username";
////    private static final String KEY_ROLE = "role";
////    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
////
////    private SharedPreferences pref;
////    private SharedPreferences.Editor editor;
////
////    public PrefManager(Context context) {
////        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
////        editor = pref.edit();
////    }
////
////    // For volunteer login
////    public void createVolunteerSession(int id, String phone, String fullName) {
////        editor.putInt(KEY_USER_ID, id);
////        editor.putInt(KEY_VOLUNTEER_ID, id);
////        editor.putString(KEY_PHONE, phone);
////        editor.putString(KEY_FULL_NAME, fullName);
////        editor.putString(KEY_ROLE, "volunteer");
////        editor.putBoolean(KEY_IS_LOGGED_IN, true);
////        editor.apply();
////    }
////
////    // For regular user login
////    public void createUserSession(int id, String username, String role, int volunteerId) {
////        editor.putInt(KEY_USER_ID, id);
////        editor.putString(KEY_USERNAME, username);
////        editor.putString(KEY_ROLE, role);
////        if (volunteerId > 0) {
////            editor.putInt(KEY_VOLUNTEER_ID, volunteerId);
////        }
////        editor.putBoolean(KEY_IS_LOGGED_IN, true);
////        editor.apply();
////    }
////
////    public boolean isLoggedIn() {
////        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
////    }
////
////    public boolean isVolunteer() {
////        return "volunteer".equals(pref.getString(KEY_ROLE, ""));
////    }
////
////    public int getVolunteerId() {
////        return pref.getInt(KEY_VOLUNTEER_ID, -1);
////    }
////
////    public String getPhone() {
////        return pref.getString(KEY_PHONE, "");
////    }
////
////    public String getFullName() {
////        return pref.getString(KEY_FULL_NAME, "");
////    }
////
////    public String getUsername() {
////        return pref.getString(KEY_USERNAME, "");
////    }
////
////    public String getRole() {
////        return pref.getString(KEY_ROLE, "");
////    }
////
////    public void clearSession() {
////        editor.clear();
////        editor.apply();
////    }
////    public int getUserId() {
////        return pref.getInt(KEY_USER_ID, -1);
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Context;
//import android.content.SharedPreferences;
//
//public class PrefManager {
//    private static final String PREF_NAME = "UserPrefs";
//    private static final String KEY_USER_ID = "user_id";
//    private static final String KEY_VOLUNTEER_ID = "volunteer_id";
//    private static final String KEY_PHONE = "phone";
//    private static final String KEY_FULL_NAME = "full_name";
//    private static final String KEY_USERNAME = "username";
//    private static final String KEY_ROLE = "role";
//    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
//
//    private SharedPreferences pref;
//    private SharedPreferences.Editor editor;
//
//    public PrefManager(Context context) {
//        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
//        editor = pref.edit();
//    }
//
//    // For volunteer login
//    public void createVolunteerSession(int id, String phone, String fullName) {
//        editor.putInt(KEY_USER_ID, id);
//        editor.putInt(KEY_VOLUNTEER_ID, id);
//        editor.putString(KEY_PHONE, phone);
//        editor.putString(KEY_FULL_NAME, fullName);
//        editor.putString(KEY_ROLE, "volunteer");
//        editor.putBoolean(KEY_IS_LOGGED_IN, true);
//        editor.apply();
//    }
//
//    // For regular user login - modified to handle String volunteerId
//    public void createUserSession(int id, String username, String role, String volunteerId) {
//        editor.putInt(KEY_USER_ID, id);
//        editor.putString(KEY_USERNAME, username);
//        editor.putString(KEY_ROLE, role);
//
//        // Convert volunteerId from String to int if it's a valid number
//        try {
//            if (volunteerId != null && !volunteerId.isEmpty() && !volunteerId.equals("0")) {
//                int volId = Integer.parseInt(volunteerId);
//                editor.putInt(KEY_VOLUNTEER_ID, volId);
//            }
//        } catch (NumberFormatException e) {
//            e.printStackTrace();
//            // Handle the case where volunteerId is not a valid number
//        }
//
//        editor.putBoolean(KEY_IS_LOGGED_IN, true);
//        editor.apply();
//    }
//
//    public boolean isLoggedIn() {
//        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
//    }
//
//    public boolean isVolunteer() {
//        return "volunteer".equals(pref.getString(KEY_ROLE, ""));
//    }
//
//    public int getVolunteerId() {
//        return pref.getInt(KEY_VOLUNTEER_ID, -1);
//    }
//
//    public String getPhone() {
//        return pref.getString(KEY_PHONE, "");
//    }
//
//    public String getFullName() {
//        return pref.getString(KEY_FULL_NAME, "");
//    }
//
//    public String getUsername() {
//        return pref.getString(KEY_USERNAME, "");
//    }
//
//    public String getRole() {
//        return pref.getString(KEY_ROLE, "");
//    }
//
//    public void clearSession() {
//        editor.clear();
//        editor.apply();
//    }
//
//    public int getUserId() {
//        return pref.getInt(KEY_USER_ID, -1);
//    }
//
//}
package com.SIMATS.hope;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    private static final String PREF_NAME = "UserPrefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_VOLUNTEER_ID = "volunteer_id";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_FULL_NAME = "full_name";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_ROLE = "role";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_FCM_TOKEN = "fcm_token"; // Add this

    private SharedPreferences pref;
    private SharedPreferences.Editor editor;

    public PrefManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    // For volunteer login
    public void createVolunteerSession(int id, String phone, String fullName) {
        editor.putInt(KEY_USER_ID, id);
        editor.putInt(KEY_VOLUNTEER_ID, id);
        editor.putString(KEY_PHONE, phone);
        editor.putString(KEY_FULL_NAME, fullName);
        editor.putString(KEY_ROLE, "volunteer");
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.apply();
    }

    // For regular user login - modified to handle String volunteerId
    public void createUserSession(int id, String username, String role, String volunteerId) {
        editor.putInt(KEY_USER_ID, id);
        editor.putString(KEY_USERNAME, username);
        editor.putString(KEY_ROLE, role);

        // Convert volunteerId from String to int if it's a valid number
        try {
            if (volunteerId != null && !volunteerId.isEmpty() && !volunteerId.equals("0")) {
                int volId = Integer.parseInt(volunteerId);
                editor.putInt(KEY_VOLUNTEER_ID, volId);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            // Handle the case where volunteerId is not a valid number
        }

        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.apply();
    }

    // FCM Token methods
    public void setFcmToken(String token) {
        editor.putString(KEY_FCM_TOKEN, token);
        editor.apply();
    }

    public String getFcmToken() {
        return pref.getString(KEY_FCM_TOKEN, null);
    }

    public boolean hasFcmToken() {
        return pref.contains(KEY_FCM_TOKEN) && getFcmToken() != null;
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public boolean isVolunteer() {
        return "volunteer".equals(pref.getString(KEY_ROLE, ""));
    }

    public int getVolunteerId() {
        return pref.getInt(KEY_VOLUNTEER_ID, -1);
    }

    public String getPhone() {
        return pref.getString(KEY_PHONE, "");
    }

    public String getFullName() {
        return pref.getString(KEY_FULL_NAME, "");
    }

    public String getUsername() {
        return pref.getString(KEY_USERNAME, "");
    }

    public String getRole() {
        return pref.getString(KEY_ROLE, "");
    }

    public void clearSession() {
        editor.clear();
        editor.apply();
    }

    public int getUserId() {
        return pref.getInt(KEY_USER_ID, -1);
    }
}