package com.SIMATS.hope;

public class AssignVolunteerRequest {
    private int report_id;
    private int volunteer_id;

    public AssignVolunteerRequest(int report_id, int volunteer_id) {
        this.report_id = report_id;
        this.volunteer_id = volunteer_id;
    }

    // Getters
    public int getReport_id() {
        return report_id;
    }

    public int getVolunteer_id() {
        return volunteer_id;
    }
}