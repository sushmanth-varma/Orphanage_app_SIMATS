package com.SIMATS.hope;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class DonationStatusUpdateActivity_volunteer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation_status_update);

        Spinner spinnerDonationId = findViewById(R.id.spinnerDonationId);
        Spinner spinnerStatus = findViewById(R.id.spinnerStatus);
        Button btnUpdate = findViewById(R.id.btnUpdateStatus);

        // Sample donation IDs (replace with real data later)
        List<String> donationIds = new ArrayList<>();
        donationIds.add("1 - Rice Bags (Pending)");
        donationIds.add("2 - Clothes (Collected)");
        donationIds.add("3 - Books (Assigned)");

        // Status options
        String[] statusOptions = {"Pending", "Collected", "Delivered", "Cancelled"};

        // Set up adapters for spinners
        ArrayAdapter<String> donationIdAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                donationIds
        );
        donationIdAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDonationId.setAdapter(donationIdAdapter);

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                statusOptions
        );
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(statusAdapter);

        btnUpdate.setOnClickListener(v -> {
            String selectedDonation = spinnerDonationId.getSelectedItem().toString();
            String newStatus = spinnerStatus.getSelectedItem().toString();

            // Extract just the ID from the selection
            String donationId = selectedDonation.split(" - ")[0];

            Toast.makeText(this,
                    "Would update donation #" + donationId + " to status: " + newStatus,
                    Toast.LENGTH_SHORT).show();

            // In real implementation, you would:
            // 1. Call API to update status
            // 2. Handle success/failure
            // 3. Maybe return to previous screen
        });
    }
}