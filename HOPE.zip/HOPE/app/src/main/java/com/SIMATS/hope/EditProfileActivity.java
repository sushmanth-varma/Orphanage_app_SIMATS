package com.SIMATS.hope;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.IOException;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditProfileActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_PROFILE_PHOTO = "profile_photo";

    private EditText editName;
    private ImageView ivProfile;
    private Button btnSave;
    private Uri profileImageUri;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        editName = findViewById(R.id.editName);
        ivProfile = findViewById(R.id.ivProfile);
        btnSave = findViewById(R.id.btnSave);

        // Get user data from SharedPreferences
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        userId = prefs.getInt(KEY_USER_ID, -1);
        String userName = prefs.getString(KEY_USER_NAME, "");
        String profilePhoto = prefs.getString(KEY_PROFILE_PHOTO, "");

        // Set current data
        editName.setText(userName);
        if (!profilePhoto.isEmpty()) {
            Glide.with(this)
                    .load(profilePhoto)
                    .placeholder(R.drawable.ic_user)
                    .into(ivProfile);
        }

        ivProfile.setOnClickListener(v -> openGallery());
        btnSave.setOnClickListener(v -> updateProfile());
    }

    private void updateProfile() {
        String name = editName.getText().toString().trim();

        if (name.isEmpty() && profileImageUri == null) {
            Toast.makeText(this, "Please enter at least one field to update", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create request parts
        RequestBody userIdBody = RequestBody.create(MultipartBody.FORM, String.valueOf(userId));
        RequestBody nameBody = RequestBody.create(MultipartBody.FORM, name);

        MultipartBody.Part imagePart = null;
        if (profileImageUri != null) {
            try {
                File file = FileUtil.from(this, profileImageUri);
                RequestBody requestFile = RequestBody.create(MultipartBody.FORM, file);
                imagePart = MultipartBody.Part.createFormData("profile_photo", file.getName(), requestFile);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Error processing image", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Make API call
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ProfileUpdateResponse> call = apiService.updateProfile(userIdBody, nameBody, imagePart);

        call.enqueue(new Callback<ProfileUpdateResponse>() {
            @Override
            public void onResponse(Call<ProfileUpdateResponse> call, Response<ProfileUpdateResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ProfileUpdateResponse updateResponse = response.body();
                    if ("success".equals(updateResponse.getStatus())) {
                        // Update SharedPreferences
                        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString(KEY_USER_NAME, updateResponse.getData().getName());
                        if (updateResponse.getData().getProfilePhotoUrl() != null) {
                            editor.putString(KEY_PROFILE_PHOTO, updateResponse.getData().getProfilePhotoUrl());
                        }
                        editor.apply();

                        // Prepare result to send back
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("updated_name", updateResponse.getData().getName());
                        if (updateResponse.getData().getProfilePhotoUrl() != null) {
                            resultIntent.putExtra("updated_photo_url", updateResponse.getData().getProfilePhotoUrl());
                        }
                        setResult(RESULT_OK, resultIntent);

                        Toast.makeText(EditProfileActivity.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(EditProfileActivity.this, updateResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EditProfileActivity.this, "Failed to update profile", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ProfileUpdateResponse> call, Throwable t) {
                Toast.makeText(EditProfileActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            profileImageUri = data.getData();
            Glide.with(this)
                    .load(profileImageUri)
                    .placeholder(R.drawable.ic_user)
                    .into(ivProfile);
        }
    }
}