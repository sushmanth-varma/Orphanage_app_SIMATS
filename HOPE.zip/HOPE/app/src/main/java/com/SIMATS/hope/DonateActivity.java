package com.SIMATS.hope;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DonateActivity extends AppCompatActivity {
    private CardView btnMonetary, btnMaterial;
    private ImageView ivBack;
    private BottomNavigationView bottomNavigationView;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donate);

        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        initializeViews();
        setupClickListeners();
        setupBottomNavigation();
    }

    private void initializeViews() {
        btnMonetary = findViewById(R.id.btnMonetary);
        btnMaterial = findViewById(R.id.btnMaterial);
        ivBack = findViewById(R.id.ivBack);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Add animation
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        btnMonetary.startAnimation(fadeIn);
        btnMaterial.startAnimation(fadeIn);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                startActivity(new Intent(DonateActivity.this, DashboardActivity.class));
                return true;
            } else if (itemId == R.id.nav_donate) {
                // Already on donate page
                return true;
            } else if (itemId == R.id.nav_report) {
                startActivity(new Intent(DonateActivity.this, ReportChildActivity.class));
                return true;
            } else if (itemId == R.id.nav_volunteer) {
                startActivity(new Intent(DonateActivity.this, VolunteerRequestActivity.class));
                return true;
            } else if (itemId == R.id.nav_profile) {
                startActivity(new Intent(DonateActivity.this, SettingsActivity.class));
                return true;
            }
            return false;
        });

        // Set donate as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_donate);
    }

    private void setupClickListeners() {
        btnMonetary.setOnClickListener(v -> {
            saveDonationType("Monetary");
            startActivityWithAnimation(MonetaryDonationActivity.class);
        });

        btnMaterial.setOnClickListener(v -> {
            saveDonationType("Material");
            startActivityWithAnimation(MaterialDonationActivity.class);
        });

        // Add back button functionality
        ivBack.setOnClickListener(v -> finish());
    }

    private void saveDonationType(String type) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("last_donation_type", type);
        editor.apply();
    }

    private void startActivityWithAnimation(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Set donate as selected when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_donate);
        }
    }
}