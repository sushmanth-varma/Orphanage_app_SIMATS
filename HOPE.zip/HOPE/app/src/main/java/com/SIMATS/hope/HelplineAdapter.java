//package com.SIMATS.hope;
//
//public class HelplineAdapter {
//}
