//////package com.SIMATS.hope;
//////
//////import android.Manifest;
//////import android.app.AlertDialog;
//////import android.content.Intent;
//////import android.content.SharedPreferences;
//////import android.content.pm.PackageManager;
//////import android.graphics.Bitmap;
//////import android.location.Location;
//////import android.net.Uri;
//////import android.os.Build;
//////import android.os.Bundle;
//////import android.provider.MediaStore;
//////import android.util.Log;
//////import android.widget.ArrayAdapter;
//////import android.widget.Button;
//////import android.widget.CheckBox;
//////import android.widget.EditText;
//////import android.widget.ImageView;
//////import android.widget.Spinner;
//////import android.widget.Toast;
//////
//////import androidx.annotation.NonNull;
//////import androidx.annotation.Nullable;
//////import androidx.appcompat.app.AppCompatActivity;
//////import androidx.core.app.ActivityCompat;
//////import androidx.core.content.ContextCompat;
//////import androidx.core.content.FileProvider;
//////
//////import com.google.android.gms.location.FusedLocationProviderClient;
//////import com.google.android.gms.location.LocationServices;
//////import com.google.android.gms.tasks.OnSuccessListener;
//////
//////import java.io.ByteArrayOutputStream;
//////import java.io.File;
//////import java.io.FileOutputStream;
//////import java.io.IOException;
//////import java.text.SimpleDateFormat;
//////import java.util.Date;
//////import java.util.Locale;
//////
//////import okhttp3.MultipartBody;
//////import okhttp3.RequestBody;
//////import okhttp3.ResponseBody;
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////
//////public class ReportChildActivity extends AppCompatActivity {
//////
//////    private static final int PERMISSION_REQUEST_CODE = 100;
//////    private static final int PICK_IMAGE = 101;
//////    private static final int CAMERA_REQUEST = 102;
//////    private static final int LOCATION_PERMISSION_REQUEST_CODE = 200;
//////    private static final int STORAGE_PERMISSION_CODE = 300;
//////
//////    private Spinner spinnerType;
//////    private EditText editName, editAge, editCity, editLocation, editDetails;
//////    private CheckBox checkboxAnonymous;
//////    private Button btnUploadPhoto, btnSubmitReport;
//////    private Button mapPlaceholder;
//////    private ImageView imagePreview;
//////
//////    private Uri selectedImageUri;
//////    private Bitmap selectedBitmap;
//////    private FusedLocationProviderClient fusedLocationClient;
//////    private String currentPhotoPath;
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.activity_report_child);
//////
//////        // Initialize Views
//////        spinnerType = findViewById(R.id.spinnerType);
//////        editName = findViewById(R.id.editName);
//////        editAge = findViewById(R.id.editAge);
//////        editCity = findViewById(R.id.editCity);
//////        editLocation = findViewById(R.id.getlocation);
//////        editDetails = findViewById(R.id.editDetails);
//////        checkboxAnonymous = findViewById(R.id.checkboxAnonymous);
//////        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
//////        btnSubmitReport = findViewById(R.id.btnSubmitReport);
//////        mapPlaceholder = findViewById(R.id.mapPlaceholder);
//////        imagePreview = findViewById(R.id.imagePreview);
//////
//////        // Initialize location client
//////        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
//////
//////        // Setup spinner
//////        String[] personTypes = {"Child", "Orphan", "Homeless", "Injured", "Other"};
//////        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, personTypes);
//////        spinnerType.setAdapter(adapter);
//////
//////        // Set click listeners
//////        btnUploadPhoto.setOnClickListener(v -> checkAndRequestPermissions());
//////
//////        mapPlaceholder.setOnClickListener(v -> {
//////            if (checkLocationPermission()) {
//////                getCurrentLocation();
//////            } else {
//////                requestLocationPermission();
//////            }
//////        });
//////
//////        btnSubmitReport.setOnClickListener(v -> submitReport());
//////    }
//////
//////    private void checkAndRequestPermissions() {
//////        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//////            // For Android 13+, we need READ_MEDIA_IMAGES permission
//////            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED ||
//////                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//////
//////                ActivityCompat.requestPermissions(this,
//////                        new String[]{
//////                                Manifest.permission.READ_MEDIA_IMAGES,
//////                                Manifest.permission.CAMERA
//////                        },
//////                        PERMISSION_REQUEST_CODE);
//////            } else {
//////                showImagePickerDialog();
//////            }
//////        } else {
//////            // For older versions, we need READ_EXTERNAL_STORAGE and CAMERA permissions
//////            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
//////                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//////
//////                ActivityCompat.requestPermissions(this,
//////                        new String[]{
//////                                Manifest.permission.READ_EXTERNAL_STORAGE,
//////                                Manifest.permission.CAMERA
//////                        },
//////                        PERMISSION_REQUEST_CODE);
//////            } else {
//////                showImagePickerDialog();
//////            }
//////        }
//////    }
//////
//////    private boolean checkLocationPermission() {
//////        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
//////    }
//////
//////    private void requestLocationPermission() {
//////        ActivityCompat.requestPermissions(this,
//////                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//////                LOCATION_PERMISSION_REQUEST_CODE);
//////    }
//////
//////    private void getCurrentLocation() {
//////        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//////            return;
//////        }
//////
//////        fusedLocationClient.getLastLocation()
//////                .addOnSuccessListener(this, location -> {
//////                    if (location != null) {
//////                        double latitude = location.getLatitude();
//////                        double longitude = location.getLongitude();
//////                        editLocation.setText(latitude + ", " + longitude);
//////                        Toast.makeText(this, "Location obtained: " + latitude + ", " + longitude, Toast.LENGTH_LONG).show();
//////                    } else {
//////                        Toast.makeText(this, "Unable to get location. Make sure location is enabled.", Toast.LENGTH_SHORT).show();
//////                    }
//////                });
//////    }
//////
//////    private void showImagePickerDialog() {
//////        String[] options = {"Take Photo", "Choose from Gallery"};
//////        new AlertDialog.Builder(this)
//////                .setTitle("Select Photo")
//////                .setItems(options, (dialog, which) -> {
//////                    if (which == 0) {
//////                        dispatchTakePictureIntent();
//////                    } else if (which == 1) {
//////                        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//////                        startActivityForResult(galleryIntent, PICK_IMAGE);
//////                    }
//////                })
//////                .show();
//////    }
//////
//////    private File createImageFile() throws IOException {
//////        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
//////        String imageFileName = "JPEG_" + timeStamp + "_";
//////        File storageDir = getExternalFilesDir("HopeApp");
//////        File image = File.createTempFile(
//////                imageFileName,  /* prefix */
//////                ".jpg",         /* suffix */
//////                storageDir      /* directory */
//////        );
//////
//////        currentPhotoPath = image.getAbsolutePath();
//////        return image;
//////    }
//////
//////    private void dispatchTakePictureIntent() {
//////        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//////        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
//////            File photoFile = null;
//////            try {
//////                photoFile = createImageFile();
//////            } catch (IOException ex) {
//////                Toast.makeText(this, "Error occurred while creating the File", Toast.LENGTH_SHORT).show();
//////            }
//////
//////            if (photoFile != null) {
//////                selectedImageUri = FileProvider.getUriForFile(this,
//////                        "com.SIMATS.hope.fileprovider",
//////                        photoFile);
//////                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, selectedImageUri);
//////                startActivityForResult(takePictureIntent, CAMERA_REQUEST);
//////            }
//////        }
//////    }
//////
//////    @Override
//////    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//////        super.onActivityResult(requestCode, resultCode, data);
//////        if (resultCode == RESULT_OK) {
//////            if (requestCode == PICK_IMAGE && data != null) {
//////                selectedImageUri = data.getData();
//////                try {
//////                    selectedBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
//////                    imagePreview.setImageBitmap(selectedBitmap);
//////                    imagePreview.setVisibility(ImageView.VISIBLE);
//////                } catch (IOException e) {
//////                    e.printStackTrace();
//////                }
//////            } else if (requestCode == CAMERA_REQUEST) {
//////                try {
//////                    selectedBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
//////                    imagePreview.setImageBitmap(selectedBitmap);
//////                    imagePreview.setVisibility(ImageView.VISIBLE);
//////                } catch (IOException e) {
//////                    e.printStackTrace();
//////                }
//////            }
//////        }
//////    }
//////
//////    @Override
//////    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//////        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//////        if (requestCode == PERMISSION_REQUEST_CODE) {
//////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//////                showImagePickerDialog();
//////            } else {
//////                Toast.makeText(this, "Permissions are required to upload photos", Toast.LENGTH_SHORT).show();
//////            }
//////        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
//////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//////                getCurrentLocation();
//////            } else {
//////                Toast.makeText(this, "Location permission is required to get your current location", Toast.LENGTH_SHORT).show();
//////            }
//////        }
//////    }
//////
//////    private void submitReport() {
//////        // Get user ID from SharedPreferences
//////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////        int userId = prefs.getInt("user_id", 0);
//////
//////        if (userId == 0) {
//////            Toast.makeText(this, "Please login to submit a report", Toast.LENGTH_SHORT).show();
//////            return;
//////        }
//////
//////        String type = spinnerType.getSelectedItem().toString();
//////        String name = checkboxAnonymous.isChecked() ? "Anonymous" : editName.getText().toString().trim();
//////        String age = editAge.getText().toString().trim();
//////        String city = editCity.getText().toString().trim();
//////        String exactLocation = editLocation.getText().toString().trim();
//////        String details = editDetails.getText().toString().trim();
//////        boolean anonymous = checkboxAnonymous.isChecked();
//////
//////        if (type.isEmpty() || age.isEmpty() || city.isEmpty() || details.isEmpty()) {
//////            Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
//////            return;
//////        }
//////
//////        // Create request parts with actual user ID
//////        RequestBody userIdBody = RequestBody.create(MultipartBody.FORM, String.valueOf(userId)); // Changed this line
//////        RequestBody typeBody = RequestBody.create(MultipartBody.FORM, type);
//////        RequestBody nameBody = RequestBody.create(MultipartBody.FORM, name);
//////        RequestBody ageBody = RequestBody.create(MultipartBody.FORM, age);
//////        RequestBody generalLocationBody = RequestBody.create(MultipartBody.FORM, city);
//////        RequestBody exactLocationBody = RequestBody.create(MultipartBody.FORM, exactLocation);
//////        RequestBody detailsBody = RequestBody.create(MultipartBody.FORM, details);
//////        RequestBody isAnonymousBody = RequestBody.create(MultipartBody.FORM, anonymous ? "1" : "0");
//////
//////        MultipartBody.Part photoPart = null;
//////        if (selectedBitmap != null) {
//////            File file = bitmapToFile(selectedBitmap);
//////            RequestBody requestFile = RequestBody.create(MultipartBody.FORM, file);
//////            photoPart = MultipartBody.Part.createFormData("photo", file.getName(), requestFile);
//////        }
//////
//////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////        Call<ResponseBody> call = apiService.submitReport(
//////                userId, typeBody, nameBody, ageBody, generalLocationBody,
//////                exactLocationBody, detailsBody, isAnonymousBody, photoPart);
//////
//////        call.enqueue(new Callback<ResponseBody>() {
//////            @Override
//////            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//////                if (response.isSuccessful()) {
//////                    try {
//////                        String responseString = response.body().string();
//////                        Log.d("API_RESPONSE", responseString);
//////                        showSuccessDialog();
//////                    } catch (IOException e) {
//////                        e.printStackTrace();
//////                        Toast.makeText(ReportChildActivity.this, "Error reading response", Toast.LENGTH_SHORT).show();
//////                    }
//////                } else {
//////                    Toast.makeText(ReportChildActivity.this, "Submission failed: " + response.code(), Toast.LENGTH_SHORT).show();
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<ResponseBody> call, Throwable t) {
//////                Toast.makeText(ReportChildActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////                Log.e("API_ERROR", t.getMessage(), t);
//////            }
//////        });
//////    }
//////
//////    private File bitmapToFile(Bitmap bitmap) {
//////        File file = new File(getCacheDir(), "photo_" + System.currentTimeMillis() + ".jpg");
//////        try {
//////            file.createNewFile();
//////            ByteArrayOutputStream bos = new ByteArrayOutputStream();
//////            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, bos);
//////            byte[] bitmapdata = bos.toByteArray();
//////
//////            FileOutputStream fos = new FileOutputStream(file);
//////            fos.write(bitmapdata);
//////            fos.flush();
//////            fos.close();
//////        } catch (IOException e) {
//////            e.printStackTrace();
//////        }
//////        return file;
//////    }
//////
//////    private void showSuccessDialog() {
//////        new AlertDialog.Builder(this)
//////                .setTitle("Report Submitted")
//////                .setMessage("Thank you for your report. We will take necessary action.")
//////                .setCancelable(false)
//////                .setPositiveButton("Go to Dashboard", (dialog, which) -> {
//////                    Intent intent = new Intent(ReportChildActivity.this, DashboardActivity.class);
//////                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
//////                    startActivity(intent);
//////                    finish();
//////                }).show();
//////    }
//////}
//////package com.SIMATS.hope;
//////
//////import android.Manifest;
//////import android.app.AlertDialog;
//////import android.content.Intent;
//////import android.content.SharedPreferences;
//////import android.content.pm.PackageManager;
//////import android.graphics.Bitmap;
//////import android.location.Location;
//////import android.net.Uri;
//////import android.os.Build;
//////import android.os.Bundle;
//////import android.provider.MediaStore;
//////import android.util.Log;
//////import android.widget.ArrayAdapter;
//////import android.widget.Button;
//////import android.widget.CheckBox;
//////import android.widget.EditText;
//////import android.widget.ImageView;
//////import android.widget.Spinner;
//////import android.widget.Toast;
//////
//////import androidx.annotation.NonNull;
//////import androidx.annotation.Nullable;
//////import androidx.appcompat.app.AppCompatActivity;
//////import androidx.core.app.ActivityCompat;
//////import androidx.core.content.ContextCompat;
//////import androidx.core.content.FileProvider;
//////
//////import com.google.android.gms.location.FusedLocationProviderClient;
//////import com.google.android.gms.location.LocationServices;
//////import com.google.android.gms.tasks.OnSuccessListener;
//////
//////import java.io.ByteArrayOutputStream;
//////import java.io.File;
//////import java.io.FileOutputStream;
//////import java.io.IOException;
//////import java.text.SimpleDateFormat;
//////import java.util.Date;
//////import java.util.Locale;
//////
//////import okhttp3.MediaType;
//////import okhttp3.MultipartBody;
//////import okhttp3.RequestBody;
//////import okhttp3.ResponseBody;
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////
//////public class ReportChildActivity extends AppCompatActivity {
//////
//////    private static final int PERMISSION_REQUEST_CODE = 100;
//////    private static final int PICK_IMAGE = 101;
//////    private static final int CAMERA_REQUEST = 102;
//////    private static final int LOCATION_PERMISSION_REQUEST_CODE = 200;
//////
//////    private Spinner spinnerType;
//////    private EditText editName, editAge, editCity, editLocation, editDetails;
//////    private CheckBox checkboxAnonymous;
//////    private Button btnUploadPhoto, btnSubmitReport;
//////    private Button mapPlaceholder;
//////    private ImageView imagePreview;
//////
//////    private Uri selectedImageUri;
//////    private Bitmap selectedBitmap;
//////    private FusedLocationProviderClient fusedLocationClient;
//////    private String currentPhotoPath;
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.activity_report_child);
//////
//////        // Initialize Views
//////        spinnerType = findViewById(R.id.spinnerType);
//////        editName = findViewById(R.id.editName);
//////        editAge = findViewById(R.id.editAge);
//////        editCity = findViewById(R.id.editCity);
//////        editLocation = findViewById(R.id.getlocation);
//////        editDetails = findViewById(R.id.editDetails);
//////        checkboxAnonymous = findViewById(R.id.checkboxAnonymous);
//////        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
//////        btnSubmitReport = findViewById(R.id.btnSubmitReport);
//////        mapPlaceholder = findViewById(R.id.mapPlaceholder);
//////        imagePreview = findViewById(R.id.imagePreview);
//////
//////        // Initialize location client
//////        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
//////
//////        // Setup spinner
//////        String[] personTypes = {"Child", "Orphan", "Homeless", "Injured", "Other"};
//////        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, personTypes);
//////        spinnerType.setAdapter(adapter);
//////
//////        // Set click listeners
//////        btnUploadPhoto.setOnClickListener(v -> checkAndRequestPermissions());
//////        mapPlaceholder.setOnClickListener(v -> requestLocationPermission());
//////        btnSubmitReport.setOnClickListener(v -> submitReport());
//////    }
//////
//////    private void checkAndRequestPermissions() {
//////        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//////            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED ||
//////                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//////                ActivityCompat.requestPermissions(this,
//////                        new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.CAMERA},
//////                        PERMISSION_REQUEST_CODE);
//////            } else {
//////                showImagePickerDialog();
//////            }
//////        } else {
//////            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
//////                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//////                ActivityCompat.requestPermissions(this,
//////                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
//////                        PERMISSION_REQUEST_CODE);
//////            } else {
//////                showImagePickerDialog();
//////            }
//////        }
//////    }
//////
//////    private void requestLocationPermission() {
//////        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//////            ActivityCompat.requestPermissions(this,
//////                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//////                    LOCATION_PERMISSION_REQUEST_CODE);
//////        } else {
//////            getCurrentLocation();
//////        }
//////    }
//////
//////    private void getCurrentLocation() {
//////        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//////            return;
//////        }
//////
//////        fusedLocationClient.getLastLocation()
//////                .addOnSuccessListener(this, location -> {
//////                    if (location != null) {
//////                        double latitude = location.getLatitude();
//////                        double longitude = location.getLongitude();
//////                        editLocation.setText(latitude + ", " + longitude);
//////                        Toast.makeText(this, "Location captured", Toast.LENGTH_SHORT).show();
//////                    } else {
//////                        Toast.makeText(this, "Unable to get location", Toast.LENGTH_SHORT).show();
//////                    }
//////                });
//////    }
//////
//////    private void showImagePickerDialog() {
//////        String[] options = {"Take Photo", "Choose from Gallery"};
//////        new AlertDialog.Builder(this)
//////                .setTitle("Select Photo")
//////                .setItems(options, (dialog, which) -> {
//////                    if (which == 0) {
//////                        dispatchTakePictureIntent();
//////                    } else {
//////                        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//////                        startActivityForResult(galleryIntent, PICK_IMAGE);
//////                    }
//////                })
//////                .show();
//////    }
//////
//////    private File createImageFile() throws IOException {
//////        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
//////        String imageFileName = "JPEG_" + timeStamp + "_";
//////        File storageDir = getExternalFilesDir("HopeApp");
//////        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
//////        currentPhotoPath = image.getAbsolutePath();
//////        return image;
//////    }
//////
//////    private void dispatchTakePictureIntent() {
//////        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//////        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
//////            File photoFile = null;
//////            try {
//////                photoFile = createImageFile();
//////            } catch (IOException ex) {
//////                Toast.makeText(this, "Error creating file", Toast.LENGTH_SHORT).show();
//////            }
//////
//////            if (photoFile != null) {
//////                selectedImageUri = FileProvider.getUriForFile(this,
//////                        "com.SIMATS.hope.fileprovider",
//////                        photoFile);
//////                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, selectedImageUri);
//////                startActivityForResult(takePictureIntent, CAMERA_REQUEST);
//////            }
//////        }
//////    }
//////
//////    @Override
//////    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//////        super.onActivityResult(requestCode, resultCode, data);
//////        if (resultCode == RESULT_OK) {
//////            try {
//////                if (requestCode == PICK_IMAGE && data != null) {
//////                    selectedImageUri = data.getData();
//////                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
//////                } else if (requestCode == CAMERA_REQUEST) {
//////                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
//////                }
//////                imagePreview.setImageBitmap(selectedBitmap);
//////                imagePreview.setVisibility(ImageView.VISIBLE);
//////            } catch (IOException e) {
//////                e.printStackTrace();
//////                Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show();
//////            }
//////        }
//////    }
//////
//////    @Override
//////    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//////        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//////        if (requestCode == PERMISSION_REQUEST_CODE) {
//////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//////                showImagePickerDialog();
//////            } else {
//////                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
//////            }
//////        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
//////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//////                getCurrentLocation();
//////            }
//////        }
//////    }
//////
//////    private void submitReport() {
//////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////        int userId = prefs.getInt("user_id", 0);
//////        if (userId == 0) {
//////            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
//////            return;
//////        }
//////
//////        String type = spinnerType.getSelectedItem().toString();
//////        String name = checkboxAnonymous.isChecked() ? "Anonymous" : editName.getText().toString().trim();
//////        String age = editAge.getText().toString().trim();
//////        String city = editCity.getText().toString().trim();
//////        String exactLocation = editLocation.getText().toString().trim();
//////        String details = editDetails.getText().toString().trim();
//////
//////        if (type.isEmpty() || city.isEmpty() || details.isEmpty()) {
//////            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
//////            return;
//////        }
//////
//////        // Create request parts
//////        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(userId));
//////        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), type);
//////        RequestBody nameBody = RequestBody.create(MediaType.parse("text/plain"), name);
//////        RequestBody ageBody = RequestBody.create(MediaType.parse("text/plain"), age);
//////        RequestBody generalLocationBody = RequestBody.create(MediaType.parse("text/plain"), city);
//////        RequestBody exactLocationBody = RequestBody.create(MediaType.parse("text/plain"), exactLocation);
//////        RequestBody detailsBody = RequestBody.create(MediaType.parse("text/plain"), details);
//////        RequestBody isAnonymousBody = RequestBody.create(MediaType.parse("text/plain"), checkboxAnonymous.isChecked() ? "1" : "0");
//////
//////        MultipartBody.Part photoPart = null;
//////        if (selectedBitmap != null) {
//////            File file = bitmapToFile(selectedBitmap);
//////            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
//////            photoPart = MultipartBody.Part.createFormData("photo", file.getName(), requestFile);
//////        }
//////
//////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////        Call<ResponseBody> call = apiService.submitReport(
//////                userIdBody, typeBody, nameBody, ageBody, generalLocationBody,
//////                exactLocationBody, detailsBody, isAnonymousBody, photoPart);
//////
//////
//////        call.enqueue(new Callback<ResponseBody>() {
//////            @Override
//////            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//////                try {
//////                    if (response.isSuccessful()) {
//////                        String responseString = response.body().string();
//////                        Log.d("API_SUCCESS", responseString);
//////                        showSuccessDialog();
//////                    } else {
//////                        String error = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
//////                        Log.e("API_ERROR", error);
//////                        Toast.makeText(ReportChildActivity.this, "Upload failed: " + error, Toast.LENGTH_LONG).show();
//////                    }
//////                } catch (IOException e) {
//////                    e.printStackTrace();
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<ResponseBody> call, Throwable t) {
//////                Toast.makeText(ReportChildActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////                Log.e("NETWORK_ERROR", t.getMessage(), t);
//////            }
//////        });
//////    }
//////
//////    private File bitmapToFile(Bitmap bitmap) {
//////        File file = new File(getCacheDir(), "upload_" + System.currentTimeMillis() + ".jpg");
//////        try (FileOutputStream out = new FileOutputStream(file)) {
//////            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
//////        } catch (IOException e) {
//////            e.printStackTrace();
//////        }
//////        return file;
//////    }
//////
//////    private void showSuccessDialog() {
//////        new AlertDialog.Builder(this)
//////                .setTitle("Success")
//////                .setMessage("Report submitted successfully")
//////                .setPositiveButton("OK", (dialog, which) -> finish())
//////                .show();
//////    }
//////}
////package com.SIMATS.hope;
////
////import android.Manifest;
////import android.app.AlertDialog;
////import android.content.Intent;
////import android.content.SharedPreferences;
////import android.content.pm.PackageManager;
////import android.graphics.Bitmap;
////import android.location.Location;
////import android.net.Uri;
////import android.os.Build;
////import android.os.Bundle;
////import android.provider.MediaStore;
////import android.util.Log;
////import android.view.View;
////import android.widget.ArrayAdapter;
////import android.widget.Button;
////import android.widget.CheckBox;
////import android.widget.EditText;
////import android.widget.ImageView;
////import android.widget.Spinner;
////import android.widget.Toast;
////
////import androidx.annotation.NonNull;
////import androidx.annotation.Nullable;
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.core.app.ActivityCompat;
////import androidx.core.content.ContextCompat;
////import androidx.core.content.FileProvider;
////
////import com.google.android.gms.location.FusedLocationProviderClient;
////import com.google.android.gms.location.LocationServices;
////import com.google.android.gms.tasks.OnSuccessListener;
////
////import java.io.ByteArrayOutputStream;
////import java.io.File;
////import java.io.FileOutputStream;
////import java.io.IOException;
////import java.text.SimpleDateFormat;
////import java.util.Date;
////import java.util.Locale;
////
////import okhttp3.MediaType;
////import okhttp3.MultipartBody;
////import okhttp3.RequestBody;
////import okhttp3.ResponseBody;
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class ReportChildActivity extends AppCompatActivity {
////
////    private static final int PERMISSION_REQUEST_CODE = 100;
////    private static final int PICK_IMAGE = 101;
////    private static final int CAMERA_REQUEST = 102;
////    private static final int LOCATION_PERMISSION_REQUEST_CODE = 200;
////
////    private Spinner spinnerType;
////    private EditText editName, editAge, editCity, editLocation, editDetails;
////    private CheckBox checkboxAnonymous;
////    private Button btnUploadPhoto, btnSubmitReport;
////    private Button mapPlaceholder;
////    private ImageView imagePreview;
////    private ImageView ivBack; // Added back button reference
////
////    private Uri selectedImageUri;
////    private Bitmap selectedBitmap;
////    private FusedLocationProviderClient fusedLocationClient;
////    private String currentPhotoPath;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_report_child);
////
////        // Initialize Views
////        spinnerType = findViewById(R.id.spinnerType);
////        editName = findViewById(R.id.editName);
////        editAge = findViewById(R.id.editAge);
////        editCity = findViewById(R.id.editCity);
////        editLocation = findViewById(R.id.getlocation);
////        editDetails = findViewById(R.id.editDetails);
////        checkboxAnonymous = findViewById(R.id.checkboxAnonymous);
////        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
////        btnSubmitReport = findViewById(R.id.btnSubmitReport);
////        mapPlaceholder = findViewById(R.id.mapPlaceholder);
////        imagePreview = findViewById(R.id.imagePreview);
////        ivBack = findViewById(R.id.ivBack); // Initialize back button
////
////        // Initialize location client
////        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
////
////        // Setup spinner
////        String[] personTypes = {"Child", "Orphan", "Homeless", "Injured", "Other"};
////        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, personTypes);
////        spinnerType.setAdapter(adapter);
////
////        // Set click listeners
////        btnUploadPhoto.setOnClickListener(v -> checkAndRequestPermissions());
////        mapPlaceholder.setOnClickListener(v -> requestLocationPermission());
////        btnSubmitReport.setOnClickListener(v -> submitReport());
////
////        // Add back button functionality
////        ivBack.setOnClickListener(v -> finish());
////    }
////
////    private void checkAndRequestPermissions() {
////        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
////            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED ||
////                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
////                ActivityCompat.requestPermissions(this,
////                        new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.CAMERA},
////                        PERMISSION_REQUEST_CODE);
////            } else {
////                showImagePickerDialog();
////            }
////        } else {
////            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
////                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
////                ActivityCompat.requestPermissions(this,
////                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
////                        PERMISSION_REQUEST_CODE);
////            } else {
////                showImagePickerDialog();
////            }
////        }
////    }
////
////    private void requestLocationPermission() {
////        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
////            ActivityCompat.requestPermissions(this,
////                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
////                    LOCATION_PERMISSION_REQUEST_CODE);
////        } else {
////            getCurrentLocation();
////        }
////    }
////
////    private void getCurrentLocation() {
////        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
////            return;
////        }
////
////        fusedLocationClient.getLastLocation()
////                .addOnSuccessListener(this, location -> {
////                    if (location != null) {
////                        double latitude = location.getLatitude();
////                        double longitude = location.getLongitude();
////                        editLocation.setText(latitude + ", " + longitude);
////                        Toast.makeText(this, "Location captured", Toast.LENGTH_SHORT).show();
////                    } else {
////                        Toast.makeText(this, "Unable to get location", Toast.LENGTH_SHORT).show();
////                    }
////                });
////    }
////
////    private void showImagePickerDialog() {
////        String[] options = {"Take Photo", "Choose from Gallery"};
////        new AlertDialog.Builder(this)
////                .setTitle("Select Photo")
////                .setItems(options, (dialog, which) -> {
////                    if (which == 0) {
////                        dispatchTakePictureIntent();
////                    } else {
////                        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
////                        startActivityForResult(galleryIntent, PICK_IMAGE);
////                    }
////                })
////                .show();
////    }
////
////    private File createImageFile() throws IOException {
////        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
////        String imageFileName = "JPEG_" + timeStamp + "_";
////        File storageDir = getExternalFilesDir("HopeApp");
////        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
////        currentPhotoPath = image.getAbsolutePath();
////        return image;
////    }
////
////    private void dispatchTakePictureIntent() {
////        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
////        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
////            File photoFile = null;
////            try {
////                photoFile = createImageFile();
////            } catch (IOException ex) {
////                Toast.makeText(this, "Error creating file", Toast.LENGTH_SHORT).show();
////            }
////
////            if (photoFile != null) {
////                selectedImageUri = FileProvider.getUriForFile(this,
////                        "com.SIMATS.hope.fileprovider",
////                        photoFile);
////                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, selectedImageUri);
////                startActivityForResult(takePictureIntent, CAMERA_REQUEST);
////            }
////        }
////    }
////
////    @Override
////    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
////        super.onActivityResult(requestCode, resultCode, data);
////        if (resultCode == RESULT_OK) {
////            try {
////                if (requestCode == PICK_IMAGE && data != null) {
////                    selectedImageUri = data.getData();
////                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
////                } else if (requestCode == CAMERA_REQUEST) {
////                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
////                }
////                imagePreview.setImageBitmap(selectedBitmap);
////                imagePreview.setVisibility(ImageView.VISIBLE);
////            } catch (IOException e) {
////                e.printStackTrace();
////                Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show();
////            }
////        }
////    }
////
////    @Override
////    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
////        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
////        if (requestCode == PERMISSION_REQUEST_CODE) {
////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
////                showImagePickerDialog();
////            } else {
////                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
////            }
////        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
////            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
////                getCurrentLocation();
////            }
////        }
////    }
////
////    private void submitReport() {
////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////        int userId = prefs.getInt("user_id", 0);
////        if (userId == 0) {
////            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
////            return;
////        }
////
////        String type = spinnerType.getSelectedItem().toString();
////        String name = checkboxAnonymous.isChecked() ? "Anonymous" : editName.getText().toString().trim();
////        String age = editAge.getText().toString().trim();
////        String city = editCity.getText().toString().trim();
////        String exactLocation = editLocation.getText().toString().trim();
////        String details = editDetails.getText().toString().trim();
////
////        if (type.isEmpty() || city.isEmpty() || details.isEmpty()) {
////            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
////            return;
////        }
////
////        // Create request parts
////        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(userId));
////        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), type);
////        RequestBody nameBody = RequestBody.create(MediaType.parse("text/plain"), name);
////        RequestBody ageBody = RequestBody.create(MediaType.parse("text/plain"), age);
////        RequestBody generalLocationBody = RequestBody.create(MediaType.parse("text/plain"), city);
////        RequestBody exactLocationBody = RequestBody.create(MediaType.parse("text/plain"), exactLocation);
////        RequestBody detailsBody = RequestBody.create(MediaType.parse("text/plain"), details);
////        RequestBody isAnonymousBody = RequestBody.create(MediaType.parse("text/plain"), checkboxAnonymous.isChecked() ? "1" : "0");
////
////        MultipartBody.Part photoPart = null;
////        if (selectedBitmap != null) {
////            File file = bitmapToFile(selectedBitmap);
////            RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
////            photoPart = MultipartBody.Part.createFormData("photo", file.getName(), requestFile);
////        }
////
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<ResponseBody> call = apiService.submitReport(
////                userIdBody, typeBody, nameBody, ageBody, generalLocationBody,
////                exactLocationBody, detailsBody, isAnonymousBody, photoPart);
////
////        call.enqueue(new Callback<ResponseBody>() {
////            @Override
////            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
////                try {
////                    if (response.isSuccessful()) {
////                        String responseString = response.body().string();
////                        Log.d("API_SUCCESS", responseString);
////                        showSuccessDialog();
////                    } else {
////                        String error = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
////                        Log.e("API_ERROR", error);
////                        Toast.makeText(ReportChildActivity.this, "Upload failed: " + error, Toast.LENGTH_LONG).show();
////                    }
////                } catch (IOException e) {
////                    e.printStackTrace();
////                }
////            }
////
////            @Override
////            public void onFailure(Call<ResponseBody> call, Throwable t) {
////                Toast.makeText(ReportChildActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////                Log.e("NETWORK_ERROR", t.getMessage(), t);
////            }
////        });
////    }
////
////    private File bitmapToFile(Bitmap bitmap) {
////        File file = new File(getCacheDir(), "upload_" + System.currentTimeMillis() + ".jpg");
////        try (FileOutputStream out = new FileOutputStream(file)) {
////            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
////        } catch (IOException e) {
////            e.printStackTrace();
////        }
////        return file;
////    }
////
////    private void showSuccessDialog() {
////        new AlertDialog.Builder(this)
////                .setTitle("Success")
////                .setMessage("Report submitted successfully")
////                .setPositiveButton("OK", (dialog, which) -> finish())
////                .show();
////    }
////}
//package com.SIMATS.hope;
//
//import android.Manifest;
//import android.app.AlertDialog;
//import android.content.Context;
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.content.pm.PackageManager;
//import android.graphics.Bitmap;
//import android.location.Address;
//import android.location.Geocoder;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Bundle;
//import android.provider.MediaStore;
//import android.util.Log;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.CheckBox;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.Spinner;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//import androidx.core.content.FileProvider;
//
//import com.google.android.gms.location.FusedLocationProviderClient;
//import com.google.android.gms.location.LocationServices;
//
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.Locale;
//
//import okhttp3.MediaType;
//import okhttp3.MultipartBody;
//import okhttp3.RequestBody;
//import okhttp3.ResponseBody;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class ReportChildActivity extends AppCompatActivity {
//
//    private static final int PERMISSION_REQUEST_CODE = 100;
//    private static final int PICK_IMAGE = 101;
//    private static final int CAMERA_REQUEST = 102;
//    private static final int LOCATION_PERMISSION_REQUEST_CODE = 200;
//
//    private Spinner spinnerType, spinnerOrphanages, spinnerCitiesFallback;
//    private EditText editName, editAge, editCity, editLocation, editDetails;
//    private CheckBox checkboxAnonymous;
//    private Button btnUploadPhoto, btnSubmitReport, mapPlaceholder;
//    private ImageView imagePreview, ivBack;
//    private TextView tvOrphanageTitle, tvSelectCityFallback;
//
//    private Uri selectedImageUri;
//    private Bitmap selectedBitmap;
//    private FusedLocationProviderClient fusedLocationClient;
//    private String currentPhotoPath;
//    private List<Orphanage> orphanageList = new ArrayList<>(); // Global list
//    private List<String> citiesWithOrphanages = new ArrayList<>();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_report_child);
//
//        // Initialize Views
//        spinnerType = findViewById(R.id.spinnerType);
//        spinnerOrphanages = findViewById(R.id.spinnerOrphanages);
//        spinnerCitiesFallback = findViewById(R.id.spinnerCitiesFallback);
//        tvOrphanageTitle = findViewById(R.id.tvOrphanageTitle);
//        tvSelectCityFallback = findViewById(R.id.tvSelectCityFallback);
//        editName = findViewById(R.id.editName);
//        editAge = findViewById(R.id.editAge);
//        editCity = findViewById(R.id.editCity);
//        editLocation = findViewById(R.id.getlocation);
//        editDetails = findViewById(R.id.editDetails);
//        checkboxAnonymous = findViewById(R.id.checkboxAnonymous);
//        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
//        btnSubmitReport = findViewById(R.id.btnSubmitReport);
//        mapPlaceholder = findViewById(R.id.mapPlaceholder);
//        imagePreview = findViewById(R.id.imagePreview);
//        ivBack = findViewById(R.id.ivBack);
//
//        // Initialize location client - ADD THIS LINE
//        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
//
//        // Initialize orphanage spinner with empty data initially
//        setupOrphanageSpinner(new ArrayList<>());
//
//        // ... rest of your onCreate code ...
//
//
//        // Setup person type spinner
//        String[] personTypes = {"Child", "Orphan", "Homeless", "Injured", "Other"};
//        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, personTypes);
//        spinnerType.setAdapter(typeAdapter);
//
//        // Fetch all cities with orphanages
//        fetchCitiesWithOrphanages();
//
//        // Click listeners
//        btnUploadPhoto.setOnClickListener(v -> checkAndRequestPermissions());
//        mapPlaceholder.setOnClickListener(v -> requestLocationPermission());
//        btnSubmitReport.setOnClickListener(v -> submitReport());
//        ivBack.setOnClickListener(v -> finish());
//
//        // City field listener - fetch orphanages when user leaves the field
//        editCity.setOnFocusChangeListener((v, hasFocus) -> {
//            if (!hasFocus) {
//                String city = editCity.getText().toString().trim();
//                if (!city.isEmpty()) {
//                    fetchOrphanages(city);
//                }
//            }
//        });
//
//        // Fallback city spinner listener
//        spinnerCitiesFallback.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedCity = parent.getItemAtPosition(position).toString();
//                if (!selectedCity.equals("Select a city")) {
//                    editCity.setText(selectedCity);
//                    // Fetch orphanages for the selected city
//                    fetchOrphanages(selectedCity);
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//                // Do nothing
//            }
//        });
//    }
//
//    private void showOrphanageSection() {
//        tvOrphanageTitle.setVisibility(View.VISIBLE);
//
//        // Check if we have cities data
//        if (citiesWithOrphanages != null && !citiesWithOrphanages.isEmpty()) {
//            // Show the city input field and hide the fallback spinner
//            editCity.setVisibility(View.VISIBLE);
//            tvSelectCityFallback.setVisibility(View.GONE);
//            spinnerCitiesFallback.setVisibility(View.GONE);
//        } else {
//            // Show fallback city selection spinner
//            editCity.setVisibility(View.GONE);
//            tvSelectCityFallback.setVisibility(View.VISIBLE);
//            spinnerCitiesFallback.setVisibility(View.VISIBLE);
//        }
//    }
//
//    private void hideOrphanageSection() {
//        tvOrphanageTitle.setVisibility(View.GONE);
//        spinnerOrphanages.setVisibility(View.GONE);
//        tvSelectCityFallback.setVisibility(View.GONE);
//        spinnerCitiesFallback.setVisibility(View.GONE);
//        editCity.setVisibility(View.VISIBLE);
//    }
//
//    private void fetchCitiesWithOrphanages() {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<CityResponse> call = apiService.getAllCities();
//
//        call.enqueue(new Callback<CityResponse>() {
//            @Override
//            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
//                Log.d("API_DEBUG", "Response code: " + response.code());
//                Log.d("API_DEBUG", "Response message: " + response.message());
//
//                if (response.isSuccessful() && response.body() != null) {
//                    CityResponse cityResponse = response.body();
//                    Log.d("API_DEBUG", "Status: " + cityResponse.getStatus());
//                    Log.d("API_DEBUG", "Message: " + cityResponse.getMessage());
//
//                    citiesWithOrphanages = cityResponse.getCities();
//
//                    if (citiesWithOrphanages != null) {
//                        Log.d("API_DEBUG", "Cities count: " + citiesWithOrphanages.size());
//                    }
//
//                    // ALWAYS setup fallback spinner for city selection
//                    if (citiesWithOrphanages != null && !citiesWithOrphanages.isEmpty()) {
//                        List<String> spinnerItems = new ArrayList<>();
//                        spinnerItems.add("Select a city");
//                        spinnerItems.addAll(citiesWithOrphanages);
//
//                        ArrayAdapter<String> adapter = new ArrayAdapter<>(ReportChildActivity.this,
//                                android.R.layout.simple_spinner_dropdown_item, spinnerItems);
//                        spinnerCitiesFallback.setAdapter(adapter);
//
//                        // ALWAYS show the city selection spinner
//                        tvSelectCityFallback.setVisibility(View.VISIBLE);
//                        spinnerCitiesFallback.setVisibility(View.VISIBLE);
//                    } else {
//                        Toast.makeText(ReportChildActivity.this, "No cities available", Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    try {
//                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "No error body";
//                        Log.e("API_DEBUG", "Error response: " + errorBody);
//                        Toast.makeText(ReportChildActivity.this, "Failed to fetch cities: " + response.message(), Toast.LENGTH_SHORT).show();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                        Toast.makeText(ReportChildActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<CityResponse> call, Throwable t) {
//                Log.e("API_DEBUG", "Network error: " + t.getMessage());
//                Toast.makeText(ReportChildActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//    private void setupOrphanageSpinner(List<Orphanage> orphanages) {
//        orphanageList = orphanages;
//
//        OrphanageAdapter adapter = new OrphanageAdapter(this, orphanages);
//        spinnerOrphanages.setAdapter(adapter);
//    }
//
//
//
//    // Check image & camera permissions
//    private void checkAndRequestPermissions() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
//            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED ||
//                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.CAMERA},
//                        PERMISSION_REQUEST_CODE);
//            } else {
//                showImagePickerDialog();
//            }
//        } else {
//            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
//                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
//                        PERMISSION_REQUEST_CODE);
//            } else {
//                showImagePickerDialog();
//            }
//        }
//    }
//
//    private void requestLocationPermission() {
//        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this,
//                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//                    LOCATION_PERMISSION_REQUEST_CODE);
//        } else {
//            // Check if location services are enabled
//            if (isLocationEnabled()) {
//                getCurrentLocation();
//            } else {
//                Toast.makeText(this, "Please enable location services", Toast.LENGTH_SHORT).show();
//                // You can prompt user to enable location services
//                showLocationSettingsDialog();
//            }
//        }
//    }
//    private void getCityNameFromLocation(double latitude, double longitude) {
//        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//        try {
//            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
//            if (addresses != null && !addresses.isEmpty()) {
//                Address address = addresses.get(0);
//                String cityName = address.getLocality();
//                if (cityName != null && !cityName.isEmpty()) {
//                    // Auto-fill the city field if it's empty
//                    if (editCity.getText().toString().trim().isEmpty()) {
//                        editCity.setText(cityName);
//                        // Also fetch orphanages for this city
//                        fetchOrphanages(cityName);
//                    }
//                }
//            }
//        } catch (IOException e) {
//            Log.e("GeocoderError", "Failed to get city name from location", e);
//        }
//    }
//    private boolean isLocationEnabled() {
//        android.location.LocationManager locationManager = (android.location.LocationManager) getSystemService(Context.LOCATION_SERVICE);
//        return locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ||
//                locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
//    }
//
//    private void showLocationSettingsDialog() {
//        new AlertDialog.Builder(this)
//                .setTitle("Location Services Disabled")
//                .setMessage("Please enable location services to get your current location")
//                .setPositiveButton("Settings", (dialog, which) -> {
//                    Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
//                    startActivity(intent);
//                })
//                .setNegativeButton("Cancel", null)
//                .show();
//    }
//    private void getCurrentLocation() {
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Show loading message
//        Toast.makeText(this, "Getting your location...", Toast.LENGTH_SHORT).show();
//
//        fusedLocationClient.getLastLocation()
//                .addOnSuccessListener(this, location -> {
//                    if (location != null) {
//                        double latitude = location.getLatitude();
//                        double longitude = location.getLongitude();
//                        // Only update the location field, not the city field
//                        editLocation.setText(latitude + ", " + longitude);
//                        Toast.makeText(this, "Location coordinates captured", Toast.LENGTH_SHORT).show();
//
//                        // Optional: Also try to get city name from coordinates
//                        getCityNameFromLocation(latitude, longitude);
//                    } else {
//                        Toast.makeText(this, "Unable to get location. Please ensure location is enabled and try again.", Toast.LENGTH_LONG).show();
//                    }
//                })
//                .addOnFailureListener(this, e -> {
//                    Toast.makeText(this, "Failed to get location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
//                    Log.e("LocationError", "Failed to get location", e);
//                });
//    }
//
//    private void showImagePickerDialog() {
//        String[] options = {"Take Photo", "Choose from Gallery"};
//        new AlertDialog.Builder(this)
//                .setTitle("Select Photo")
//                .setItems(options, (dialog, which) -> {
//                    if (which == 0) dispatchTakePictureIntent();
//                    else {
//                        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
//                        startActivityForResult(galleryIntent, PICK_IMAGE);
//                    }
//                }).show();
//    }
//
//    private File createImageFile() throws IOException {
//        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
//        String imageFileName = "JPEG_" + timeStamp + "_";
//        File storageDir = getExternalFilesDir("HopeApp");
//        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
//        currentPhotoPath = image.getAbsolutePath();
//        return image;
//    }
//
//    private void dispatchTakePictureIntent() {
//        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
//            File photoFile = null;
//            try {
//                photoFile = createImageFile();
//            } catch (IOException ex) {
//                Toast.makeText(this, "Error creating file", Toast.LENGTH_SHORT).show();
//                return;
//            }
//
//            if (photoFile != null) {
//                selectedImageUri = FileProvider.getUriForFile(this,
//                        "com.SIMATS.hope.fileprovider",
//                        photoFile);
//                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, selectedImageUri);
//                startActivityForResult(takePictureIntent, CAMERA_REQUEST);
//            }
//        }
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == RESULT_OK) {
//            try {
//                if (requestCode == PICK_IMAGE && data != null) {
//                    selectedImageUri = data.getData();
//                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
//                } else if (requestCode == CAMERA_REQUEST) {
//                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
//                }
//                imagePreview.setImageBitmap(selectedBitmap);
//                imagePreview.setVisibility(View.VISIBLE);
//            } catch (IOException e) {
//                e.printStackTrace();
//                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == PERMISSION_REQUEST_CODE) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                showImagePickerDialog();
//            } else {
//                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
//            }
//        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                getCurrentLocation();
//            } else {
//                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
//
//    private void fetchOrphanages(String city) {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<OrphanageResponse> call = apiService.getOrphanages(city);
//
//        call.enqueue(new Callback<OrphanageResponse>() {
//            @Override
//            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    OrphanageResponse orphanageResponse = response.body();
//                    if ("success".equals(orphanageResponse.getStatus())) {
//                        List<Orphanage> orphanages = orphanageResponse.getOrphanages();
//
//                        if (orphanages != null && !orphanages.isEmpty()) {
//                            // Show orphanages with address
//                            setupOrphanageSpinner(orphanages);
//                            spinnerOrphanages.setVisibility(View.VISIBLE);
//
//                            Toast.makeText(ReportChildActivity.this,
//                                    "Found " + orphanages.size() + " orphanages in " + city,
//                                    Toast.LENGTH_SHORT).show();
//                        } else {
//                            // No orphanages in this city
//                            setupOrphanageSpinner(new ArrayList<>());
//                            spinnerOrphanages.setVisibility(View.VISIBLE);
//
//                            // Add a message item to the spinner
//                            List<Orphanage> emptyList = new ArrayList<>();
//                            Orphanage messageOrphanage = new Orphanage();
//                            // You might need to add setters to your Orphanage class
//                            // messageOrphanage.setName("No orphanages in " + city);
//                            // emptyList.add(messageOrphanage);
//                            // setupOrphanageSpinner(emptyList);
//
//                            // Or simpler approach:
//                            List<String> message = new ArrayList<>();
//                            message.add("No orphanages found in " + city);
//                            ArrayAdapter<String> adapter = new ArrayAdapter<>(ReportChildActivity.this,
//                                    android.R.layout.simple_spinner_dropdown_item, message);
//                            spinnerOrphanages.setAdapter(adapter);
//                        }
//                    } else {
//                        Toast.makeText(ReportChildActivity.this, "Error: " + orphanageResponse.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Toast.makeText(ReportChildActivity.this, "Server error: " + response.message(), Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
//                Toast.makeText(ReportChildActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//    private void submitReport() {
//        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//        int userId = prefs.getInt("user_id", 0);
//        if (userId == 0) {
//            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        String type = spinnerType.getSelectedItem().toString();
//        String name = checkboxAnonymous.isChecked() ? "Anonymous" : editName.getText().toString().trim();
//        String age = editAge.getText().toString().trim();
//        String city = editCity.getText().toString().trim();
//        String exactLocation = editLocation.getText().toString().trim();
//        String details = editDetails.getText().toString().trim();
//
//        if (type.isEmpty() || age.isEmpty() || city.isEmpty() || exactLocation.isEmpty() || details.isEmpty()) {
//            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
//            return;
//        }
//
//        // Selected orphanage - for ALL types (optional)
//        String orphanageId = "0"; // Default to 0 if no orphanage selected
//
//        if (spinnerOrphanages.getSelectedItem() != null &&
//                spinnerOrphanages.getSelectedItemPosition() > 0 && // Skip the first "Select an orphanage" option
//                orphanageList != null && !orphanageList.isEmpty()) {
//
//            Orphanage selectedOrphanage = orphanageList.get(spinnerOrphanages.getSelectedItemPosition() - 1);
//            orphanageId = String.valueOf(selectedOrphanage.getId());
//
//            Toast.makeText(this, "Selected: " + selectedOrphanage.getName(), Toast.LENGTH_SHORT).show();
//
//        }
//
//        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), type);
//        RequestBody nameBody = RequestBody.create(MediaType.parse("text/plain"), name);
//        RequestBody ageBody = RequestBody.create(MediaType.parse("text/plain"), age);
//        RequestBody cityBody = RequestBody.create(MediaType.parse("text/plain"), city);
//        RequestBody locationBody = RequestBody.create(MediaType.parse("text/plain"), exactLocation);
//        RequestBody detailsBody = RequestBody.create(MediaType.parse("text/plain"), details);
//        RequestBody orphanageIdBody = RequestBody.create(MediaType.parse("text/plain"), orphanageId);
//        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(userId));
//        RequestBody isAnonymousBody = RequestBody.create(MediaType.parse("text/plain"),
//                checkboxAnonymous.isChecked() ? "1" : "0");
//
//        MultipartBody.Part photoPart = null;
//        if (selectedBitmap != null) {
//            try {
//                File file = new File(getCacheDir(), "report_image.jpg");
//                FileOutputStream fos = new FileOutputStream(file);
//                selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 80, fos);
//                fos.flush();
//                fos.close();
//                RequestBody photoBody = RequestBody.create(MediaType.parse("image/*"), file);
//                photoPart = MultipartBody.Part.createFormData("photo", file.getName(), photoBody);
//            } catch (IOException e) {
//                e.printStackTrace();
//                Toast.makeText(this, "Failed to process image", Toast.LENGTH_SHORT).show();
//            }
//        }
//
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<ResponseBody> call = apiService.submitReport(
//                userIdBody, typeBody, nameBody, ageBody,
//                cityBody, locationBody, detailsBody,
//                isAnonymousBody, orphanageIdBody, photoPart
//        );
//
//        call.enqueue(new Callback<ResponseBody>() {
//            @Override
//            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                if (response.isSuccessful()) {
//                    Toast.makeText(ReportChildActivity.this, "Report submitted successfully", Toast.LENGTH_SHORT).show();
//                    finish();
//                } else {
//                    try {
//                        String error = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
//                        Toast.makeText(ReportChildActivity.this, "Failed to submit report: " + error, Toast.LENGTH_SHORT).show();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                        Toast.makeText(ReportChildActivity.this, "Failed to submit report", Toast.LENGTH_SHORT).show();
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ResponseBody> call, Throwable t) {
//                Toast.makeText(ReportChildActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//}
package com.SIMATS.hope;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReportChildActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int PICK_IMAGE = 101;
    private static final int CAMERA_REQUEST = 102;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 200;

    private Spinner spinnerType, spinnerOrphanages, spinnerCitiesFallback;
    private EditText editName, editAge, editCity, editLocation, editDetails;
    private CheckBox checkboxAnonymous;
    private Button btnUploadPhoto, btnSubmitReport, mapPlaceholder;
    private ImageView imagePreview, ivBack;
    private TextView tvOrphanageTitle, tvSelectCityFallback;
    private BottomNavigationView bottomNavigationView;

    private Uri selectedImageUri;
    private Bitmap selectedBitmap;
    private FusedLocationProviderClient fusedLocationClient;
    private String currentPhotoPath;
    private List<Orphanage> orphanageList = new ArrayList<>();
    private List<String> citiesWithOrphanages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_child);

        // Initialize Views
        spinnerType = findViewById(R.id.spinnerType);
        spinnerOrphanages = findViewById(R.id.spinnerOrphanages);
        spinnerCitiesFallback = findViewById(R.id.spinnerCitiesFallback);
        tvOrphanageTitle = findViewById(R.id.tvOrphanageTitle);
        tvSelectCityFallback = findViewById(R.id.tvSelectCityFallback);
        editName = findViewById(R.id.editName);
        editAge = findViewById(R.id.editAge);
        editCity = findViewById(R.id.editCity);
        editLocation = findViewById(R.id.getlocation);
        editDetails = findViewById(R.id.editDetails);
        checkboxAnonymous = findViewById(R.id.checkboxAnonymous);
        btnUploadPhoto = findViewById(R.id.btnUploadPhoto);
        btnSubmitReport = findViewById(R.id.btnSubmitReport);
        mapPlaceholder = findViewById(R.id.mapPlaceholder);
        imagePreview = findViewById(R.id.imagePreview);
        ivBack = findViewById(R.id.ivBack);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Initialize location client
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Setup bottom navigation
        setupBottomNavigation();

        // Initialize orphanage spinner with empty data initially
        setupOrphanageSpinner(new ArrayList<>());

        // Setup person type spinner
        String[] personTypes = {"Child", "Orphan", "Homeless", "Injured", "Other"};
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, personTypes);
        spinnerType.setAdapter(typeAdapter);

        // Fetch all cities with orphanages
        fetchCitiesWithOrphanages();

        // Click listeners
        btnUploadPhoto.setOnClickListener(v -> checkAndRequestPermissions());
        mapPlaceholder.setOnClickListener(v -> requestLocationPermission());
        btnSubmitReport.setOnClickListener(v -> submitReport());
        ivBack.setOnClickListener(v -> finish());

        // City field listener - fetch orphanages when user leaves the field
        editCity.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                String city = editCity.getText().toString().trim();
                if (!city.isEmpty()) {
                    fetchOrphanages(city);
                }
            }
        });

        // Fallback city spinner listener
        spinnerCitiesFallback.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = parent.getItemAtPosition(position).toString();
                if (!selectedCity.equals("Select a city")) {
                    editCity.setText(selectedCity);
                    // Fetch orphanages for the selected city
                    fetchOrphanages(selectedCity);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(ReportChildActivity.this, DashboardActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_donate) {
                    startActivity(new Intent(ReportChildActivity.this, DonateActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_report) {
                    // Already on report page
                    return true;
                } else if (itemId == R.id.nav_volunteer) {
                    startActivity(new Intent(ReportChildActivity.this, VolunteerRequestActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    startActivity(new Intent(ReportChildActivity.this, SettingsActivity.class));
                    finish();
                    return true;
                }
                return false;
            }
        });

        // Set report as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_report);
    }

    private void showOrphanageSection() {
        tvOrphanageTitle.setVisibility(View.VISIBLE);

        // Check if we have cities data
        if (citiesWithOrphanages != null && !citiesWithOrphanages.isEmpty()) {
            // Show the city input field and hide the fallback spinner
            editCity.setVisibility(View.VISIBLE);
            tvSelectCityFallback.setVisibility(View.GONE);
            spinnerCitiesFallback.setVisibility(View.GONE);
        } else {
            // Show fallback city selection spinner
            editCity.setVisibility(View.GONE);
            tvSelectCityFallback.setVisibility(View.VISIBLE);
            spinnerCitiesFallback.setVisibility(View.VISIBLE);
        }
    }

    private void hideOrphanageSection() {
        tvOrphanageTitle.setVisibility(View.GONE);
        spinnerOrphanages.setVisibility(View.GONE);
        tvSelectCityFallback.setVisibility(View.GONE);
        spinnerCitiesFallback.setVisibility(View.GONE);
        editCity.setVisibility(View.VISIBLE);
    }

    private void fetchCitiesWithOrphanages() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<CityResponse> call = apiService.getAllCities();

        call.enqueue(new Callback<CityResponse>() {
            @Override
            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                Log.d("API_DEBUG", "Response code: " + response.code());
                Log.d("API_DEBUG", "Response message: " + response.message());

                if (response.isSuccessful() && response.body() != null) {
                    CityResponse cityResponse = response.body();
                    Log.d("API_DEBUG", "Status: " + cityResponse.getStatus());
                    Log.d("API_DEBUG", "Message: " + cityResponse.getMessage());

                    citiesWithOrphanages = cityResponse.getCities();

                    if (citiesWithOrphanages != null) {
                        Log.d("API_DEBUG", "Cities count: " + citiesWithOrphanages.size());
                    }

                    // ALWAYS setup fallback spinner for city selection
                    if (citiesWithOrphanages != null && !citiesWithOrphanages.isEmpty()) {
                        List<String> spinnerItems = new ArrayList<>();
                        spinnerItems.add("Select a city");
                        spinnerItems.addAll(citiesWithOrphanages);

                        ArrayAdapter<String> adapter = new ArrayAdapter<>(ReportChildActivity.this,
                                android.R.layout.simple_spinner_dropdown_item, spinnerItems);
                        spinnerCitiesFallback.setAdapter(adapter);

                        // ALWAYS show the city selection spinner
                        tvSelectCityFallback.setVisibility(View.VISIBLE);
                        spinnerCitiesFallback.setVisibility(View.VISIBLE);
                    } else {
                        Toast.makeText(ReportChildActivity.this, "No cities available", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    try {
                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "No error body";
                        Log.e("API_DEBUG", "Error response: " + errorBody);
                        Toast.makeText(ReportChildActivity.this, "Failed to fetch cities: " + response.message(), Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(ReportChildActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<CityResponse> call, Throwable t) {
                Log.e("API_DEBUG", "Network error: " + t.getMessage());
                Toast.makeText(ReportChildActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupOrphanageSpinner(List<Orphanage> orphanages) {
        orphanageList = orphanages;

        OrphanageAdapter adapter = new OrphanageAdapter(this, orphanages);
        spinnerOrphanages.setAdapter(adapter);
    }

    // Check image & camera permissions
    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.CAMERA},
                        PERMISSION_REQUEST_CODE);
            } else {
                showImagePickerDialog();
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
                        PERMISSION_REQUEST_CODE);
            } else {
                showImagePickerDialog();
            }
        }
    }

    private void requestLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            // Check if location services are enabled
            if (isLocationEnabled()) {
                getCurrentLocation();
            } else {
                Toast.makeText(this, "Please enable location services", Toast.LENGTH_SHORT).show();
                // You can prompt user to enable location services
                showLocationSettingsDialog();
            }
        }
    }

    private void getCityNameFromLocation(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                String cityName = address.getLocality();
                if (cityName != null && !cityName.isEmpty()) {
                    // Auto-fill the city field if it's empty
                    if (editCity.getText().toString().trim().isEmpty()) {
                        editCity.setText(cityName);
                        // Also fetch orphanages for this city
                        fetchOrphanages(cityName);
                    }
                }
            }
        } catch (IOException e) {
            Log.e("GeocoderError", "Failed to get city name from location", e);
        }
    }

    private boolean isLocationEnabled() {
        android.location.LocationManager locationManager = (android.location.LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
    }

    private void showLocationSettingsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Location Services Disabled")
                .setMessage("Please enable location services to get your current location")
                .setPositiveButton("Settings", (dialog, which) -> {
                    Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show loading message
        Toast.makeText(this, "Getting your location...", Toast.LENGTH_SHORT).show();

        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        double latitude = location.getLatitude();
                        double longitude = location.getLongitude();
                        // Only update the location field, not the city field
                        editLocation.setText(latitude + ", " + longitude);
                        Toast.makeText(this, "Location coordinates captured", Toast.LENGTH_SHORT).show();

                        // Optional: Also try to get city name from coordinates
                        getCityNameFromLocation(latitude, longitude);
                    } else {
                        Toast.makeText(this, "Unable to get location. Please ensure location is enabled and try again.", Toast.LENGTH_LONG).show();
                    }
                })
                .addOnFailureListener(this, e -> {
                    Toast.makeText(this, "Failed to get location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.e("LocationError", "Failed to get location", e);
                });
    }

    private void showImagePickerDialog() {
        String[] options = {"Take Photo", "Choose from Gallery"};
        new AlertDialog.Builder(this)
                .setTitle("Select Photo")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) dispatchTakePictureIntent();
                    else {
                        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(galleryIntent, PICK_IMAGE);
                    }
                }).show();
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir("HopeApp");
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                Toast.makeText(this, "Error creating file", Toast.LENGTH_SHORT).show();
                return;
            }

            if (photoFile != null) {
                selectedImageUri = FileProvider.getUriForFile(this,
                        "com.SIMATS.hope.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, selectedImageUri);
                startActivityForResult(takePictureIntent, CAMERA_REQUEST);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            try {
                if (requestCode == PICK_IMAGE && data != null) {
                    selectedImageUri = data.getData();
                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                } else if (requestCode == CAMERA_REQUEST) {
                    selectedBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                }
                imagePreview.setImageBitmap(selectedBitmap);
                imagePreview.setVisibility(View.VISIBLE);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showImagePickerDialog();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void fetchOrphanages(String city) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<OrphanageResponse> call = apiService.getOrphanages(city);

        call.enqueue(new Callback<OrphanageResponse>() {
            @Override
            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    OrphanageResponse orphanageResponse = response.body();
                    if ("success".equals(orphanageResponse.getStatus())) {
                        List<Orphanage> orphanages = orphanageResponse.getOrphanages();

                        if (orphanages != null && !orphanages.isEmpty()) {
                            // Show orphanages with address
                            setupOrphanageSpinner(orphanages);
                            spinnerOrphanages.setVisibility(View.VISIBLE);

                            Toast.makeText(ReportChildActivity.this,
                                    "Found " + orphanages.size() + " orphanages in " + city,
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            // No orphanages in this city
                            setupOrphanageSpinner(new ArrayList<>());
                            spinnerOrphanages.setVisibility(View.VISIBLE);

                            // Add a message item to the spinner
                            List<Orphanage> emptyList = new ArrayList<>();
                            Orphanage messageOrphanage = new Orphanage();
                            // You might need to add setters to your Orphanage class
                            // messageOrphanage.setName("No orphanages in " + city);
                            // emptyList.add(messageOrphanage);
                            // setupOrphanageSpinner(emptyList);

                            // Or simpler approach:
                            List<String> message = new ArrayList<>();
                            message.add("No orphanages found in " + city);
                            ArrayAdapter<String> adapter = new ArrayAdapter<>(ReportChildActivity.this,
                                    android.R.layout.simple_spinner_dropdown_item, message);
                            spinnerOrphanages.setAdapter(adapter);
                        }
                    } else {
                        Toast.makeText(ReportChildActivity.this, "Error: " + orphanageResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ReportChildActivity.this, "Server error: " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
                Toast.makeText(ReportChildActivity.this, "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void submitReport() {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int userId = prefs.getInt("user_id", 0);
        if (userId == 0) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }

        String type = spinnerType.getSelectedItem().toString();
        String name = checkboxAnonymous.isChecked() ? "Anonymous" : editName.getText().toString().trim();
        String age = editAge.getText().toString().trim();
        String city = editCity.getText().toString().trim();
        String exactLocation = editLocation.getText().toString().trim();
        String details = editDetails.getText().toString().trim();

        if (type.isEmpty() || age.isEmpty() || city.isEmpty() || exactLocation.isEmpty() || details.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Selected orphanage - for ALL types (optional)
        String orphanageId = "0"; // Default to 0 if no orphanage selected

        if (spinnerOrphanages.getSelectedItem() != null &&
                spinnerOrphanages.getSelectedItemPosition() > 0 && // Skip the first "Select an orphanage" option
                orphanageList != null && !orphanageList.isEmpty()) {

            Orphanage selectedOrphanage = orphanageList.get(spinnerOrphanages.getSelectedItemPosition() - 1);
            orphanageId = String.valueOf(selectedOrphanage.getId());

            Toast.makeText(this, "Selected: " + selectedOrphanage.getName(), Toast.LENGTH_SHORT).show();

        }

        RequestBody typeBody = RequestBody.create(MediaType.parse("text/plain"), type);
        RequestBody nameBody = RequestBody.create(MediaType.parse("text/plain"), name);
        RequestBody ageBody = RequestBody.create(MediaType.parse("text/plain"), age);
        RequestBody cityBody = RequestBody.create(MediaType.parse("text/plain"), city);
        RequestBody locationBody = RequestBody.create(MediaType.parse("text/plain"), exactLocation);
        RequestBody detailsBody = RequestBody.create(MediaType.parse("text/plain"), details);
        RequestBody orphanageIdBody = RequestBody.create(MediaType.parse("text/plain"), orphanageId);
        RequestBody userIdBody = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(userId));
        RequestBody isAnonymousBody = RequestBody.create(MediaType.parse("text/plain"),
                checkboxAnonymous.isChecked() ? "1" : "0");

        MultipartBody.Part photoPart = null;
        if (selectedBitmap != null) {
            try {
                File file = new File(getCacheDir(), "report_image.jpg");
                FileOutputStream fos = new FileOutputStream(file);
                selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 80, fos);
                fos.flush();
                fos.close();
                RequestBody photoBody = RequestBody.create(MediaType.parse("image/*"), file);
                photoPart = MultipartBody.Part.createFormData("photo", file.getName(), photoBody);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to process image", Toast.LENGTH_SHORT).show();
            }
        }

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ResponseBody> call = apiService.submitReport(
                userIdBody, typeBody, nameBody, ageBody,
                cityBody, locationBody, detailsBody,
                isAnonymousBody, orphanageIdBody, photoPart
        );

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(ReportChildActivity.this, "Report submitted successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    try {
                        String error = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
                        Toast.makeText(ReportChildActivity.this, "Failed to submit report: " + error, Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText(ReportChildActivity.this, "Failed to submit report", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(ReportChildActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Set report as selected when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_report);
        }
    }
}