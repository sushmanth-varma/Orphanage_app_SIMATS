package com.SIMATS.hope;
// Volunteer_admin.java
public class Volunteer_admin {
    private String id;
    private String full_name;
    private String email;
    private String phone;
    private String reason;
    private String approval_status;

    public Volunteer_admin(String id, String full_name, String email, String phone, String reason, String approval_status) {
        this.id = id;
        this.full_name = full_name;
        this.email = email;
        this.phone = phone;
        this.reason = reason;
        this.approval_status = approval_status;
    }

    public String getFull_name() { return full_name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getReason() { return reason; }
    public String getApproval_status() { return approval_status; }
}
