package com.SIMATS.hope;

public class ApiResponse_update_donationstatus {
    private String status;
    private String message;
    private int updated_id;

    // Getters
    public String getStatus() { return status; }
    public String getMessage() { return message; }
    public int getUpdatedId() { return updated_id; }
}