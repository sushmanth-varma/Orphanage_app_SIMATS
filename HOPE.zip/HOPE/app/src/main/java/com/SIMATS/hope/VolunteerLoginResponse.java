package com.SIMATS.hope;

public class VolunteerLoginResponse {
    private String status;
    private String message;
    private User user;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public User getUser() {
        return user;
    }

    public static class User {
        private int id;
        private String full_name;
        private String phone;

        public int getId() {
            return id;
        }

        public String getFull_name() {
            return full_name;
        }

        public String getPhone() {
            return phone;
        }
    }
}