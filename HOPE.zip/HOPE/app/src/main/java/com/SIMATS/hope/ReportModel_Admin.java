package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class ReportModel_Admin {
    @SerializedName("id")
    private String id;

    @SerializedName("type")
    private String type;

    @SerializedName("name")
    private String name;

    @SerializedName("age")
    private String age;

    @SerializedName("general_location")
    private String generalLocation;

    @SerializedName("exact_location")
    private String exactLocation;

    @SerializedName("photo_path")
    private String photoPath;

    @SerializedName("details")
    private String details;

    @SerializedName("is_anonymous")
    private String isAnonymous;

    @SerializedName("status")
    private String status;

    @SerializedName("volunteer_id")
    private String volunteerId;

    @SerializedName("volunteer_name")
    private String volunteerName;

    @SerializedName("volunteer_phone")
    private String volunteerPhone;

    // Getters
    public String getId() { return id; }
    public String getType() { return type; }
    public String getName() { return name; }
    public String getAge() { return age; }
    public String getGeneralLocation() { return generalLocation; }
    public String getExactLocation() { return exactLocation; }
    public String getPhotoPath() { return photoPath; }
    public String getDetails() { return details; }
    public String getIsAnonymous() { return isAnonymous; }
    public String getStatus() { return status; }
    public String getVolunteerId() { return volunteerId; }
    public String getVolunteerName() { return volunteerName; }
    public String getVolunteerPhone() { return volunteerPhone; }
}