package com.SIMATS.hope;

import java.util.List;

public class MaterialDonationRequest {
    private String donation_type;
    private String cause;
    private String item_description;
    private int quantity;
    private String full_name;
    private String phone;
    private String orphanage_name;
    private String location;
    private int user_id;
    private Integer orphanage_id;
    private List<DonationItem> items;

    // Constructor for single item (backward compatibility)
    public MaterialDonationRequest(String cause, String item_description, int quantity,
                                   String full_name, String phone, String orphanage_name,
                                   String location, int user_id, Integer orphanage_id) {
        this.donation_type = "Material";
        this.cause = cause;
        this.item_description = item_description;
        this.quantity = quantity;
        this.full_name = full_name;
        this.phone = phone;
        this.orphanage_name = orphanage_name;
        this.location = location;
        this.user_id = user_id;
        this.orphanage_id = orphanage_id;
        this.items = null; // No items list for single item
    }

    // Constructor for multiple items
    public MaterialDonationRequest(String cause, List<DonationItem> items,
                                   String full_name, String phone, String orphanage_name,
                                   String location, int user_id, Integer orphanage_id) {
        this.donation_type = "Material";
        this.cause = cause;
        this.items = items;
        this.full_name = full_name;
        this.phone = phone;
        this.orphanage_name = orphanage_name;
        this.location = location;
        this.user_id = user_id;
        this.orphanage_id = orphanage_id;

        // Calculate total quantity from all items
        this.quantity = 0;
        if (items != null) {
            for (DonationItem item : items) {
                this.quantity += item.getQuantity();
            }
        }

        // Create item description from all items
        this.item_description = generateItemDescription(items);
    }

    private String generateItemDescription(List<DonationItem> items) {
        if (items == null || items.isEmpty()) {
            return "";
        }

        StringBuilder description = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            DonationItem item = items.get(i);
            description.append(item.toString());
            if (i < items.size() - 1) {
                description.append("; ");
            }
        }
        return description.toString();
    }

    // Getters
    public String getDonation_type() { return donation_type; }
    public String getCause() { return cause; }
    public String getItem_description() { return item_description; }
    public int getQuantity() { return quantity; }
    public String getFull_name() { return full_name; }
    public String getPhone() { return phone; }
    public String getOrphanage_name() { return orphanage_name; }
    public String getLocation() { return location; }
    public int getUser_id() { return user_id; }
    public Integer getOrphanage_id() { return orphanage_id; }
    public List<DonationItem> getItems() { return items; }

    // Setters
    public void setDonation_type(String donation_type) { this.donation_type = donation_type; }
    public void setCause(String cause) { this.cause = cause; }
    public void setItem_description(String item_description) { this.item_description = item_description; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setFull_name(String full_name) { this.full_name = full_name; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setOrphanage_name(String orphanage_name) { this.orphanage_name = orphanage_name; }
    public void setLocation(String location) { this.location = location; }
    public void setUser_id(int user_id) { this.user_id = user_id; }
    public void setOrphanage_id(Integer orphanage_id) { this.orphanage_id = orphanage_id; }
    public void setItems(List<DonationItem> items) {
        this.items = items;
        // Update quantity and description when items change
        if (items != null) {
            this.quantity = 0;
            for (DonationItem item : items) {
                this.quantity += item.getQuantity();
            }
            this.item_description = generateItemDescription(items);
        }
    }
}