package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class Receipt {
    @SerializedName("id")
    private int id;

    @SerializedName("donation_id")
    private int donationId;

    @SerializedName("donation_type")
    private String donationType;

    @SerializedName("cause")
    private String cause;

    @SerializedName("amount_donated")
    private String amountDonated;

    @SerializedName("amount_used")
    private String amountUsed;

    @SerializedName("item_description")
    private String itemDescription;

    @SerializedName("quantity")
    private int quantity;

    @SerializedName("purpose")
    private String purpose;

    @SerializedName("remarks")
    private String remarks;

    @SerializedName("volunteer_name")
    private String volunteerName;

    @SerializedName("collected_at")
    private String collectedAt;

    @SerializedName("created_at")
    private String createdAt;

    @SerializedName("proof_url")
    private String proofUrl;

    // Getters
    public int getId() { return id; }
    public int getDonationId() { return donationId; }
    public String getDonationType() { return donationType; }
    public String getCause() { return cause; }
    public String getAmountDonated() { return amountDonated; }
    public String getAmountUsed() { return amountUsed; }
    public String getItemDescription() { return itemDescription; }
    public int getQuantity() { return quantity; }
    public String getPurpose() { return purpose; }
    public String getRemarks() { return remarks; }
    public String getVolunteerName() { return volunteerName; }
    public String getCollectedAt() { return collectedAt; }
    public String getCreatedAt() { return createdAt; }
    public String getProofUrl() { return proofUrl; }
}