package com.SIMATS.hope;

public class Dates {
    private String created_at;
    private String assigned_at;
    private String collected_at;
    private String updated_at;

    public String getCreatedAt() { return created_at; }
    public String getAssignedAt() { return assigned_at; }
    public String getCollectedAt() { return collected_at; }
    public String getUpdatedAt() { return updated_at; }
}
