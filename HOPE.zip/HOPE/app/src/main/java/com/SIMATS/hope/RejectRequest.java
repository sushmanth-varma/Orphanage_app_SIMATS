package com.SIMATS.hope;

// RejectRequest.java
public class RejectRequest {
    private String phone;
    private String email;

    public RejectRequest(String phone, String email) {
        this.phone = phone;
        this.email = email;
    }
}


