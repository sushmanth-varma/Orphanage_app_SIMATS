package com.SIMATS.hope;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DonationAdapter_admin extends RecyclerView.Adapter<DonationAdapter_admin.ViewHolder> {

    private List<Donation_admin> donationList;

    public DonationAdapter_admin(List<Donation_admin> donationList) {
        this.donationList = donationList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.donation_item_admin, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Donation_admin donation = donationList.get(position);
        holder.donorName.setText("Donor: " + donation.getDonorName());
        holder.donationType.setText("Type: " + donation.getDonationType());
        holder.donationAmount.setText("Amount: " + donation.getAmount());
        holder.textDate.setText("Date: " + donation.getDate());
        holder.donationStatus.setText("Volunteer: " + donation.getVolunteerName());
    }

    @Override
    public int getItemCount() {
        return donationList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView donorName, donationType, donationAmount, donationStatus, textDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            donorName = itemView.findViewById(R.id.donorName);
            donationType = itemView.findViewById(R.id.donationType);
            donationAmount = itemView.findViewById(R.id.donationAmount);
            textDate = itemView.findViewById(R.id.textDate);
            donationStatus = itemView.findViewById(R.id.donationStatus);
        }
    }
}
