package com.SIMATS.hope;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class UpdateReportAdapter_Volunteer extends RecyclerView.Adapter<UpdateReportAdapter_Volunteer.ViewHolder> {

    private final Context context;
    private final ArrayList<AssignedReport_Volunteer> list;

    public UpdateReportAdapter_Volunteer(Context context, ArrayList<AssignedReport_Volunteer> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.report_item_card_volunteer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AssignedReport_Volunteer report = list.get(position);

        holder.txtType.setText("Type: " + report.type);
        holder.txtName.setText("Name: " + report.name + ", Age: " + report.age);
        holder.txtLocation.setText("Location: " + report.generalLocation + " / " + report.exactLocation);
        holder.txtStatus.setText("Status: " + report.status);

        holder.btnUpdate.setOnClickListener(v -> {
            Toast.makeText(context, "Would update status for report #" + report.id,
                    Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtType, txtName, txtLocation, txtStatus;
        Button btnUpdate;

        public ViewHolder(View itemView) {
            super(itemView);
            txtType = itemView.findViewById(R.id.txtType);
            txtName = itemView.findViewById(R.id.txtName);
            txtLocation = itemView.findViewById(R.id.txtLocation);
            txtStatus = itemView.findViewById(R.id.txtStatus);
//            btnUpdate = itemView.findViewById(R.id.buttonUpdateStatus);
        }
    }
}