package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Volunteer_OTPVerificationActivity extends AppCompatActivity {
    EditText etOtp;
    Button btnNext;
    String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer_otp);

        phone = getIntent().getStringExtra("phone"); // receive phone
        etOtp = findViewById(R.id.etOtp);
        btnNext = findViewById(R.id.btnVerifyOtp);

        btnNext.setOnClickListener(v -> {
            String otp = etOtp.getText().toString().trim();
            if(otp.isEmpty()){
                etOtp.setError("Enter OTP");
                return;
            }

            // Navigate to Volunteer Registration screen
            Intent intent = new Intent(Volunteer_OTPVerificationActivity.this, VolunteerSuccessActivity.class);
            intent.putExtra("phone", phone);
            startActivity(intent);
        });
    }
}
