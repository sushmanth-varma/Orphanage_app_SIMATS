package com.SIMATS.hope;

public class SupportRequest {
    private int user_id;
    private String subject;
    private String message;

    public SupportRequest(int user_id, String subject, String message) {
        this.user_id = user_id;
        this.subject = subject;
        this.message = message;
    }
}