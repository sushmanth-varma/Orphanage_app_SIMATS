package com.SIMATS.hope;

public class SignupRequest {
    private String username;
    private String phone;
    private String password;
    private String confirm_password;
    private String role;

    public SignupRequest(String username, String phone, String password, String confirm_password, String role) {
        this.username = username;
        this.phone = phone;
        this.password = password;
        this.confirm_password = confirm_password;
        this.role = role;
    }

}
