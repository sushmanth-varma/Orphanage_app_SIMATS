package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ManageDonationActivity_Volunteer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_donation_volunteer);

        Button btnGetDonations = findViewById(R.id.btnGetDonations);

        btnGetDonations.setOnClickListener(v -> {
            // Navigate to the donations list screen
            Intent intent = new Intent(this, DonationListActivity_volunteer.class);
            // Pass the volunteer ID (you might get this from SharedPreferences or login)
            intent.putExtra("volunteer_id", 2); // Replace with actual volunteer ID
            startActivity(intent);
        });

//        btnUpdateStatus.setOnClickListener(v -> {
//            Intent intent = new Intent(this, DonationStatusUpdateActivity_volunteer.class);
//            startActivity(intent);
//        });
    }
}