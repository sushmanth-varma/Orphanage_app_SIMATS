package com.SIMATS.hope;

public class Donation_admin {
    private String donorName;
    private String donationType;
    private String amount;
    private String date;
    private String volunteerName;

    public Donation_admin(String donorName, String donationType, String amount, String date, String volunteerName) {
        this.donorName = donorName;
        this.donationType = donationType;
        this.amount = amount;
        this.date = date;
        this.volunteerName = volunteerName;
    }

    public String getDonorName() {
        return donorName;
    }

    public String getDonationType() {
        return donationType;
    }

    public String getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getVolunteerName() {
        return volunteerName;
    }
}
