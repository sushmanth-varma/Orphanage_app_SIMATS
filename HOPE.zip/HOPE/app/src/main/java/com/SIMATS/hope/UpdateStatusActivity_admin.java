package com.SIMATS.hope;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateStatusActivity_admin extends AppCompatActivity {

    EditText editDonationId;
    Spinner spinnerStatus;
    Button btnUpdateStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_status_admin);

        editDonationId = findViewById(R.id.editDonationId);
        spinnerStatus = findViewById(R.id.spinnerStatus);
        btnUpdateStatus = findViewById(R.id.btnUpdateStatus);

        // Spinner setup
        String[] statuses = {"Pending", "Accepted", "Rejected", "completed"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, statuses);
        spinnerStatus.setAdapter(adapter);

        btnUpdateStatus.setOnClickListener(view -> {
            String donationIdStr = editDonationId.getText().toString().trim();
            String status = spinnerStatus.getSelectedItem().toString();

            if (donationIdStr.isEmpty()) {
                showToast("Please enter Donation ID");
                return;
            }

            try {
                int donationId = Integer.parseInt(donationIdStr);
                updateDonationStatus(donationId, status);
            } catch (NumberFormatException e) {
                showToast("Invalid Donation ID format");
            }
        });
    }

    private void updateDonationStatus(int donationId, String status) {
        UpdateStatusRequest_donation request = new UpdateStatusRequest_donation(donationId, status);
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        apiService.updateDonationStatus(request).enqueue(new Callback<ApiResponse_update_donationstatus>() {
            @Override
            public void onResponse(Call<ApiResponse_update_donationstatus> call,
                                   Response<ApiResponse_update_donationstatus> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse_update_donationstatus apiResponse = response.body();
                    showToast(apiResponse.getMessage());
                    if ("success".equals(apiResponse.getStatus())) {
                        editDonationId.setText("");
                    }
                } else {
                    showToast("Failed to update status");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse_update_donationstatus> call, Throwable t) {
                showToast("Network error: " + t.getMessage());
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}