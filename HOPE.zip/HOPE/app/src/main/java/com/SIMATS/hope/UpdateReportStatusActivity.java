package com.SIMATS.hope;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateReportStatusActivity extends AppCompatActivity {

    private EditText reportIdInput;
    private Spinner statusSpinner;
    private Button updateButton;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_report_status);

        initializeViews();
        setupSpinner();
        setupApiService();
        setupButtonListener();
    }

    private void initializeViews() {
        reportIdInput = findViewById(R.id.reportIdInput);
        statusSpinner = findViewById(R.id.statusSpinner);
        updateButton = findViewById(R.id.updateButton);
    }

    private void setupSpinner() {
        String[] statuses = {"Pending", "Under Review", "Assigned to Volunteer", "Resolved", "Closed"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, statuses);
        statusSpinner.setAdapter(adapter);
    }

    private void setupApiService() {
        apiService = ApiClient.getClient().create(ApiService.class);
    }

    private void setupButtonListener() {
        updateButton.setOnClickListener(v -> {
            String reportIdStr = reportIdInput.getText().toString().trim();
            String selectedStatus = statusSpinner.getSelectedItem().toString();

            if (reportIdStr.isEmpty()) {
                Toast.makeText(this, "Please enter Report ID", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int reportId = Integer.parseInt(reportIdStr);
                updateReportStatus(reportId, selectedStatus);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid Report ID", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateReportStatus(int reportId, String status) {
        UpdateStatusRequest request = new UpdateStatusRequest(reportId, status);

        apiService.updateReportStatus(request).enqueue(new Callback<UpdateStatusResponse>() {
            @Override
            public void onResponse(Call<UpdateStatusResponse> call,
                                   Response<UpdateStatusResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    UpdateStatusResponse apiResponse = response.body();
                    if (apiResponse.isSuccess()) {
                        Toast.makeText(UpdateReportStatusActivity.this,
                                apiResponse.getMessage(), Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(UpdateReportStatusActivity.this,
                                "Failed: " + apiResponse.getMessage(), Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(UpdateReportStatusActivity.this,
                            "Server error", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UpdateStatusResponse> call, Throwable t) {
                Toast.makeText(UpdateReportStatusActivity.this,
                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}