package com.SIMATS.hope;

public class Donation_get_volunteer {
    private int id;
    private String donation_type;
    private String cause;
    private String amount;
    private String item_description;
    private int quantity;
    private DonorInfo_Volunteer donor_info;
    private String orphanage_name;
    private String location;
    private Dates dates;
    private String status;
    private String volunteer_username;

    public int getId() { return id; }
    public String getDonationType() { return donation_type; }
    public String getCause() { return cause; }
    public String getAmount() { return amount; }
    public String getItemDescription() { return item_description; }
    public int getQuantity() { return quantity; }
    public DonorInfo_Volunteer getDonorInfo() { return donor_info; }
    public String getOrphanageName() { return orphanage_name; }
    public String getLocation() { return location; }
    public Dates getDates() { return dates; }
    public String getStatus() { return status; }
    public String getVolunteerUsername() { return volunteer_username; }

    // ✅ Add this setter
    public void setStatus(String status) {
        this.status = status;
    }

    // ✅ Helper method to get donor phone
    public String getDonorPhone() {
        return donor_info != null ? donor_info.getPhone() : "Not available";
    }

    // ✅ Helper method to get donor name with phone
    public String getDonorNameWithPhone() {
        if (donor_info != null) {
            return donor_info.getFullName() + " (" + donor_info.getPhone() + ")";
        }
        return "Anonymous";
    }
}