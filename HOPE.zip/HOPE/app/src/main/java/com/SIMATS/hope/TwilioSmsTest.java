package com.SIMATS.hope;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class TwilioSmsTest {

    // Replace with your Twilio Account SID and Auth Token
    public static final String ACCOUNT_SID = "ACcb6a537bac3c559687ddad6bb3246353";
    public static final String AUTH_TOKEN = "84edc97da782d64b84b50fe570ec9d2c";

    public static void sendSms(String toPhone) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        Message message = Message.creator(
                        new PhoneNumber(toPhone),        // Receiver phone
                        new PhoneNumber("+919121957737"), // Twilio number
                        "Your OTP is: 123456")          // Message text
                .create();

        System.out.println("Message SID: " + message.getSid());
    }
}
