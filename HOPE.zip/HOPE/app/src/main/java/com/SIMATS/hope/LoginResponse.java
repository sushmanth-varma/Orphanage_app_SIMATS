//package com.SIMATS.hope;
//
//import com.google.gson.annotations.SerializedName;
//
//public class LoginResponse {
//    @SerializedName("status")
//    private String status;
//
//    @SerializedName("message")
//    private String message;
//
//    @SerializedName("user")
//    private User user;
//
//    public String getStatus() { return status; }
//    public String getMessage() { return message; }
//    public User getUser() { return user; }
//
//    public static class User {
//        @SerializedName("id")
//        private int id;
//
//        @SerializedName("username")
//        private String username;
//
//        @SerializedName("phone")
//        private String phone;
//
//        @SerializedName("role")
//        private String role;
//
//        @SerializedName("volunteer_id")
//        private int volunteerId;
//
//        public int getId() { return id; }
//        public String getUsername() { return username; }
//        public String getPhone() { return phone; }
//        public String getRole() { return role; }
//        public String getVolunteerId() { return volunteerId; }
//    }
//}
package com.SIMATS.hope;

public class LoginResponse {
    private String status;
    private String message;
    private User user;

    // Getters and setters
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public static class User {
        private int id;
        private String username;
        private String role;
        private int volunteerId; // This is an int

        // Getters and setters
        public int getId() { return id; }
        public void setId(int id) { this.id = id; }

        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }

        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }

        public int getVolunteerId() { return volunteerId; } // Return int
        public void setVolunteerId(int volunteerId) { this.volunteerId = volunteerId; }
    }
}