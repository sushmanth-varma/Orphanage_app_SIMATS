package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class VolunteerDashboardActivity extends AppCompatActivity {

    private CardView cardViewReports, cardViewDonations;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer_dashboard);

        initializeViews();
        setupClickListeners();
        setupBottomNavigation();
    }

    private void initializeViews() {
        cardViewReports = findViewById(R.id.cardViewReports);
        cardViewDonations = findViewById(R.id.cardViewDonations);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
    }

    private void setupClickListeners() {
        // Reports card click
        cardViewReports.setOnClickListener(v -> {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_click1);
            cardViewReports.startAnimation(anim);
            startActivity(new Intent(this, ReportsActivity_Volunteer.class));
        });

        // Donations card click
        cardViewDonations.setOnClickListener(v -> {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.button_click1);
            cardViewDonations.startAnimation(anim);
            startActivity(new Intent(this, ManageDonationActivity_Volunteer.class));
        });
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    // Already on home/dashboard
                    return true;
                } else if (itemId == R.id.nav_reports) {
                    startActivity(new Intent(VolunteerDashboardActivity.this, AssignedReportsActivity_Volunteer.class));
                    return true;
                } else if (itemId == R.id.nav_donations) {
                    startActivity(new Intent(VolunteerDashboardActivity.this, DonationListActivity_volunteer.class));
                    return true;
                }
                return false;
            }
        });

        // Set home as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reset to home tab when returning to this activity
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
    }
}