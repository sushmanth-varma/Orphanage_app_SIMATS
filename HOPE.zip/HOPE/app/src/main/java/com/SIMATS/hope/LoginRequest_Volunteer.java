package com.SIMATS.hope;

public class LoginRequest_Volunteer {
    private String phone;
    private String password;

    public LoginRequest_Volunteer(String phone, String password) {
        this.phone = phone;
        this.password = password;
    }
}