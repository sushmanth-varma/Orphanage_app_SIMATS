
package com.SIMATS.hope;

public class AssignVolunteerResponse {
    private boolean success;
    private String message;
    private String volunteer_phone;
    private String error;
    private int volunteer_id;

    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }

    public String getVolunteerPhone() { return volunteer_phone; }

    public int getVolunteerId() { return volunteer_id; }
    public void setSuccess(boolean success) { this.success = success; }
    public void setMessage(String message) { this.message = message; }
    public void setVolunteerPhone(String volunteer_phone) { this.volunteer_phone = volunteer_phone; }
    public void setVolunteerId(int volunteer_id) { this.volunteer_id = volunteer_id; }

    public String getError() {

        return error;
    }
}