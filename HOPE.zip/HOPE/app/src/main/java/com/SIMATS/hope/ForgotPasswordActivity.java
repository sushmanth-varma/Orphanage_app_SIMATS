package com.SIMATS.hope;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText phoneInput, newPassword, confirmPassword, currentPassword;
    private Button savePasswordBtn, cancelBtn;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot_password);

        // Initialize views
        phoneInput = findViewById(R.id.phoneForgot);
        currentPassword = findViewById(R.id.currentPass);
        newPassword = findViewById(R.id.newPass);
        confirmPassword = findViewById(R.id.confirmPass);
        savePasswordBtn = findViewById(R.id.sendCodeBtn);
        cancelBtn = findViewById(R.id.cancelBtn);

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        savePasswordBtn.setOnClickListener(v -> changePassword());
        cancelBtn.setOnClickListener(v -> finish());
    }

    private void changePassword() {
        String phone = phoneInput.getText().toString().trim();
        String currentPass = currentPassword.getText().toString().trim();
        String newPass = newPassword.getText().toString().trim();
        String confirmPass = confirmPassword.getText().toString().trim();

        // Validation
        if (phone.isEmpty()) {
            Toast.makeText(this, "Enter phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentPass.isEmpty()) {
            Toast.makeText(this, "Enter current password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (newPass.isEmpty()) {
            Toast.makeText(this, "Enter new password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (newPass.length() < 8) {
            Toast.makeText(this, "Password must be at least 8 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!newPass.equals(confirmPass)) {
            Toast.makeText(this, "Passwords don't match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get session cookie from SharedPreferences
        String sessionId = sharedPreferences.getString("session_id", "");
        String sessionCookie = "PHPSESSID=" + sessionId;

        // Create API service
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        // Create request object
        ChangePasswordRequest request = new ChangePasswordRequest(
                phone,
                currentPass,
                newPass,
                confirmPass
        );

        // Make API call
        Call<ChangePasswordResponse> call = apiService.changePassword(sessionCookie, request);
        call.enqueue(new Callback<ChangePasswordResponse>() {
            @Override
            public void onResponse(Call<ChangePasswordResponse> call, Response<ChangePasswordResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ChangePasswordResponse changeResponse = response.body();
                    if (changeResponse.getStatus().equals("success")) {
                        Toast.makeText(ForgotPasswordActivity.this,
                                "Password changed successfully", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(ForgotPasswordActivity.this,
                                changeResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    try {
                        String error = response.errorBody().string();
                        Toast.makeText(ForgotPasswordActivity.this,
                                "Error: " + error, Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(ForgotPasswordActivity.this,
                                "Failed to change password", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ChangePasswordResponse> call, Throwable t) {
                Toast.makeText(ForgotPasswordActivity.this,
                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}