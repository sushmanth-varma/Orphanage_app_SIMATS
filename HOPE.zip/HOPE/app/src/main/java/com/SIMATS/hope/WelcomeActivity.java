////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.os.Bundle;
////import android.widget.LinearLayout;
////import android.widget.TextView;
////import androidx.appcompat.app.AppCompatActivity;
////
////public class WelcomeActivity extends AppCompatActivity {
////
////    LinearLayout userLoginLayout, ngoLoginLayout, volunteerLoginLayout;
////    TextView registerLink, helpText;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.welcome_page); // Use the XML you posted
////
////        userLoginLayout = findViewById(R.id.userLoginLayout);
////        ngoLoginLayout = findViewById(R.id.ngoLoginLayout);
////        volunteerLoginLayout = findViewById(R.id.volunteerLoginLayout);
////        registerLink = findViewById(R.id.registerLink);
////        helpText = findViewById(R.id.helpText);
////
////        // Click listener for User Login
////        userLoginLayout.setOnClickListener(v -> {
////            Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
////            intent.putExtra("role", "user");
////            startActivity(intent);
////        });
////
////        // Click listener for NGO/Admin Login
////        ngoLoginLayout.setOnClickListener(v -> {
////            Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
////            intent.putExtra("role", "admin");
////            startActivity(intent);
////        });
////
////        // Click listener for Volunteer Login
////        volunteerLoginLayout.setOnClickListener(v -> {
////            Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
////            intent.putExtra("role", "volunteer");
////            startActivity(intent);
////        });
////
////        // Optional: Register
////        registerLink.setOnClickListener(v -> {
////            startActivity(new Intent(WelcomeActivity.this, SignupActivity.class));
////        });
////
////        // Optional: Help and Support
////        helpText.setOnClickListener(v -> {
////            startActivity(new Intent(WelcomeActivity.this, HelpSupportActivity.class));
////        });
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//import androidx.appcompat.app.AppCompatActivity;
//
//public class WelcomeActivity extends AppCompatActivity {
//
//    LinearLayout userLoginLayout, ngoLoginLayout, volunteerLoginLayout;
//    TextView registerLink, helpText;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.welcome_page); // This must match your layout filename
//
//        userLoginLayout = findViewById(R.id.userLoginLayout);
//        ngoLoginLayout = findViewById(R.id.ngoLoginLayout);
//        volunteerLoginLayout = findViewById(R.id.volunteerLoginLayout);
//        registerLink = findViewById(R.id.registerLink);
//        helpText = findViewById(R.id.helpText);
//
//        userLoginLayout.setOnClickListener(v -> {
//            Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
//            intent.putExtra("role", "user");
//            startActivity(intent);
//        });
//
//        ngoLoginLayout.setOnClickListener(v -> {
//            Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
//            intent.putExtra("role", "admin");
//            startActivity(intent);
//        });
//
//        volunteerLoginLayout.setOnClickListener(v -> {
//            Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
//            intent.putExtra("role", "volunteer");
//            startActivity(intent);
//        });
//
//        registerLink.setOnClickListener(v -> {
//            startActivity(new Intent(WelcomeActivity.this, SignupActivity.class));
//        });
//
//        helpText.setOnClickListener(v -> {
//            startActivity(new Intent(WelcomeActivity.this, HelpSupportActivity.class));
//        });
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_page);

        // Initialize views
        CardView userLoginLayout = findViewById(R.id.userLoginLayout);
        CardView ngoLoginLayout = findViewById(R.id.ngoLoginLayout);
        CardView volunteerLoginLayout = findViewById(R.id.volunteerLoginLayout);
        TextView registerLink = findViewById(R.id.registerLink);
        TextView helpText = findViewById(R.id.helpText);

        // Load animations
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        Animation slideUp = AnimationUtils.loadAnimation(this, R.anim.slide_up);
        Animation bounce = AnimationUtils.loadAnimation(this, R.anim.bounce);

        // Apply animations
        findViewById(R.id.logoImage).startAnimation(bounce);
        findViewById(R.id.appTitle).startAnimation(fadeIn);
        findViewById(R.id.tagline).startAnimation(fadeIn);
        findViewById(R.id.welcomeText).startAnimation(fadeIn);
        findViewById(R.id.subText).startAnimation(fadeIn);

        userLoginLayout.startAnimation(slideUp);
        ngoLoginLayout.startAnimation(slideUp);
        volunteerLoginLayout.startAnimation(slideUp);

        // Click listeners
        View.OnClickListener loginClick = v -> {
            v.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_click));
            new Handler().postDelayed(() -> {
                Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
                if (v == userLoginLayout) {
                    intent.putExtra("role", "user");
                } else if (v == ngoLoginLayout) {
                    intent.putExtra("role", "admin");
                } else {
                    intent.putExtra("role", "volunteer");
                }
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }, 200);
        };

        userLoginLayout.setOnClickListener(loginClick);
        ngoLoginLayout.setOnClickListener(loginClick);
        volunteerLoginLayout.setOnClickListener(loginClick);

        registerLink.setOnClickListener(v -> {
            v.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_click));
            new Handler().postDelayed(() -> {
                startActivity(new Intent(WelcomeActivity.this, SignupActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }, 200);
        });

        helpText.setOnClickListener(v -> {
            v.startAnimation(AnimationUtils.loadAnimation(this, R.anim.button_click));
            new Handler().postDelayed(() -> {
                startActivity(new Intent(WelcomeActivity.this, HelpSupportActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }, 200);
        });
    }
}