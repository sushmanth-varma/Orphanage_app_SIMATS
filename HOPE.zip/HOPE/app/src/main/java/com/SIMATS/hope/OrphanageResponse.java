package com.SIMATS.hope;

import java.util.List;

public class OrphanageResponse {
    private String status;
    private String requested_city;
    private String message;
    private List<Orphanage> orphanages;

    public String getStatus() { return status; }
    public String getRequested_city() { return requested_city; }
    public String getMessage() { return message; }
    public List<Orphanage> getOrphanages() { return orphanages; }
}
