//////package com.SIMATS.hope;
//////
//////import android.content.SharedPreferences;
//////import android.os.Bundle;
//////import android.util.Log;
//////import android.widget.Toast;
//////import androidx.appcompat.app.AppCompatActivity;
//////import androidx.recyclerview.widget.LinearLayoutManager;
//////import androidx.recyclerview.widget.RecyclerView;
//////import java.util.ArrayList;
//////import java.util.List;
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////
//////public class UserTrackCaseActivity extends AppCompatActivity {
//////    private static final String TAG = "UserTrackCaseActivity";
//////    private RecyclerView recyclerReports;
//////    private ReportAdapter_User adapter;
//////    private List<ReportModel> reportList = new ArrayList<>();
//////    private int userId;
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.activity_user_track_case);
//////
//////        // Get userId from SharedPreferences
//////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//////        userId = prefs.getInt("user_id", 0);
//////
//////        if (userId == 0) {
//////            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
//////            finish();
//////            return;
//////        }
//////
//////        initializeViews();
//////        setupRecyclerView();
//////        fetchUserReports();
//////    }
//////
//////    private void initializeViews() {
//////        recyclerReports = findViewById(R.id.recyclerReports);
//////    }
//////
//////    private void setupRecyclerView() {
//////        recyclerReports.setLayoutManager(new LinearLayoutManager(this));
//////        adapter = new ReportAdapter_User(this, reportList);
//////        recyclerReports.setAdapter(adapter);
//////    }
//////
//////    private void fetchUserReports() {
//////        ReportRequest request = new ReportRequest(userId);
//////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//////
//////        Call<ApiResponse_user> call = apiService.fetchUserReports(request);
//////        call.enqueue(new Callback<ApiResponse_user>() {
//////            @Override
//////            public void onResponse(Call<ApiResponse_user> call, Response<ApiResponse_user> response) {
//////                if (response.isSuccessful() && response.body() != null) {
//////                    ApiResponse_user apiResponse = response.body();
//////                    if (apiResponse.isSuccess()) {
//////                        reportList.clear();
//////                        reportList.addAll(apiResponse.getData());
//////                        adapter.notifyDataSetChanged();
//////                        Log.d(TAG, "Fetched " + reportList.size() + " reports");
//////
//////                        // Debug photo paths
//////                        for (ReportModel report : reportList) {
//////                            Log.d(TAG, "Photo path for report " + report.getId() + ": " + report.getPhotoPath());
//////                        }
//////                    } else {
//////                        Toast.makeText(UserTrackCaseActivity.this,
//////                                apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
//////                    }
//////                } else {
//////                    Toast.makeText(UserTrackCaseActivity.this,
//////                            "Failed to fetch reports", Toast.LENGTH_SHORT).show();
//////                    Log.e(TAG, "Response error: " + response.message());
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<ApiResponse_user> call, Throwable t) {
//////                Toast.makeText(UserTrackCaseActivity.this,
//////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////                Log.e(TAG, "Network error", t);
//////            }
//////        });
//////    }
//////}
////////package com.SIMATS.hope;
////////
////////import android.content.SharedPreferences;
////////import android.os.Bundle;
////////import android.util.Log;
////////import android.widget.Toast;
////////import androidx.appcompat.app.AppCompatActivity;
////////import androidx.recyclerview.widget.LinearLayoutManager;
////////import androidx.recyclerview.widget.RecyclerView;
////////import java.util.ArrayList;
////////import java.util.List;
////////import retrofit2.Call;
////////import retrofit2.Callback;
////////import retrofit2.Response;
////////
////////public class UserTrackCaseActivity extends AppCompatActivity {
////////    private static final String TAG = "UserTrackCaseActivity";
////////    private RecyclerView recyclerReports;
////////    private ReportAdapter_User adapter;
////////    private List<ReportModel> reportList = new ArrayList<>();
////////    private int userId;
////////
////////    @Override
////////    protected void onCreate(Bundle savedInstanceState) {
////////        super.onCreate(savedInstanceState);
////////        setContentView(R.layout.activity_user_track_case);
////////
////////        // Get userId from SharedPreferences
////////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////////        userId = prefs.getInt("user_id", 0);
////////
////////        if (userId == 0) {
////////            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
////////            finish();
////////            return;
////////        }
////////
////////        initializeViews();
////////        setupRecyclerView();
////////        fetchUserReports();
////////    }
////////
////////    private void initializeViews() {
////////        recyclerReports = findViewById(R.id.recyclerReports);
////////    }
////////
////////    private void setupRecyclerView() {
////////        recyclerReports.setLayoutManager(new LinearLayoutManager(this));
////////        adapter = new ReportAdapter_User(this, reportList);
////////        recyclerReports.setAdapter(adapter);
////////    }
////////
////////    private void fetchUserReports() {
////////        ReportRequest request = new ReportRequest(userId);
////////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////////
////////        Call<ApiResponse_user> call = apiService.fetchUserReports(request);
////////        call.enqueue(new Callback<ApiResponse_user>() {
////////            @Override
////////            public void onResponse(Call<ApiResponse_user> call, Response<ApiResponse_user> response) {
////////                if (response.isSuccessful() && response.body() != null) {
////////                    ApiResponse_user apiResponse = response.body();
////////                    if (apiResponse.isSuccess()) {
////////                        reportList.clear();
////////                        reportList.addAll(apiResponse.getData());
////////                        adapter.notifyDataSetChanged();
////////                        Log.d(TAG, "Successfully fetched " + reportList.size() + " reports");
////////
////////                        if (reportList.isEmpty()) {
////////                            Toast.makeText(UserTrackCaseActivity.this,
////////                                    "No reports found", Toast.LENGTH_SHORT).show();
////////                        }
////////                    } else {
////////                        Toast.makeText(UserTrackCaseActivity.this,
////////                                apiResponse.getMessage(), Toast.LENGTH_LONG).show();
////////                        Log.e(TAG, "API Error: " + apiResponse.getMessage());
////////                    }
////////                } else {
////////                    String errorMessage = "Failed to fetch reports: " + response.code();
////////                    if (response.errorBody() != null) {
////////                        try {
////////                            errorMessage += " - " + response.errorBody().string();
////////                        } catch (Exception e) {
////////                            Log.e(TAG, "Error parsing error body", e);
////////                        }
////////                    }
////////                    Toast.makeText(UserTrackCaseActivity.this,
////////                            errorMessage, Toast.LENGTH_LONG).show();
////////                    Log.e(TAG, errorMessage);
////////                }
////////            }
////////
////////            @Override
////////            public void onFailure(Call<ApiResponse_user> call, Throwable t) {
////////                String errorMsg = "Network error: " + t.getMessage();
////////                Toast.makeText(UserTrackCaseActivity.this,
////////                        errorMsg, Toast.LENGTH_LONG).show();
////////                Log.e(TAG, errorMsg, t);
////////            }
////////        });
////////    }
////////}
////package com.SIMATS.hope;
////
////import android.content.SharedPreferences;
////import android.os.Bundle;
////import android.util.Log;
////import android.view.View;
////import android.widget.ImageView;
////import android.widget.Toast;
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.recyclerview.widget.LinearLayoutManager;
////import androidx.recyclerview.widget.RecyclerView;
////import java.util.ArrayList;
////import java.util.List;
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class UserTrackCaseActivity extends AppCompatActivity {
////    private static final String TAG = "UserTrackCaseActivity";
////    private RecyclerView recyclerReports;
////    private ReportAdapter_User adapter;
////    private List<ReportModel> reportList = new ArrayList<>();
////    private ImageView ivBack; // Added back button reference
////    private int userId;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_user_track_case);
////
////        // Get userId from SharedPreferences
////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////        userId = prefs.getInt("user_id", 0);
////
////        if (userId == 0) {
////            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
////            finish();
////            return;
////        }
////
////        initializeViews();
////        setupRecyclerView();
////        fetchUserReports();
////    }
////
////    private void initializeViews() {
////        recyclerReports = findViewById(R.id.recyclerReports);
////        ivBack = findViewById(R.id.ivBack); // Initialize back button
////    }
////
////    private void setupRecyclerView() {
////        recyclerReports.setLayoutManager(new LinearLayoutManager(this));
////        adapter = new ReportAdapter_User(this, reportList);
////        recyclerReports.setAdapter(adapter);
////
////        // Add back button functionality
////        ivBack.setOnClickListener(v -> finish());
////    }
////
////    private void fetchUserReports() {
////        ReportRequest request = new ReportRequest(userId);
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////
////        Call<ApiResponse_user> call = apiService.fetchUserReports(request);
////        call.enqueue(new Callback<ApiResponse_user>() {
////            @Override
////            public void onResponse(Call<ApiResponse_user> call, Response<ApiResponse_user> response) {
////                if (response.isSuccessful() && response.body() != null) {
////                    ApiResponse_user apiResponse = response.body();
////                    if (apiResponse.isSuccess()) {
////                        reportList.clear();
////                        reportList.addAll(apiResponse.getData());
////                        adapter.notifyDataSetChanged();
////                        Log.d(TAG, "Fetched " + reportList.size() + " reports");
////
////                        // Debug photo paths
////                        for (ReportModel report : reportList) {
////                            Log.d(TAG, "Photo path for report " + report.getId() + ": " + report.getPhotoPath());
////                        }
////                    } else {
////                        Toast.makeText(UserTrackCaseActivity.this,
////                                apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
////                    }
////                } else {
////                    Toast.makeText(UserTrackCaseActivity.this,
////                            "Failed to fetch reports", Toast.LENGTH_SHORT).show();
////                    Log.e(TAG, "Response error: " + response.message());
////                }
////            }
////
////            @Override
////            public void onFailure(Call<ApiResponse_user> call, Throwable t) {
////                Toast.makeText(UserTrackCaseActivity.this,
////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////                Log.e(TAG, "Network error", t);
////            }
////        });
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.google.android.material.bottomnavigation.BottomNavigationView;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class UserTrackCaseActivity extends AppCompatActivity {
//    private static final String TAG = "UserTrackCaseActivity";
//    private RecyclerView recyclerReports;
//    private ReportAdapter_User adapter;
//    private List<ReportModel> reportList = new ArrayList<>();
//    private ImageView ivBack;
//    private BottomNavigationView bottomNavigationView;
//    private int userId;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_user_track_case);
//
//        // Get userId from SharedPreferences
//        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//        userId = prefs.getInt("user_id", 0);
//
//        if (userId == 0) {
//            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
//            finish();
//            return;
//        }
//
//        initializeViews();
//        setupBottomNavigation();
//        setupRecyclerView();
//        fetchUserReports();
//    }
//
//    private void initializeViews() {
//        recyclerReports = findViewById(R.id.recyclerReports);
//        ivBack = findViewById(R.id.ivBack);
//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//    }
//
//    private void setupBottomNavigation() {
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                int itemId = item.getItemId();
//
//                if (itemId == R.id.nav_home) {
//                    startActivity(new Intent(UserTrackCaseActivity.this, DashboardActivity.class));
//                    return true;
//                } else if (itemId == R.id.nav_donate) {
//                    startActivity(new Intent(UserTrackCaseActivity.this, DonateActivity.class));
//                    return true;
//                } else if (itemId == R.id.nav_report) {
//                    startActivity(new Intent(UserTrackCaseActivity.this, ReportChildActivity.class));
//                    return true;
//                } else if (itemId == R.id.nav_volunteer) {
//                    startActivity(new Intent(UserTrackCaseActivity.this, VolunteerRequestActivity.class));
//                    return true;
//                } else if (itemId == R.id.nav_profile) {
//                    startActivity(new Intent(UserTrackCaseActivity.this, SettingsActivity.class));
//                    return true;
//                }
//                return false;
//            }
//        });
//
//        // Since this is a tracking page that might not be in the bottom nav,
//        // we won't set any item as selected by default
//        // If you add a track menu item, uncomment the line below:
//        // bottomNavigationView.setSelectedItemId(R.id.nav_track);
//    }
//
//    private void setupRecyclerView() {
//        recyclerReports.setLayoutManager(new LinearLayoutManager(this));
//        adapter = new ReportAdapter_User(this, reportList);
//        recyclerReports.setAdapter(adapter);
//
//        // Add back button functionality
//        ivBack.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//        });
//    }
//
//    private void fetchUserReports() {
//        ReportRequest request = new ReportRequest(userId);
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//
//        Call<ApiResponse_user> call = apiService.fetchUserReports(request);
//        call.enqueue(new Callback<ApiResponse_user>() {
//            @Override
//            public void onResponse(Call<ApiResponse_user> call, Response<ApiResponse_user> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    ApiResponse_user apiResponse = response.body();
//                    if (apiResponse.isSuccess()) {
//                        reportList.clear();
//                        reportList.addAll(apiResponse.getData());
//                        adapter.notifyDataSetChanged();
//                        Log.d(TAG, "Fetched " + reportList.size() + " reports");
//
//                        // Show message if no reports found
//                        if (reportList.isEmpty()) {
//                            Toast.makeText(UserTrackCaseActivity.this,
//                                    "No reports found", Toast.LENGTH_SHORT).show();
//                        }
//
//                        // Debug photo paths
//                        for (ReportModel report : reportList) {
//                            Log.d(TAG, "Photo path for report " + report.getId() + ": " + report.getPhotoPath());
//                        }
//                    } else {
//                        Toast.makeText(UserTrackCaseActivity.this,
//                                apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Toast.makeText(UserTrackCaseActivity.this,
//                            "Failed to fetch reports", Toast.LENGTH_SHORT).show();
//                    Log.e(TAG, "Response error: " + response.message());
//
//                    // Try to read error body for more details
//                    try {
//                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
//                        Log.e(TAG, "Error body: " + errorBody);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ApiResponse_user> call, Throwable t) {
//                Toast.makeText(UserTrackCaseActivity.this,
//                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//                Log.e(TAG, "Network error", t);
//            }
//        });
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        // Since this is a tracking page that might not be in the bottom nav,
//        // we won't set any item as selected by default
//
//        // Optional: Refresh data when returning to this activity
//        fetchUserReports();
//    }
//
//    // Handle back button press
//    @Override
//    public void onBackPressed() {
//        super.onBackPressed();
//        finish();
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserTrackCaseActivity extends AppCompatActivity {
    private static final String TAG = "UserTrackCaseActivity";
    private RecyclerView recyclerReports;
    private ReportAdapter_User adapter;
    private List<ReportModel> reportList = new ArrayList<>();
    private ImageView ivBack;
    private BottomNavigationView bottomNavigationView;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_track_case);

        // Get userId from SharedPreferences
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        userId = prefs.getInt("user_id", 0);

        if (userId == 0) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initializeViews();
        setupBottomNavigation();
        setupRecyclerView();
        fetchUserReports();
    }

    private void initializeViews() {
        recyclerReports = findViewById(R.id.recyclerReports);
        ivBack = findViewById(R.id.ivBack);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(UserTrackCaseActivity.this, DashboardActivity.class));
                    return true;
                } else if (itemId == R.id.nav_donate) {
                    startActivity(new Intent(UserTrackCaseActivity.this, DonateActivity.class));
                    return true;
                } else if (itemId == R.id.nav_report) {
                    startActivity(new Intent(UserTrackCaseActivity.this, ReportChildActivity.class));
                    return true;
                } else if (itemId == R.id.nav_volunteer) {
                    startActivity(new Intent(UserTrackCaseActivity.this, VolunteerRequestActivity.class));
                    return true;
                } else if (itemId == R.id.nav_profile) {
                    // Already going to settings, no need to navigate
                    return true;
                }
                return false;
            }
        });

        // Highlight the Settings (Profile) button instead of Donate
        bottomNavigationView.setSelectedItemId(R.id.nav_profile);
    }

    private void setupRecyclerView() {
        recyclerReports.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ReportAdapter_User(this, reportList);
        recyclerReports.setAdapter(adapter);

        // Add back button functionality
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void fetchUserReports() {
        ReportRequest request = new ReportRequest(userId);
        ApiService apiService = ApiClient.getClient().create(ApiService.class);

        Call<ApiResponse_user> call = apiService.fetchUserReports(request);
        call.enqueue(new Callback<ApiResponse_user>() {
            @Override
            public void onResponse(Call<ApiResponse_user> call, Response<ApiResponse_user> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse_user apiResponse = response.body();
                    if (apiResponse.isSuccess()) {
                        reportList.clear();
                        reportList.addAll(apiResponse.getData());
                        adapter.notifyDataSetChanged();
                        Log.d(TAG, "Fetched " + reportList.size() + " reports");

                        // Show message if no reports found
                        if (reportList.isEmpty()) {
                            Toast.makeText(UserTrackCaseActivity.this,
                                    "No reports found", Toast.LENGTH_SHORT).show();
                        }

                        // Debug photo paths
                        for (ReportModel report : reportList) {
                            Log.d(TAG, "Photo path for report " + report.getId() + ": " + report.getPhotoPath());
                        }
                    } else {
                        Toast.makeText(UserTrackCaseActivity.this,
                                apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(UserTrackCaseActivity.this,
                            "Failed to fetch reports", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Response error: " + response.message());

                    // Try to read error body for more details
                    try {
                        String errorBody = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
                        Log.e(TAG, "Error body: " + errorBody);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ApiResponse_user> call, Throwable t) {
                Toast.makeText(UserTrackCaseActivity.this,
                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Network error", t);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Highlight the Settings (Profile) button when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_profile);
        }
    }

    // Handle back button press
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}