package com.SIMATS.hope;

import java.util.ArrayList;
import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {

    @POST("login.php")
    Call<LoginResponse> loginUser(@Body LoginRequest requestBody);

    @POST("signup.php")
    Call<SignupResponse> registerUser(@Body SignupRequest requestBody);

    @POST("volunteer_request.php") // Replace with your actual endpoint
    Call<Volunteer_OtpResponse> registerVolunteer(@Body VolunteerRequest volunteerRequest);


    @GET("admin_get_all_volunteers.php")
    Call<VolunteerResponse> getAllVolunteers();

    @POST("reject_volunteer.php")
    Call<ApproveResponse> rejectVolunteer(@Body RejectRequest body);

    @POST("admin_approve_volunteer.php")
    Call<ApproveResponse> approveVolunteer(@Body ApproveRequest request);

    // Remove this duplicate method
    // @FormUrlEncoded
     @GET("process_donation.php")
     Call<DonationResponse> getDonation(@Query("id") int donationId);


    @POST("submit_monetary_donation.php")
    Call<DonationResponse> sendMonetaryDonation(@Body MonetaryDonationRequest request);

    @POST("submit_material_donation.php")
    Call<DonationResponse> sendMaterialDonation(@Body MaterialDonationRequest request);

    @GET("get_user_donations.php")
    Call<DonationListResponse> getUserDonations(@Query("user_id") int userId);
    @Multipart
    @POST("report_person.php")
    Call<ResponseBody> submitReport(
            @Part("user_id") RequestBody userId,
            @Part("type") RequestBody type,
            @Part("name") RequestBody name,
            @Part("age") RequestBody age,
            @Part("general_location") RequestBody generalLocation,
            @Part("exact_location") RequestBody exactLocation,
            @Part("details") RequestBody details,
            @Part("is_anonymous") RequestBody isAnonymous,
            @Part("orphanage_id") RequestBody orphanageId,
            @Part MultipartBody.Part photo
    );
    // ... (your existing methods)

        @POST("track_user_reports.php")
        Call<ApiResponse_user> fetchUserReports(@Body ReportRequest request);
    @GET("view_reports.php")
    Call<ApiResponseViewReportsAdmin> getAllReports();



    // Add this new method for volunteer assignment
    @POST("assign_volunteer.php")
    Call<AssignVolunteerResponse> assignVolunteer(@Body AssignVolunteerRequest request);
    @POST("update_report_status.php")  // Match your PHP endpoint
    Call<UpdateStatusResponse> updateReportStatus(@Body UpdateStatusRequest request);
    @GET("admin_get_donations.php")
    Call<DonationResponse_get_Admin> getDonations();
    @POST("admin_assign_volunteer.php") // Update this endpoint to match your PHP file
    Call<AssignmentResponse_Donation_admin> assignVolunteer(@Body AssignmentRequest_Donation_admin request);
    @POST("admin_update_status.php")
    Call<ApiResponse_update_donationstatus> updateDonationStatus(@Body UpdateStatusRequest_donation request);
    @GET("get_assigned_reports.php")
    Call<ApiResponseAssignedReports> getAssignedReports(@Query("volunteer_id") int volunteerId);
    @POST("volunteer_login.php")
    Call<VolunteerLoginResponse> loginVolunteer(@Body VolunteerLoginRequest request);
    @POST("update_report_status_by_volunteer.php")
    Call<UpdateStatusResponse_Volunteer> updateReportStatus_Volunteer(@Body UpdateStatusRequest_Volunteer request);
    @GET("volunteer_get_donations.php")
    Call<DonationResponse_get_Volunteer> getVolunteerDonations(@Query("volunteer_id") int volunteerId);
    @POST("volunteer_update_status.php")
    Call<StatusUpdateResponse_Volunteer> updateDonationStatus_Volunteer(@Body StatusUpdateRequest_Volunteer request);
    @Multipart
    @POST("edit_profile.php")
    Call<ProfileUpdateResponse> updateProfile(
            @Part("user_id") RequestBody userId,
            @Part("name") RequestBody name,
            @Part MultipartBody.Part profilePhoto
    );
    @POST("change_password.php")
    Call<ChangePasswordResponse> changePassword(
            @Header("Cookie") String sessionCookie,
            @Body ChangePasswordRequest request
    );
    @POST("support.php")
    Call<ApiResult<SupportResponse>> submitSupportRequest(@Body SupportRequest request);

    @GET("helplines.php")
    Call<ApiResult<List<Helpline>>> getHelplines();

    @GET("resources.php")
    Call<ApiResult<List<Resource>>> getResources();
    @POST("update_report_status_volunteer.php")
    Call<UpdateStatusResponse_Volunteer> updateReportStatusVolunteer(
            @Body UpdateStatusRequest_Volunteer request
    );
    @GET("get_cities_with_orphanages.php")
    Call<CityResponse> getAllCities();

    // Get orphanages by city
    @GET("get_orphanages.php")
    Call<OrphanageResponse> getOrphanages(@Query("city") String city);
    @GET("get_receipts.php")
    Call<ReceiptsListResponse> getUserReceipts(@Query("user_id") int userId);

    @Multipart
    @POST("upload_receipt.php")
    Call<UploadResponse> uploadReceipt(
            @Part("donation_id") RequestBody donationId,
            @Part("volunteer_id") RequestBody volunteerId,
            @Part("purpose") RequestBody purpose,
            @Part("remarks") RequestBody remarks,
            @Part("amount_donated") RequestBody amountDonated,
            @Part("amount_used") RequestBody amountUsed,
            @Part("item_description") RequestBody itemDescription, // Make sure this matches PHP
            @Part("quantity") RequestBody quantity,
            @Part MultipartBody.Part file
    );


    // Generate PDF receipt
    @GET("generate_receipt.php")
    Call<ResponseBody> generateReceiptPdf(@Query("receipt_id") int receiptId);

    // Download PDF receipt
    @GET("download_receipt.php")
    Call<ResponseBody> downloadReceiptPdf(@Query("receipt_id") int receiptId, @Query("type") String type);
    @FormUrlEncoded
    @POST("update_fcm_token.php")
    Call<BaseResponse> updateFcmToken(
            @Field("user_id") int userId,
            @Field("fcm_token") String fcmToken
    );
    @GET("get_resources_helplines.php") // file name in your XAMPP folder
    Call<get_resourses> getResourcesAndHelplines();

}



