package com.SIMATS.hope;

import com.google.gson.annotations.SerializedName;

public class DonationDetailResponse {
    @SerializedName("status")
    private boolean status;

    @SerializedName("message")
    private String message;

    @SerializedName("data")
    private DonationData data;

    public boolean isStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public DonationData getData() {
        return data;
    }

}