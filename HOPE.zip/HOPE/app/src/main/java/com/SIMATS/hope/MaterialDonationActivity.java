////package com.SIMATS.hope;
////
////import android.app.ProgressDialog;
////import android.content.SharedPreferences;
////import android.os.Bundle;
////import android.view.View;
////import android.widget.Button;
////import android.widget.EditText;
////import android.widget.ImageView;
////import android.widget.Toast;
////
////import androidx.appcompat.app.AppCompatActivity;
////
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class MaterialDonationActivity extends AppCompatActivity {
////    private EditText editCause, editItem, editQuantity, editOrphanageName,
////            editName, editPhone, editLocation;
////    private Button btnSubmit;
////    private ImageView ivBack; // Added back button reference
////    private ApiService apiService;
////    private ProgressDialog progressDialog;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_material_donation);
////
////        initializeViews();
////        setupListeners();
////    }
////
////    private void initializeViews() {
////        editCause = findViewById(R.id.editTextCause);
////        editItem = findViewById(R.id.editTextItem);
////        editQuantity = findViewById(R.id.editTextQuantity);
////        editOrphanageName = findViewById(R.id.editTextOrphanageName);
////        editName = findViewById(R.id.editTextName);
////        editPhone = findViewById(R.id.editTextEmail); // Note: This should be editTextPhone if you rename it
////        editLocation = findViewById(R.id.editTextLocation);
////        btnSubmit = findViewById(R.id.btnSubmitMaterial);
////        ivBack = findViewById(R.id.ivBack); // Initialize back button
////
////        apiService = ApiClient.getClient().create(ApiService.class);
////        progressDialog = new ProgressDialog(this);
////        progressDialog.setMessage("Submitting donation...");
////        progressDialog.setCancelable(false);
////    }
////
////    private void setupListeners() {
////        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
////
////        // Add back button functionality
////        ivBack.setOnClickListener(v -> finish());
////    }
////
////    private void validateAndSubmitDonation() {
////        String cause = editCause.getText().toString().trim();
////        String item = editItem.getText().toString().trim();
////        String quantityStr = editQuantity.getText().toString().trim();
////        String name = editName.getText().toString().trim();
////        String phone = editPhone.getText().toString().trim();
////        String orphanageName = editOrphanageName.getText().toString().trim();
////        String location = editLocation.getText().toString().trim();
////
////        // Validate inputs
////        if (!FormValidator.validateField(editCause, "Please enter a cause")) return;
////        if (!FormValidator.validateField(editItem, "Please describe the items")) return;
////        if (!FormValidator.validateField(editQuantity, "Please enter quantity")) return;
////        if (!FormValidator.validateField(editOrphanageName, "Please enter orphanage name")) return;
////        if (!FormValidator.validateField(editLocation, "Please enter location")) return;
////        if (!FormValidator.validateField(editName, "Please enter your name")) return;
////        if (!FormValidator.validateField(editPhone, "Please enter phone number")) return;
////
////
////        try {
////            int quantity = Integer.parseInt(quantityStr);
////            if (quantity <= 0) {
////                editQuantity.setError("Quantity must be greater than 0");
////                editQuantity.requestFocus();
////                return;
////            }
////
////            submitDonationToServer(cause, item, quantity, name, phone, orphanageName, location);
////        } catch (NumberFormatException e) {
////            editQuantity.setError("Please enter a valid number");
////            editQuantity.requestFocus();
////        }
////    }
////
////    private void submitDonationToServer(String cause, String item, int quantity,
////                                        String name, String phone, String orphanageName,
////                                        String location) {
////        progressDialog.show();
////        btnSubmit.setEnabled(false);
////
////        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
////        int userId = prefs.getInt("user_id",0);
////
////        MaterialDonationRequest request = new MaterialDonationRequest(
////                cause, item, quantity, name, phone, orphanageName, location,userId
////        );
////
////        Call<DonationResponse> call = apiService.sendMaterialDonation(request);
////        call.enqueue(new Callback<DonationResponse>() {
////            @Override
////            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
////                progressDialog.dismiss();
////                btnSubmit.setEnabled(true);
////
////                if (response.isSuccessful() && response.body() != null) {
////                    DonationResponse donationResponse = response.body();
////                    if (donationResponse.isSuccess()) {
////                        showSuccess(donationResponse.getMessage());
////                    } else {
////                        showError(donationResponse.getMessage());
////                    }
////                } else {
////                    showError("Server error occurred");
////                }
////            }
////
////            @Override
////            public void onFailure(Call<DonationResponse> call, Throwable t) {
////                progressDialog.dismiss();
////                btnSubmit.setEnabled(true);
////                showError("Network error: " + t.getMessage());
////            }
////        });
////    }
////
////    private void showSuccess(String message) {
////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
////        clearForm();
////    }
////
////    private void showError(String message) {
////        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
////    }
////
////    private void clearForm() {
////        editCause.setText("");
////        editItem.setText("");
////        editQuantity.setText("");
////        editName.setText("");
////        editPhone.setText("");
////        editOrphanageName.setText("");
////        editLocation.setText("");
////    }
////}
//package com.SIMATS.hope;
//
//import android.app.ProgressDialog;
//import android.content.SharedPreferences;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.Spinner;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class MaterialDonationActivity extends AppCompatActivity {
//    private Spinner spinnerCause, spinnerCategory, spinnerItem, spinnerUnit, spinnerLocation, spinnerOrphanage;
//    private EditText editQuantity, editName, editPhone, editOtherItem;
//    private Button btnSubmit;
//    private ImageView ivBack;
//    private ApiService apiService;
//    private ProgressDialog progressDialog;
//    private View layoutOtherItem;
//
//    private List<String> causesList = new ArrayList<>();
//    private List<String> categoriesList = new ArrayList<>();
//    private Map<String, List<String>> categoryItemsMap = new HashMap<>();
//    private List<String> unitsList = new ArrayList<>();
//    private List<String> citiesList = new ArrayList<>();
//    private List<Orphanage> orphanageList = new ArrayList<>();
//    private Map<String, List<String>> itemUnitsMap = new HashMap<>();
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_material_donation);
//
//        initializeViews();
//        setupData();
//        setupListeners();
//        setupRealTimeValidation(); // Add this line
//    }
//
//    private void initializeViews() {
//        spinnerCause = findViewById(R.id.spinnerCause);
//        spinnerCategory = findViewById(R.id.spinnerCategory);
//        spinnerItem = findViewById(R.id.spinnerItem);
//        spinnerUnit = findViewById(R.id.spinnerUnit);
//        spinnerLocation = findViewById(R.id.spinnerLocation);
//        spinnerOrphanage = findViewById(R.id.spinnerOrphanage);
//        editQuantity = findViewById(R.id.editTextQuantity);
//        editName = findViewById(R.id.editTextName);
//        editPhone = findViewById(R.id.editTextPhone);
//        editOtherItem = findViewById(R.id.editTextOtherItem);
//        btnSubmit = findViewById(R.id.btnSubmitMaterial);
//        ivBack = findViewById(R.id.ivBack);
//        layoutOtherItem = findViewById(R.id.layoutOtherItem);
//
//        apiService = ApiClient.getClient().create(ApiService.class);
//        progressDialog = new ProgressDialog(this);
//        progressDialog.setMessage("Submitting donation...");
//        progressDialog.setCancelable(false);
//    }
//
//    private void setupData() {
//        // Setup causes
//        causesList.add("Select Cause");
//        causesList.add("Donation for Children");
//        causesList.add("Donation for Disabled Persons");
//        causesList.add("Donation for Education");
//        causesList.add("Donation for Food & Nutrition");
//        causesList.add("Donation for Healthcare");
//        causesList.add("Donation for Shelter");
//        causesList.add("Donation for Clothing");
//        causesList.add("General Donation");
//
//        ArrayAdapter<String> causeAdapter = new ArrayAdapter<>(this,
//                android.R.layout.simple_spinner_dropdown_item, causesList);
//        spinnerCause.setAdapter(causeAdapter);
//
//        // Setup categories
//        categoriesList.add("Select Category");
//        categoriesList.add("Clothing");
//        categoriesList.add("Food Items");
//        categoriesList.add("Kitchen Items");
//        categoriesList.add("Educational Materials");
//        categoriesList.add("Medical Supplies");
//        categoriesList.add("Toys & Games");
//        categoriesList.add("Furniture");
//        categoriesList.add("Bedding & Linens");
//        categoriesList.add("Electronics");
//        categoriesList.add("Hygiene Products");
//        categoriesList.add("Sports Equipment");
//        categoriesList.add("Books & Stationery");
//        categoriesList.add("Other");
//
//        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this,
//                android.R.layout.simple_spinner_dropdown_item, categoriesList);
//        spinnerCategory.setAdapter(categoryAdapter);
//
//        // Setup category items mapping
//        setupCategoryItems();
//
//        // Setup units
//        unitsList.add("Select Unit");
//        unitsList.add("Pieces");
//        unitsList.add("Kg");
//        unitsList.add("Liters");
//        unitsList.add("Boxes");
//        unitsList.add("Pairs");
//        unitsList.add("Sets");
//        unitsList.add("Bags");
//        unitsList.add("Packets");
//        unitsList.add("Bottles");
//        unitsList.add("Cartons");
//        unitsList.add("Dozen");
//        unitsList.add("Meters");
//        unitsList.add("Rolls");
//
//        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(this,
//                android.R.layout.simple_spinner_dropdown_item, unitsList);
//        spinnerUnit.setAdapter(unitAdapter);
//
//        // Fetch cities
//        fetchCities();
//
//        // Setup listeners
//        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedCategory = parent.getItemAtPosition(position).toString();
//                if (!selectedCategory.equals("Select Category")) {
//                    updateItemSpinner(selectedCategory);
//                }
//                // Hide other item field when category changes
//                layoutOtherItem.setVisibility(View.GONE);
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });
//        spinnerItem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedItem = parent.getItemAtPosition(position).toString();
//                if (selectedItem.equals("Other (Please specify)")) {
//                    layoutOtherItem.setVisibility(View.VISIBLE);
//                } else {
//                    layoutOtherItem.setVisibility(View.GONE);
//                    // Update units based on selected item
//                    updateUnitSpinner(selectedItem);
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });
//
//        spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selectedCity = parent.getItemAtPosition(position).toString();
//                if (!selectedCity.equals("Select Location") && !selectedCity.isEmpty()) {
//                    fetchOrphanages(selectedCity);
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//            }
//        });
//    }
//
//    private void setupCategoryItems() {
//        // Clothing items
//        List<String> clothingItems = new ArrayList<>();
//        clothingItems.add("Select Item");
//        clothingItems.add("Shirts/T-Shirts");
//        clothingItems.add("Pants/Trousers");
//        clothingItems.add("Dresses/Skirts");
//        clothingItems.add("Sweaters/Hoodies");
//        clothingItems.add("Jackets/Coats");
//        clothingItems.add("Shoes (New)");
//        clothingItems.add("Socks");
//        clothingItems.add("Underwear (New)");
//        clothingItems.add("Winter Wear");
//        clothingItems.add("Traditional Clothes");
//        clothingItems.add("Baby Clothes");
//        clothingItems.add("School Uniforms");
//        categoryItemsMap.put("Clothing", clothingItems);
//
//        // Food items
//        List<String> foodItems = new ArrayList<>();
//        foodItems.add("Select Item");
//        foodItems.add("Rice");
//        foodItems.add("Wheat Flour");
//        foodItems.add("Lentils/Dal");
//        foodItems.add("Cooking Oil");
//        foodItems.add("Sugar");
//        foodItems.add("Salt");
//        foodItems.add("Tea Leaves");
//        foodItems.add("Coffee Powder");
//        foodItems.add("Biscuits");
//        foodItems.add("Dry Fruits");
//        foodItems.add("Spices");
//        foodItems.add("Canned Food");
//        foodItems.add("Baby Food");
//        foodItems.add("Milk Powder");
//        foodItems.add("Honey");
//        foodItems.add("Chocolate");
//        categoryItemsMap.put("Food Items", foodItems);
//
//        // Kitchen items
//        List<String> kitchenItems = new ArrayList<>();
//        kitchenItems.add("Select Item");
//        kitchenItems.add("Plates/Bowls");
//        kitchenItems.add("Cups/Glasses");
//        kitchenItems.add("Spoons/Forks");
//        kitchenItems.add("Cooking Pots");
//        kitchenItems.add("Frying Pans");
//        kitchenItems.add("Knives");
//        kitchenItems.add("Food Containers");
//        kitchenItems.add("Water Bottles");
//        kitchenItems.add("Thermos Flasks");
//        kitchenItems.add("Cutting Boards");
//        kitchenItems.add("Mixer Grinder");
//        kitchenItems.add("Gas Stove");
//        kitchenItems.add("Pressure Cooker");
//        categoryItemsMap.put("Kitchen Items", kitchenItems);
//
//        // Educational Materials
//        List<String> educationalItems = new ArrayList<>();
//        educationalItems.add("Select Item");
//        educationalItems.add("School Books");
//        educationalItems.add("Notebooks");
//        educationalItems.add("Pens/Pencils");
//        educationalItems.add("Erasers/Sharpeners");
//        educationalItems.add("School Bags");
//        educationalItems.add("Geometry Sets");
//        educationalItems.add("Art Supplies");
//        educationalItems.add("Story Books");
//        educationalItems.add("Dictionaries");
//        educationalItems.add("Calculators");
//        educationalItems.add("Whiteboards");
//        educationalItems.add("Markers");
//        educationalItems.add("Educational Toys");
//        categoryItemsMap.put("Educational Materials", educationalItems);
//
//        // Medical Supplies
//        List<String> medicalItems = new ArrayList<>();
//        medicalItems.add("Select Item");
//        medicalItems.add("First Aid Kits");
//        medicalItems.add("Bandages");
//        medicalItems.add("Antiseptic Cream");
//        medicalItems.add("Pain Relievers");
//        medicalItems.add("Thermometers");
//        medicalItems.add("Vitamins");
//        medicalItems.add("Baby Care Products");
//        medicalItems.add("Sanitary Napkins");
//        medicalItems.add("Disinfectants");
//        medicalItems.add("Hand Sanitizer");
//        medicalItems.add("Masks");
//        medicalItems.add("Gloves");
//        medicalItems.add("Walking Aids");
//        categoryItemsMap.put("Medical Supplies", medicalItems);
//
//        // Toys & Games
//        List<String> toysItems = new ArrayList<>();
//        toysItems.add("Select Item");
//        toysItems.add("Soft Toys");
//        toysItems.add("Building Blocks");
//        toysItems.add("Board Games");
//        toysItems.add("Puzzles");
//        toysItems.add("Sports Equipment");
//        toysItems.add("Art & Craft Kits");
//        toysItems.add("Educational Toys");
//        toysItems.add("Outdoor Games");
//        toysItems.add("Dolls");
//        toysItems.add("Toy Vehicles");
//        toysItems.add("Musical Instruments");
//        toysItems.add("Books");
//        categoryItemsMap.put("Toys & Games", toysItems);
//
//        // Furniture
//        List<String> furnitureItems = new ArrayList<>();
//        furnitureItems.add("Select Item");
//        furnitureItems.add("Beds");
//        furnitureItems.add("Mattresses");
//        furnitureItems.add("Study Tables");
//        furnitureItems.add("Chairs");
//        furnitureItems.add("Cupboards");
//        furnitureItems.add("Shelves");
//        furnitureItems.add("Desks");
//        furnitureItems.add("Bean Bags");
//        furnitureItems.add("Storage Boxes");
//        furnitureItems.add("Baby Cribs");
//        furnitureItems.add("Sofas");
//        categoryItemsMap.put("Furniture", furnitureItems);
//
//        // Bedding & Linens
//        List<String> beddingItems = new ArrayList<>();
//        beddingItems.add("Select Item");
//        beddingItems.add("Blankets");
//        beddingItems.add("Bed Sheets");
//        beddingItems.add("Pillows");
//        beddingItems.add("Towels");
//        beddingItems.add("Curtains");
//        beddingItems.add("Mosquito Nets");
//        beddingItems.add("Sleeping Bags");
//        beddingItems.add("Quilts");
//        beddingItems.add("Mattress Covers");
//        categoryItemsMap.put("Bedding & Linens", beddingItems);
//
//        // Electronics
//        List<String> electronicsItems = new ArrayList<>();
//        electronicsItems.add("Select Item");
//        electronicsItems.add("Computers/Laptops");
//        electronicsItems.add("Tablets");
//        electronicsItems.add("Mobile Phones");
//        electronicsItems.add("Televisions");
//        electronicsItems.add("Fans");
//        electronicsItems.add("Lights/Lamps");
//        electronicsItems.add("Radios");
//        electronicsItems.add("Chargers");
//        electronicsItems.add("Power Banks");
//        electronicsItems.add("Headphones");
//        categoryItemsMap.put("Electronics", electronicsItems);
//
//        // Hygiene Products
//        List<String> hygieneItems = new ArrayList<>();
//        hygieneItems.add("Select Item");
//        hygieneItems.add("Soap");
//        hygieneItems.add("Shampoo");
//        hygieneItems.add("Toothpaste");
//        hygieneItems.add("Toothbrushes");
//        hygieneItems.add("Toilet Paper");
//        hygieneItems.add("Diapers");
//        hygieneItems.add("Baby Wipes");
//        hygieneItems.add("Deodorant");
//        hygieneItems.add("Combs/Brushes");
//        hygieneItems.add("Laundry Detergent");
//        categoryItemsMap.put("Hygiene Products", hygieneItems);
//
//        // Sports Equipment
//        List<String> sportsItems = new ArrayList<>();
//        sportsItems.add("Select Item");
//        sportsItems.add("Cricket Sets");
//        sportsItems.add("Football");
//        sportsItems.add("Basketball");
//        sportsItems.add("Volleyball");
//        sportsItems.add("Badminton Sets");
//        sportsItems.add("Skating Equipment");
//        sportsItems.add("Yoga Mats");
//        sportsItems.add("Exercise Equipment");
//        sportsItems.add("Swimming Gear");
//        categoryItemsMap.put("Sports Equipment", sportsItems);
//
//        // Books & Stationery
//        List<String> booksItems = new ArrayList<>();
//        booksItems.add("Select Item");
//        booksItems.add("Story Books");
//        booksItems.add("Textbooks");
//        booksItems.add("Reference Books");
//        booksItems.add("Coloring Books");
//        booksItems.add("Notebooks");
//        booksItems.add("Pens/Pencils");
//        booksItems.add("Art Supplies");
//        booksItems.add("School Bags");
//        booksItems.add("Calculators");
//        booksItems.add("Geometry Sets");
//        categoryItemsMap.put("Books & Stationery", booksItems);
//
//        // Other category
//        List<String> otherItems = new ArrayList<>();
//        otherItems.add("Select Item");
//        otherItems.add("Other (Please specify)");
//        categoryItemsMap.put("Other", otherItems);
//    }
//
//    private void updateItemSpinner(String category) {
//        List<String> items = categoryItemsMap.get(category);
//        if (items != null) {
//            ArrayAdapter<String> itemAdapter = new ArrayAdapter<>(this,
//                    android.R.layout.simple_spinner_dropdown_item, items);
//            spinnerItem.setAdapter(itemAdapter);
//        }
//    }
//
//    private void fetchCities() {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<CityResponse> call = apiService.getAllCities();
//
//        call.enqueue(new Callback<CityResponse>() {
//            @Override
//            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    citiesList = response.body().getCities();
//                    if (citiesList != null && !citiesList.isEmpty()) {
//                        citiesList.add(0, "Select Location");
//                        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(MaterialDonationActivity.this,
//                                android.R.layout.simple_spinner_dropdown_item, citiesList);
//                        spinnerLocation.setAdapter(locationAdapter);
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<CityResponse> call, Throwable t) {
//                Toast.makeText(MaterialDonationActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void fetchOrphanages(String city) {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<OrphanageResponse> call = apiService.getOrphanages(city);
//
//        call.enqueue(new Callback<OrphanageResponse>() {
//            @Override
//            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    OrphanageResponse orphanageResponse = response.body();
//                    if ("success".equals(orphanageResponse.getStatus())) {
//                        orphanageList = orphanageResponse.getOrphanages();
//
//                        List<String> orphanageNames = new ArrayList<>();
//                        orphanageNames.add("Select Orphanage");
//
//                        orphanageIdMap.clear();
//
//                        for (Orphanage orphanage : orphanageList) {
//                            orphanageNames.add(orphanage.getName());
//                            orphanageIdMap.put(orphanage.getName(), orphanage.getId());
//                        }
//
//                        ArrayAdapter<String> orphanageAdapter = new ArrayAdapter<>(MaterialDonationActivity.this,
//                                android.R.layout.simple_spinner_dropdown_item, orphanageNames);
//                        spinnerOrphanage.setAdapter(orphanageAdapter);
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
//                Toast.makeText(MaterialDonationActivity.this, "Failed to fetch orphanages", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void setupListeners() {
//        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
//        ivBack.setOnClickListener(v -> finish());
//    }
//
//    private void validateAndSubmitDonation() {
//        String cause = spinnerCause.getSelectedItem().toString();
//        String category = spinnerCategory.getSelectedItem().toString();
//        String item = spinnerItem.getSelectedItem().toString();
//        String unit = spinnerUnit.getSelectedItem().toString();
//        String location = spinnerLocation.getSelectedItem().toString();
//        String orphanageName = spinnerOrphanage.getSelectedItem().toString();
//        String quantityStr = editQuantity.getText().toString().trim();
//        String name = editName.getText().toString().trim();
//        String phone = editPhone.getText().toString().trim();
//
//        // Strict validation
//        if (cause.equals("Select Cause")) {
//            Toast.makeText(this, "Please select a cause", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (category.equals("Select Category")) {
//            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (item.equals("Select Item")) {
//            Toast.makeText(this, "Please select an item", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (item.equals("Other (Please specify)")) {
//            String otherItem = editOtherItem.getText().toString().trim();
//            if (otherItem.isEmpty()) {
//                editOtherItem.setError("Please specify the item");
//                editOtherItem.requestFocus();
//                return;
//            }
//            item = otherItem;
//        }
//        if (unit.equals("Select Unit")) {
//            Toast.makeText(this, "Please select a unit", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (location.equals("Select Location")) {
//            Toast.makeText(this, "Please select a location", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (orphanageName.equals("Select Orphanage")) {
//            Toast.makeText(this, "Please select an orphanage", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        if (quantityStr.isEmpty()) {
//            editQuantity.setError("Please enter quantity");
//            editQuantity.requestFocus();
//            return;
//        }
//        if (name.isEmpty()) {
//            editName.setError("Please enter your name");
//            editName.requestFocus();
//            return;
//        }
//        if (phone.isEmpty()) {
//            editPhone.setError("Please enter phone number");
//            editPhone.requestFocus();
//            return;
//        }
//
//        // Strict name validation
//        if (!name.matches("^[a-zA-Z\\s.'-]{2,50}$")) {
//            editName.setError("Please enter a valid name (only letters, spaces, . ' -)");
//            editName.requestFocus();
//            return;
//        }
//
//        // Strict phone validation
//        if (!phone.matches("^[6-9]\\d{9}$")) {
//            editPhone.setError("Please enter a valid 10-digit Indian mobile number");
//            editPhone.requestFocus();
//            return;
//        }
//
//        // Quantity validation
//        try {
//            int quantity = Integer.parseInt(quantityStr);
//            if (quantity <= 0) {
//                editQuantity.setError("Quantity must be greater than 0");
//                editQuantity.requestFocus();
//                return;
//            }
//            if (quantity > 1000) {
//                editQuantity.setError("Maximum 1000 allowed per donation");
//                editQuantity.requestFocus();
//                return;
//            }
//
//            // Combine item description
//            String itemDescription = category + " - " + item + " (" + quantity + " " + unit + ")";
//
//            submitDonationToServer(cause, itemDescription, quantity, name, phone, orphanageName, location);
//        } catch (NumberFormatException e) {
//            editQuantity.setError("Please enter a valid number");
//            editQuantity.requestFocus();
//        }
//    }
//    private void submitDonationToServer(String cause, String itemDescription, int quantity,
//                                        String name, String phone, String orphanageName,
//                                        String location) {
//        progressDialog.show();
//        btnSubmit.setEnabled(false);
//
//        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
//        int userId = prefs.getInt("user_id", 0);
//
//        // Get orphanage ID
//        Integer orphanageId = orphanageIdMap.get(orphanageName);
//
//        MaterialDonationRequest request = new MaterialDonationRequest(
//                cause, itemDescription, quantity, name, phone, orphanageName, location, userId, orphanageId
//        );
//        Call<DonationResponse> call = apiService.sendMaterialDonation(request);
//        call.enqueue(new Callback<DonationResponse>() {
//            @Override
//            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
//                progressDialog.dismiss();
//                btnSubmit.setEnabled(true);
//
//                if (response.isSuccessful() && response.body() != null) {
//                    DonationResponse donationResponse = response.body();
//                    if (donationResponse.isSuccess()) {
//                        showSuccess(donationResponse.getMessage());
//                    } else {
//                        showError(donationResponse.getMessage());
//                    }
//                } else {
//                    showError("Server error occurred");
//                }
//            }
//
//            @Override
//            public void onFailure(Call<DonationResponse> call, Throwable t) {
//                progressDialog.dismiss();
//                btnSubmit.setEnabled(true);
//                showError("Network error: " + t.getMessage());
//            }
//        });
//    }
//
//    private void showSuccess(String message) {
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//        clearForm();
//    }
//
//    private void showError(String message) {
//        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
//    }
//
//    private void clearForm() {
//        spinnerCause.setSelection(0);
//        spinnerCategory.setSelection(0);
//        spinnerItem.setSelection(0);
//        spinnerUnit.setSelection(0);
//        spinnerLocation.setSelection(0);
//        spinnerOrphanage.setSelection(0);
//        editQuantity.setText("");
//        editName.setText("");
//        editPhone.setText("");
//        editOtherItem.setText("");
//        layoutOtherItem.setVisibility(View.GONE);
//    }
//
//}
package com.SIMATS.hope;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MaterialDonationActivity extends AppCompatActivity {
    private Spinner spinnerCause, spinnerCategory, spinnerItem, spinnerUnit, spinnerLocation, spinnerOrphanage;
    private EditText editQuantity, editName, editPhone, editOtherItem;
    private Button btnSubmit, btnAddItem;
    private ImageView ivBack;
    private ApiService apiService;
    private ProgressDialog progressDialog;
    private View layoutOtherItem;
    private RecyclerView recyclerViewItems;
    private TextView tvEmptyItems;

    private List<String> causesList = new ArrayList<>();
    private List<String> categoriesList = new ArrayList<>();
    private Map<String, List<String>> categoryItemsMap = new HashMap<>();
    private Map<String, List<String>> itemUnitsMap = new HashMap<>();
    private List<String> citiesList = new ArrayList<>();
    private List<Orphanage> orphanageList = new ArrayList<>();
    private Map<String, Integer> orphanageIdMap = new HashMap<>();

    private DonationItemAdapter donationItemAdapter;
    private List<DonationItem> donationItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_material_donation);

        initializeViews();
        setupData();
        setupListeners();
        setupRealTimeValidation();
        setupRecyclerView();
    }

    private void initializeViews() {
        spinnerCause = findViewById(R.id.spinnerCause);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerItem = findViewById(R.id.spinnerItem);
        spinnerUnit = findViewById(R.id.spinnerUnit);
        spinnerLocation = findViewById(R.id.spinnerLocation);
        spinnerOrphanage = findViewById(R.id.spinnerOrphanage);
        editQuantity = findViewById(R.id.editTextQuantity);
        editName = findViewById(R.id.editTextName);
        editPhone = findViewById(R.id.editTextPhone);
        editOtherItem = findViewById(R.id.editTextOtherItem);
        btnSubmit = findViewById(R.id.btnSubmitMaterial);
        btnAddItem = findViewById(R.id.btnAddItem);
        ivBack = findViewById(R.id.ivBack);
        layoutOtherItem = findViewById(R.id.layoutOtherItem);
        recyclerViewItems = findViewById(R.id.recyclerViewItems);
        tvEmptyItems = findViewById(R.id.tvEmptyItems);

        apiService = ApiClient.getClient().create(ApiService.class);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Submitting donation...");
        progressDialog.setCancelable(false);
    }

    private void setupRecyclerView() {
        donationItemAdapter = new DonationItemAdapter(donationItems, new DonationItemAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(int position) {
                donationItems.remove(position);
                donationItemAdapter.notifyItemRemoved(position);
                checkEmptyState();
            }
        });

        recyclerViewItems.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewItems.setAdapter(donationItemAdapter);
        checkEmptyState();
    }

    private void checkEmptyState() {
        if (donationItems.isEmpty()) {
            recyclerViewItems.setVisibility(View.GONE);
            tvEmptyItems.setVisibility(View.VISIBLE);
        } else {
            recyclerViewItems.setVisibility(View.VISIBLE);
            tvEmptyItems.setVisibility(View.GONE);
        }
    }

    private void setupData() {
        // Setup causes
        causesList.add("Select Cause");
        causesList.add("Donation for Children");
        causesList.add("Donation for Disabled Persons");
        causesList.add("Donation for Education");
        causesList.add("Donation for Food & Nutrition");
        causesList.add("Donation for Healthcare");
        causesList.add("Donation for Shelter");
        causesList.add("Donation for Clothing");
        causesList.add("General Donation");

        ArrayAdapter<String> causeAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, causesList);
        spinnerCause.setAdapter(causeAdapter);

        // Setup categories
        categoriesList.add("Select Category");
        categoriesList.add("Clothing");
        categoriesList.add("Food Items");
        categoriesList.add("Kitchen Items");
        categoriesList.add("Educational Materials");
        categoriesList.add("Medical Supplies");
        categoriesList.add("Toys & Games");
        categoriesList.add("Furniture");
        categoriesList.add("Bedding & Linens");
        categoriesList.add("Electronics");
        categoriesList.add("Hygiene Products");
        categoriesList.add("Sports Equipment");
        categoriesList.add("Books & Stationery");
        categoriesList.add("Other");

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, categoriesList);
        spinnerCategory.setAdapter(categoryAdapter);

        // Setup category items mapping
        setupCategoryItems();
        setupItemUnits();

        // Setup default units
        List<String> defaultUnits = new ArrayList<>();
        defaultUnits.add("Select Unit");
        defaultUnits.add("Pieces");
        defaultUnits.add("Kg");
        defaultUnits.add("Liters");
        defaultUnits.add("Boxes");
        defaultUnits.add("Pairs");
        defaultUnits.add("Sets");
        defaultUnits.add("Bags");
        defaultUnits.add("Packets");
        defaultUnits.add("Bottles");
        defaultUnits.add("Cartons");
        defaultUnits.add("Dozen");
        defaultUnits.add("Meters");
        defaultUnits.add("Rolls");

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, defaultUnits);
        spinnerUnit.setAdapter(unitAdapter);

        // Fetch cities
        fetchCities();

        // Setup listeners
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = parent.getItemAtPosition(position).toString();
                if (!selectedCategory.equals("Select Category")) {
                    updateItemSpinner(selectedCategory);
                }
                // Hide other item field when category changes
                layoutOtherItem.setVisibility(View.GONE);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        spinnerItem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
                if (selectedItem.equals("Other (Please specify)")) {
                    layoutOtherItem.setVisibility(View.VISIBLE);
                } else {
                    layoutOtherItem.setVisibility(View.GONE);
                    // Update units based on selected item
                    updateUnitSpinner(selectedItem);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        spinnerLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCity = parent.getItemAtPosition(position).toString();
                if (!selectedCity.equals("Select Location") && !selectedCity.isEmpty()) {
                    fetchOrphanages(selectedCity);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setupCategoryItems() {
        // Clothing items
        List<String> clothingItems = new ArrayList<>();
        clothingItems.add("Select Item");
        clothingItems.add("Shirts/T-Shirts");
        clothingItems.add("Pants/Trousers");
        clothingItems.add("Dresses/Skirts");
        clothingItems.add("Sweaters/Hoodies");
        clothingItems.add("Jackets/Coats");
        clothingItems.add("Shoes (New)");
        clothingItems.add("Socks");
        clothingItems.add("Underwear (New)");
        clothingItems.add("Winter Wear");
        clothingItems.add("Traditional Clothes");
        clothingItems.add("Baby Clothes");
        clothingItems.add("School Uniforms");
        categoryItemsMap.put("Clothing", clothingItems);

        // Food items
        List<String> foodItems = new ArrayList<>();
        foodItems.add("Select Item");
        foodItems.add("Rice");
        foodItems.add("Wheat Flour");
        foodItems.add("Lentils/Dal");
        foodItems.add("Cooking Oil");
        foodItems.add("Sugar");
        foodItems.add("Salt");
        foodItems.add("Tea Leaves");
        foodItems.add("Coffee Powder");
        foodItems.add("Biscuits");
        foodItems.add("Dry Fruits");
        foodItems.add("Spices");
        foodItems.add("Canned Food");
        foodItems.add("Baby Food");
        foodItems.add("Milk Powder");
        foodItems.add("Honey");
        foodItems.add("Chocolate");
        categoryItemsMap.put("Food Items", foodItems);
        List<String> kitchenItems = new ArrayList<>();
        kitchenItems.add("Select Item");
        kitchenItems.add("Plates/Bowls");
        kitchenItems.add("Cups/Glasses");
        kitchenItems.add("Spoons/Forks");
        kitchenItems.add("Cooking Pots");
        kitchenItems.add("Frying Pans");
        kitchenItems.add("Knives");
        kitchenItems.add("Food Containers");
        kitchenItems.add("Water Bottles");
        kitchenItems.add("Thermos Flasks");
        kitchenItems.add("Cutting Boards");
        kitchenItems.add("Mixer Grinder");
        kitchenItems.add("Gas Stove");
        kitchenItems.add("Pressure Cooker");
        categoryItemsMap.put("Kitchen Items", kitchenItems);

        // Educational Materials
        List<String> educationalItems = new ArrayList<>();
        educationalItems.add("Select Item");
        educationalItems.add("School Books");
        educationalItems.add("Notebooks");
        educationalItems.add("Pens/Pencils");
        educationalItems.add("Erasers/Sharpeners");
        educationalItems.add("School Bags");
        educationalItems.add("Geometry Sets");
        educationalItems.add("Art Supplies");
        educationalItems.add("Story Books");
        educationalItems.add("Dictionaries");
        educationalItems.add("Calculators");
        educationalItems.add("Whiteboards");
        educationalItems.add("Markers");
        educationalItems.add("Educational Toys");
        categoryItemsMap.put("Educational Materials", educationalItems);

        // Medical Supplies
        List<String> medicalItems = new ArrayList<>();
        medicalItems.add("Select Item");
        medicalItems.add("First Aid Kits");
        medicalItems.add("Bandages");
        medicalItems.add("Antiseptic Cream");
        medicalItems.add("Pain Relievers");
        medicalItems.add("Thermometers");
        medicalItems.add("Vitamins");
        medicalItems.add("Baby Care Products");
        medicalItems.add("Sanitary Napkins");
        medicalItems.add("Disinfectants");
        medicalItems.add("Hand Sanitizer");
        medicalItems.add("Masks");
        medicalItems.add("Gloves");
        medicalItems.add("Walking Aids");
        categoryItemsMap.put("Medical Supplies", medicalItems);

        // Toys & Games
        List<String> toysItems = new ArrayList<>();
        toysItems.add("Select Item");
        toysItems.add("Soft Toys");
        toysItems.add("Building Blocks");
        toysItems.add("Board Games");
        toysItems.add("Puzzles");
        toysItems.add("Sports Equipment");
        toysItems.add("Art & Craft Kits");
        toysItems.add("Educational Toys");
        toysItems.add("Outdoor Games");
        toysItems.add("Dolls");
        toysItems.add("Toy Vehicles");
        toysItems.add("Musical Instruments");
        toysItems.add("Books");
        categoryItemsMap.put("Toys & Games", toysItems);

        // Furniture
        List<String> furnitureItems = new ArrayList<>();
        furnitureItems.add("Select Item");
        furnitureItems.add("Beds");
        furnitureItems.add("Mattresses");
        furnitureItems.add("Study Tables");
        furnitureItems.add("Chairs");
        furnitureItems.add("Cupboards");
        furnitureItems.add("Shelves");
        furnitureItems.add("Desks");
        furnitureItems.add("Bean Bags");
        furnitureItems.add("Storage Boxes");
        furnitureItems.add("Baby Cribs");
        furnitureItems.add("Sofas");
        categoryItemsMap.put("Furniture", furnitureItems);

        // Bedding & Linens
        List<String> beddingItems = new ArrayList<>();
        beddingItems.add("Select Item");
        beddingItems.add("Blankets");
        beddingItems.add("Bed Sheets");
        beddingItems.add("Pillows");
        beddingItems.add("Towels");
        beddingItems.add("Curtains");
        beddingItems.add("Mosquito Nets");
        beddingItems.add("Sleeping Bags");
        beddingItems.add("Quilts");
        beddingItems.add("Mattress Covers");
        categoryItemsMap.put("Bedding & Linens", beddingItems);

        // Electronics
        List<String> electronicsItems = new ArrayList<>();
        electronicsItems.add("Select Item");
        electronicsItems.add("Computers/Laptops");
        electronicsItems.add("Tablets");
        electronicsItems.add("Mobile Phones");
        electronicsItems.add("Televisions");
        electronicsItems.add("Fans");
        electronicsItems.add("Lights/Lamps");
        electronicsItems.add("Radios");
        electronicsItems.add("Chargers");
        electronicsItems.add("Power Banks");
        electronicsItems.add("Headphones");
        categoryItemsMap.put("Electronics", electronicsItems);

        // Hygiene Products
        List<String> hygieneItems = new ArrayList<>();
        hygieneItems.add("Select Item");
        hygieneItems.add("Soap");
        hygieneItems.add("Shampoo");
        hygieneItems.add("Toothpaste");
        hygieneItems.add("Toothbrushes");
        hygieneItems.add("Toilet Paper");
        hygieneItems.add("Diapers");
        hygieneItems.add("Baby Wipes");
        hygieneItems.add("Deodorant");
        hygieneItems.add("Combs/Brushes");
        hygieneItems.add("Laundry Detergent");
        categoryItemsMap.put("Hygiene Products", hygieneItems);

        // Sports Equipment
        List<String> sportsItems = new ArrayList<>();
        sportsItems.add("Select Item");
        sportsItems.add("Cricket Sets");
        sportsItems.add("Football");
        sportsItems.add("Basketball");
        sportsItems.add("Volleyball");
        sportsItems.add("Badminton Sets");
        sportsItems.add("Skating Equipment");
        sportsItems.add("Yoga Mats");
        sportsItems.add("Exercise Equipment");
        sportsItems.add("Swimming Gear");
        categoryItemsMap.put("Sports Equipment", sportsItems);

        // Books & Stationery
        List<String> booksItems = new ArrayList<>();
        booksItems.add("Select Item");
        booksItems.add("Story Books");
        booksItems.add("Textbooks");
        booksItems.add("Reference Books");
        booksItems.add("Coloring Books");
        booksItems.add("Notebooks");
        booksItems.add("Pens/Pencils");
        booksItems.add("Art Supplies");
        booksItems.add("School Bags");
        booksItems.add("Calculators");
        booksItems.add("Geometry Sets");
        categoryItemsMap.put("Books & Stationery", booksItems);

        // Other category
        List<String> otherItems = new ArrayList<>();
        otherItems.add("Select Item");
        otherItems.add("Other (Please specify)");
        categoryItemsMap.put("Other", otherItems);
    }

    private void setupItemUnits() {
        // Food Items Units
        itemUnitsMap.put("Rice", Arrays.asList("Kg", "Bags", "Packets"));
        itemUnitsMap.put("Wheat Flour", Arrays.asList("Kg", "Bags", "Packets"));
        itemUnitsMap.put("Lentils/Dal", Arrays.asList("Kg", "Packets"));
        itemUnitsMap.put("Cooking Oil", Arrays.asList("Liters", "Bottles", "Cans"));
        itemUnitsMap.put("Sugar", Arrays.asList("Kg", "Packets"));
        itemUnitsMap.put("Salt", Arrays.asList("Kg", "Packets"));
        itemUnitsMap.put("Tea Leaves", Arrays.asList("Kg", "Packets", "Boxes"));
        itemUnitsMap.put("Coffee Powder", Arrays.asList("Kg", "Packets", "Jars"));
        itemUnitsMap.put("Biscuits", Arrays.asList("Packets", "Boxes", "Pieces"));
        itemUnitsMap.put("Dry Fruits", Arrays.asList("Kg", "Packets"));
        itemUnitsMap.put("Spices", Arrays.asList("Kg", "Packets", "Pieces"));
        itemUnitsMap.put("Canned Food", Arrays.asList("Cans", "Pieces"));
        itemUnitsMap.put("Baby Food", Arrays.asList("Jars", "Packets", "Boxes"));
        itemUnitsMap.put("Milk Powder", Arrays.asList("Kg", "Packets", "Tins"));
        itemUnitsMap.put("Honey", Arrays.asList("Kg", "Bottles", "Jars"));
        itemUnitsMap.put("Chocolate", Arrays.asList("Pieces", "Bars", "Packets"));

        // Clothing Units
        itemUnitsMap.put("Shirts/T-Shirts", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Pants/Trousers", Arrays.asList("Pieces", "Pairs"));
        itemUnitsMap.put("Dresses/Skirts", Arrays.asList("Pieces"));
        itemUnitsMap.put("Sweaters/Hoodies", Arrays.asList("Pieces"));
        itemUnitsMap.put("Jackets/Coats", Arrays.asList("Pieces"));
        itemUnitsMap.put("Shoes (New)", Arrays.asList("Pairs"));
        itemUnitsMap.put("Socks", Arrays.asList("Pairs", "Pieces"));
        itemUnitsMap.put("Underwear (New)", Arrays.asList("Pieces", "Packs"));
        itemUnitsMap.put("Winter Wear", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Traditional Clothes", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Baby Clothes", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("School Uniforms", Arrays.asList("Pieces", "Sets"));

        // Kitchen Items Units
        itemUnitsMap.put("Plates/Bowls", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Cups/Glasses", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Spoons/Forks", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Cooking Pots", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Frying Pans", Arrays.asList("Pieces"));
        itemUnitsMap.put("Knives", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Food Containers", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Water Bottles", Arrays.asList("Pieces", "Liters"));
        itemUnitsMap.put("Thermos Flasks", Arrays.asList("Pieces", "Liters"));
        itemUnitsMap.put("Cutting Boards", Arrays.asList("Pieces"));
        itemUnitsMap.put("Mixer Grinder", Arrays.asList("Pieces"));
        itemUnitsMap.put("Gas Stove", Arrays.asList("Pieces"));
        itemUnitsMap.put("Pressure Cooker", Arrays.asList("Pieces"));

        // Educational Materials Units
        itemUnitsMap.put("School Books", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Notebooks", Arrays.asList("Pieces", "Packs"));
        itemUnitsMap.put("Pens/Pencils", Arrays.asList("Pieces", "Boxes", "Sets"));
        itemUnitsMap.put("Erasers/Sharpeners", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("School Bags", Arrays.asList("Pieces"));
        itemUnitsMap.put("Geometry Sets", Arrays.asList("Sets", "Pieces"));
        itemUnitsMap.put("Art Supplies", Arrays.asList("Sets", "Pieces", "Boxes"));
        itemUnitsMap.put("Story Books", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Dictionaries", Arrays.asList("Pieces"));
        itemUnitsMap.put("Calculators", Arrays.asList("Pieces"));
        itemUnitsMap.put("Whiteboards", Arrays.asList("Pieces"));
        itemUnitsMap.put("Markers", Arrays.asList("Pieces", "Sets", "Boxes"));
        itemUnitsMap.put("Educational Toys", Arrays.asList("Pieces", "Sets"));

        // Medical Supplies Units
        itemUnitsMap.put("First Aid Kits", Arrays.asList("Kits", "Boxes"));
        itemUnitsMap.put("Bandages", Arrays.asList("Pieces", "Rolls", "Boxes"));
        itemUnitsMap.put("Antiseptic Cream", Arrays.asList("Tubes", "Bottles", "Pieces"));
        itemUnitsMap.put("Pain Relievers", Arrays.asList("Strips", "Bottles", "Boxes"));
        itemUnitsMap.put("Thermometers", Arrays.asList("Pieces"));
        itemUnitsMap.put("Vitamins", Arrays.asList("Bottles", "Strips", "Boxes"));
        itemUnitsMap.put("Baby Care Products", Arrays.asList("Bottles", "Packs", "Pieces"));
        itemUnitsMap.put("Sanitary Napkins", Arrays.asList("Packs", "Pieces"));
        itemUnitsMap.put("Disinfectants", Arrays.asList("Bottles", "Liters", "Sprays"));
        itemUnitsMap.put("Hand Sanitizer", Arrays.asList("Bottles", "Pieces"));
        itemUnitsMap.put("Masks", Arrays.asList("Pieces", "Packs", "Boxes"));
        itemUnitsMap.put("Gloves", Arrays.asList("Pairs", "Boxes", "Packs"));
        itemUnitsMap.put("Walking Aids", Arrays.asList("Pieces"));

        // Toys & Games Units
        itemUnitsMap.put("Soft Toys", Arrays.asList("Pieces"));
        itemUnitsMap.put("Building Blocks", Arrays.asList("Sets", "Pieces", "Boxes"));
        itemUnitsMap.put("Board Games", Arrays.asList("Sets", "Boxes"));
        itemUnitsMap.put("Puzzles", Arrays.asList("Sets", "Pieces"));
        itemUnitsMap.put("Sports Equipment", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Art & Craft Kits", Arrays.asList("Kits", "Boxes", "Sets"));
        itemUnitsMap.put("Educational Toys", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Outdoor Games", Arrays.asList("Sets", "Pieces"));
        itemUnitsMap.put("Dolls", Arrays.asList("Pieces"));
        itemUnitsMap.put("Toy Vehicles", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Musical Instruments", Arrays.asList("Pieces"));
        itemUnitsMap.put("Books", Arrays.asList("Pieces"));

        // Furniture Units
        itemUnitsMap.put("Beds", Arrays.asList("Pieces"));
        itemUnitsMap.put("Mattresses", Arrays.asList("Pieces"));
        itemUnitsMap.put("Study Tables", Arrays.asList("Pieces"));
        itemUnitsMap.put("Chairs", Arrays.asList("Pieces"));
        itemUnitsMap.put("Cupboards", Arrays.asList("Pieces"));
        itemUnitsMap.put("Shelves", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Desks", Arrays.asList("Pieces"));
        itemUnitsMap.put("Bean Bags", Arrays.asList("Pieces"));
        itemUnitsMap.put("Storage Boxes", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Baby Cribs", Arrays.asList("Pieces"));
        itemUnitsMap.put("Sofas", Arrays.asList("Pieces", "Sets"));

        // Bedding & Linens Units
        itemUnitsMap.put("Blankets", Arrays.asList("Pieces"));
        itemUnitsMap.put("Bed Sheets", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Pillows", Arrays.asList("Pieces"));
        itemUnitsMap.put("Towels", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Curtains", Arrays.asList("Pieces", "Sets", "Meters"));
        itemUnitsMap.put("Mosquito Nets", Arrays.asList("Pieces"));
        itemUnitsMap.put("Sleeping Bags", Arrays.asList("Pieces"));
        itemUnitsMap.put("Quilts", Arrays.asList("Pieces"));
        itemUnitsMap.put("Mattress Covers", Arrays.asList("Pieces"));

        // Electronics Units
        itemUnitsMap.put("Computers/Laptops", Arrays.asList("Pieces"));
        itemUnitsMap.put("Tablets", Arrays.asList("Pieces"));
        itemUnitsMap.put("Mobile Phones", Arrays.asList("Pieces"));
        itemUnitsMap.put("Televisions", Arrays.asList("Pieces"));
        itemUnitsMap.put("Fans", Arrays.asList("Pieces"));
        itemUnitsMap.put("Lights/Lamps", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Radios", Arrays.asList("Pieces"));
        itemUnitsMap.put("Chargers", Arrays.asList("Pieces"));
        itemUnitsMap.put("Power Banks", Arrays.asList("Pieces"));
        itemUnitsMap.put("Headphones", Arrays.asList("Pieces", "Pairs"));

        // Hygiene Products Units
        itemUnitsMap.put("Soap", Arrays.asList("Pieces", "Bars", "Boxes"));
        itemUnitsMap.put("Shampoo", Arrays.asList("Bottles", "Packs", "Liters"));
        itemUnitsMap.put("Toothpaste", Arrays.asList("Tubes", "Packs"));
        itemUnitsMap.put("Toothbrushes", Arrays.asList("Pieces", "Packs"));
        itemUnitsMap.put("Toilet Paper", Arrays.asList("Rolls", "Packs"));
        itemUnitsMap.put("Diapers", Arrays.asList("Packs", "Pieces"));
        itemUnitsMap.put("Baby Wipes", Arrays.asList("Packs", "Pieces"));
        itemUnitsMap.put("Deodorant", Arrays.asList("Pieces", "Sprays", "Sticks"));
        itemUnitsMap.put("Combs/Brushes", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Laundry Detergent", Arrays.asList("Kg", "Liters", "Packs"));

        // Sports Equipment Units
        itemUnitsMap.put("Cricket Sets", Arrays.asList("Sets"));
        itemUnitsMap.put("Football", Arrays.asList("Pieces"));
        itemUnitsMap.put("Basketball", Arrays.asList("Pieces"));
        itemUnitsMap.put("Volleyball", Arrays.asList("Pieces"));
        itemUnitsMap.put("Badminton Sets", Arrays.asList("Sets"));
        itemUnitsMap.put("Skating Equipment", Arrays.asList("Sets", "Pairs"));
        itemUnitsMap.put("Yoga Mats", Arrays.asList("Pieces"));
        itemUnitsMap.put("Exercise Equipment", Arrays.asList("Pieces", "Sets"));
        itemUnitsMap.put("Swimming Gear", Arrays.asList("Sets", "Pieces"));

        // Books & Stationery Units
        itemUnitsMap.put("Story Books", Arrays.asList("Pieces"));
        itemUnitsMap.put("Textbooks", Arrays.asList("Pieces"));
        itemUnitsMap.put("Reference Books", Arrays.asList("Pieces"));
        itemUnitsMap.put("Coloring Books", Arrays.asList("Pieces"));
        itemUnitsMap.put("Notebooks", Arrays.asList("Pieces", "Packs"));
        itemUnitsMap.put("Pens/Pencils", Arrays.asList("Pieces", "Boxes", "Sets"));
        itemUnitsMap.put("Art Supplies", Arrays.asList("Sets", "Boxes", "Pieces"));
        itemUnitsMap.put("School Bags", Arrays.asList("Pieces"));
        itemUnitsMap.put("Calculators", Arrays.asList("Pieces"));
        itemUnitsMap.put("Geometry Sets", Arrays.asList("Sets", "Pieces"));

        // Default units for other items
        itemUnitsMap.put("Default", Arrays.asList("Pieces", "Kg", "Liters", "Boxes", "Pairs", "Sets", "Bags", "Packets", "Bottles", "Cartons", "Dozen", "Meters", "Rolls"));
    }

    private void updateItemSpinner(String category) {
        List<String> items = categoryItemsMap.get(category);
        if (items != null) {
            ArrayAdapter<String> itemAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_dropdown_item, items);
            spinnerItem.setAdapter(itemAdapter);
        }
    }

    private void updateUnitSpinner(String item) {
        List<String> units = itemUnitsMap.get(item);
        if (units == null) {
            units = itemUnitsMap.get("Default");
        }

        if (units != null) {
            List<String> unitList = new ArrayList<>(units);
            unitList.add(0, "Select Unit");
            ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_dropdown_item, unitList);
            spinnerUnit.setAdapter(unitAdapter);
        }
    }

    private void setupRealTimeValidation() {
        // Name validation - only letters, spaces, and common name characters
        editName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String name = s.toString();
                if (!name.isEmpty()) {
                    if (!name.matches("^[a-zA-Z\\s.'-]{2,50}$")) {
                        editName.setError("Only letters, spaces, . ' - allowed (2-50 characters)");
                    } else {
                        editName.setError(null);
                    }
                } else {
                    editName.setError(null);
                }
            }
        });

        // Phone validation - Indian mobile numbers only
        editPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String phone = s.toString();
                if (!phone.isEmpty()) {
                    if (!phone.matches("^[6-9]\\d{9}$")) {
                        editPhone.setError("Enter valid 10-digit Indian mobile number");
                    } else {
                        editPhone.setError(null);
                    }
                } else {
                    editPhone.setError(null);
                }
            }
        });

        // Quantity validation - only numbers with limits
        editQuantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String quantity = s.toString();
                if (!quantity.isEmpty()) {
                    if (!quantity.matches("^\\d+$")) {
                        editQuantity.setError("Enter numbers only");
                    } else {
                        try {
                            int qty = Integer.parseInt(quantity);
                            if (qty <= 0) {
                                editQuantity.setError("Quantity must be greater than 0");
                            } else if (qty > 1000) {
                                editQuantity.setError("Maximum 1000 allowed");
                            } else {
                                editQuantity.setError(null);
                            }
                        } catch (NumberFormatException e) {
                            editQuantity.setError("Invalid number");
                        }
                    }
                } else {
                    editQuantity.setError(null);
                }
            }
        });
    }

    private void fetchCities() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<CityResponse> call = apiService.getAllCities();

        call.enqueue(new Callback<CityResponse>() {
            @Override
            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    citiesList = response.body().getCities();
                    if (citiesList != null && !citiesList.isEmpty()) {
                        citiesList.add(0, "Select Location");
                        ArrayAdapter<String> locationAdapter = new ArrayAdapter<>(MaterialDonationActivity.this,
                                android.R.layout.simple_spinner_dropdown_item, citiesList);
                        spinnerLocation.setAdapter(locationAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<CityResponse> call, Throwable t) {
                Toast.makeText(MaterialDonationActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void fetchOrphanages(String city) {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<OrphanageResponse> call = apiService.getOrphanages(city);

        call.enqueue(new Callback<OrphanageResponse>() {
            @Override
            public void onResponse(Call<OrphanageResponse> call, Response<OrphanageResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    OrphanageResponse orphanageResponse = response.body();
                    if ("success".equals(orphanageResponse.getStatus())) {
                        orphanageList = orphanageResponse.getOrphanages();

                        List<String> orphanageNames = new ArrayList<>();
                        orphanageNames.add("Select Orphanage");

                        orphanageIdMap.clear();

                        for (Orphanage orphanage : orphanageList) {
                            orphanageNames.add(orphanage.getName());
                            orphanageIdMap.put(orphanage.getName(), orphanage.getId());
                        }

                        ArrayAdapter<String> orphanageAdapter = new ArrayAdapter<>(MaterialDonationActivity.this,
                                android.R.layout.simple_spinner_dropdown_item, orphanageNames);
                        spinnerOrphanage.setAdapter(orphanageAdapter);
                    }
                }
            }

            @Override
            public void onFailure(Call<OrphanageResponse> call, Throwable t) {
                Toast.makeText(MaterialDonationActivity.this, "Failed to fetch orphanages", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupListeners() {
        btnSubmit.setOnClickListener(v -> validateAndSubmitDonation());
        ivBack.setOnClickListener(v -> finish());
        btnAddItem.setOnClickListener(v -> addItemToDonation());
    }

    private void addItemToDonation() {
        String category = spinnerCategory.getSelectedItem().toString();
        String item = spinnerItem.getSelectedItem().toString();
        String quantityStr = editQuantity.getText().toString().trim();
        String unit = spinnerUnit.getSelectedItem().toString();

        // Validation
        if (category.equals("Select Category")) {
            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show();
            return;
        }

        if (item.equals("Select Item")) {
            Toast.makeText(this, "Please select an item", Toast.LENGTH_SHORT).show();
            return;
        }

        if (item.equals("Other (Please specify)")) {
            String otherItem = editOtherItem.getText().toString().trim();
            if (otherItem.isEmpty()) {
                editOtherItem.setError("Please specify the item");
                editOtherItem.requestFocus();
                return;
            }
            item = otherItem;
        }

        if (quantityStr.isEmpty()) {
            editQuantity.setError("Please enter quantity");
            editQuantity.requestFocus();
            return;
        }

        if (unit.equals("Select Unit")) {
            Toast.makeText(this, "Please select a unit", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            if (quantity <= 0) {
                editQuantity.setError("Quantity must be greater than 0");
                editQuantity.requestFocus();
                return;
            }

            // Create and add donation item
            DonationItem donationItem = new DonationItem(category, item, quantity, unit);
            donationItems.add(donationItem);
            donationItemAdapter.notifyItemInserted(donationItems.size() - 1);

            // Clear item selection and quantity
            spinnerItem.setSelection(0);
            editQuantity.setText("");
            spinnerUnit.setSelection(0);
            layoutOtherItem.setVisibility(View.GONE);

            checkEmptyState();

        } catch (NumberFormatException e) {
            editQuantity.setError("Please enter a valid number");
            editQuantity.requestFocus();
        }
    }

    private void validateAndSubmitDonation() {
        String cause = spinnerCause.getSelectedItem().toString();
        String location = spinnerLocation.getSelectedItem().toString();
        String orphanageName = spinnerOrphanage.getSelectedItem().toString();
        String name = editName.getText().toString().trim();
        String phone = editPhone.getText().toString().trim();

        // Strict validation
        if (cause.equals("Select Cause")) {
            Toast.makeText(this, "Please select a cause", Toast.LENGTH_SHORT).show();
            return;
        }
        if (location.equals("Select Location")) {
            Toast.makeText(this, "Please select a location", Toast.LENGTH_SHORT).show();
            return;
        }
        if (orphanageName.equals("Select Orphanage")) {
            Toast.makeText(this, "Please select an orphanage", Toast.LENGTH_SHORT).show();
            return;
        }
        if (donationItems.isEmpty()) {
            Toast.makeText(this, "Please add at least one donation item", Toast.LENGTH_SHORT).show();
            return;
        }
        if (name.isEmpty()) {
            editName.setError("Please enter your name");
            editName.requestFocus();
            return;
        }
        if (phone.isEmpty()) {
            editPhone.setError("Please enter phone number");
            editPhone.requestFocus();
            return;
        }

        // Strict name validation
        if (!name.matches("^[a-zA-Z\\s.'-]{2,50}$")) {
            editName.setError("Please enter a valid name (only letters, spaces, . ' -)");
            editName.requestFocus();
            return;
        }

        // Strict phone validation
        if (!phone.matches("^[6-9]\\d{9}$")) {
            editPhone.setError("Please enter a valid 10-digit Indian mobile number");
            editPhone.requestFocus();
            return;
        }

        submitDonationToServer(cause, name, phone, orphanageName, location);
    }

    private void submitDonationToServer(String cause, String name, String phone,
                                        String orphanageName, String location) {
        progressDialog.show();
        btnSubmit.setEnabled(false);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        int userId = prefs.getInt("user_id", 0);

        // Get orphanage ID
        Integer orphanageId = orphanageIdMap.get(orphanageName);

        // Create item description from all items
        StringBuilder itemDescriptionBuilder = new StringBuilder();
        int totalQuantity = 0;

        for (int i = 0; i < donationItems.size(); i++) {
            DonationItem item = donationItems.get(i);
            itemDescriptionBuilder.append(item.toString());
            totalQuantity += item.getQuantity();

            if (i < donationItems.size() - 1) {
                itemDescriptionBuilder.append("; ");
            }
        }

        String itemDescription = itemDescriptionBuilder.toString();

        // Use the existing constructor (single item description)
        MaterialDonationRequest request = new MaterialDonationRequest(
                cause, itemDescription, totalQuantity, name, phone, orphanageName, location, userId, orphanageId
        );

        Call<DonationResponse> call = apiService.sendMaterialDonation(request);
        call.enqueue(new Callback<DonationResponse>() {
            @Override
            public void onResponse(Call<DonationResponse> call, Response<DonationResponse> response) {
                progressDialog.dismiss();
                btnSubmit.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    DonationResponse donationResponse = response.body();
                    if (donationResponse.isSuccess()) {
                        showSuccess(donationResponse.getMessage());
                    } else {
                        showError(donationResponse.getMessage());
                    }
                } else {
                    showError("Server error occurred");
                }
            }

            @Override
            public void onFailure(Call<DonationResponse> call, Throwable t) {
                progressDialog.dismiss();
                btnSubmit.setEnabled(true);
                showError("Network error: " + t.getMessage());
            }
        });
    }

    private void showSuccess(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        clearForm();
    }

    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void clearForm() {
        spinnerCause.setSelection(0);
        spinnerCategory.setSelection(0);
        spinnerItem.setSelection(0);
        spinnerUnit.setSelection(0);
        spinnerLocation.setSelection(0);
        spinnerOrphanage.setSelection(0);
        editQuantity.setText("");
        editName.setText("");
        editPhone.setText("");
        editOtherItem.setText("");
        layoutOtherItem.setVisibility(View.GONE);

        // Clear the donation items list
        donationItems.clear();
        donationItemAdapter.notifyDataSetChanged();
        checkEmptyState();
    }
}