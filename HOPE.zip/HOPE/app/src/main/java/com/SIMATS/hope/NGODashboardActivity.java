package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class NGODashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ngo_dashboard);

        CardView cardReports = findViewById(R.id.cardReports);
        CardView cardDonations = findViewById(R.id.cardDonations);
        CardView cardVolunteers = findViewById(R.id.cardVolunteers);

        cardReports.setOnClickListener(v -> {
            startActivity(new Intent(NGODashboardActivity.this, AdminReportsActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        cardDonations.setOnClickListener(v -> {
            startActivity(new Intent(NGODashboardActivity.this, AdminDonationsActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        cardVolunteers.setOnClickListener(v -> {
            startActivity(new Intent(NGODashboardActivity.this, ManageVolunteersActivity.class));
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }
}