////////package com.SIMATS.hope;
////////
////////import android.os.Bundle;
////////import android.view.View;
////////import android.widget.ProgressBar;
////////import android.widget.TextView;
////////import android.widget.Toast;
////////import androidx.appcompat.app.AppCompatActivity;
////////import androidx.recyclerview.widget.LinearLayoutManager;
////////import androidx.recyclerview.widget.RecyclerView;
////////import java.util.ArrayList;
////////import retrofit2.Call;
////////import retrofit2.Callback;
////////import retrofit2.Response;
////////import retrofit2.Retrofit;
////////import retrofit2.converter.gson.GsonConverterFactory;
////////
////////public class DonationListActivity_volunteer extends AppCompatActivity {
////////
////////    private RecyclerView recyclerView;
////////    private DonationAdapter_Volunteer adapter;
////////    private ArrayList<Donation_get_volunteer> donationList = new ArrayList<>();
////////    private ProgressBar progressBar;
////////    private TextView tvEmpty;
////////    private ApiService apiService;
////////    private int volunteerId = 33; // Replace with actual volunteer ID
////////
////////    @Override
////////    protected void onCreate(Bundle savedInstanceState) {
////////        super.onCreate(savedInstanceState);
////////        setContentView(R.layout.manage_donation_volunteer);
////////
////////        recyclerView = findViewById(R.id.recyclerDonations);
////////        progressBar = findViewById(R.id.progressBar);
////////        tvEmpty = findViewById(R.id.tvEmpty);
////////
////////        // Initialize RecyclerView
////////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
////////        adapter = new DonationAdapter_Volunteer(this, donationList);
////////        recyclerView.setAdapter(adapter);
////////
////////        // Set click listener
////////        adapter.setOnItemClickListener(position -> {
////////            Donation_get_volunteer donation = donationList.get(position);
////////            // Handle update status action
////////            Toast.makeText(this, "Update donation ID: " + donation.getId(), Toast.LENGTH_SHORT).show();
////////        });
////////
////////        // Initialize Retrofit
////////        Retrofit retrofit = new Retrofit.Builder()
////////                .baseUrl("https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/")
////////                .addConverterFactory(GsonConverterFactory.create())
////////                .build();
////////
////////        apiService = retrofit.create(ApiService.class);
////////
////////        // Load data from API
////////        loadDonations();
////////    }
////////
////////    private void loadDonations() {
////////        progressBar.setVisibility(View.VISIBLE);
////////        tvEmpty.setVisibility(View.GONE);
////////
////////        Call<DonationResponse_get_Volunteer> call = apiService.getVolunteerDonations(volunteerId);
////////        call.enqueue(new Callback<DonationResponse_get_Volunteer>() {
////////            @Override
////////            public void onResponse(Call<DonationResponse_get_Volunteer> call, Response<DonationResponse_get_Volunteer> response) {
////////                progressBar.setVisibility(View.GONE);
////////
////////                if (response.isSuccessful() && response.body() != null) {
////////                    DonationResponse_get_Volunteer donationResponse = response.body();
////////                    if (donationResponse.getStatus().equals("success")) {
////////                        donationList.clear();
////////                        donationList.addAll(donationResponse.getDonations());
////////                        adapter.notifyDataSetChanged();
////////
////////                        if (donationList.isEmpty()) {
////////                            tvEmpty.setVisibility(View.VISIBLE);
////////                            tvEmpty.setText("No donations assigned to you");
////////                        }
////////                    } else {
////////                        Toast.makeText(DonationListActivity_volunteer.this,
////////                                "Failed to load donations", Toast.LENGTH_SHORT).show();
////////                    }
////////                } else {
////////                    Toast.makeText(DonationListActivity_volunteer.this,
////////                            "Server error", Toast.LENGTH_SHORT).show();
////////                }
////////            }
////////
////////            @Override
////////            public void onFailure(Call<DonationResponse_get_Volunteer> call, Throwable t) {
////////                progressBar.setVisibility(View.GONE);
////////                Toast.makeText(DonationListActivity_volunteer.this,
////////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////////                tvEmpty.setVisibility(View.VISIBLE);
////////                tvEmpty.setText("Failed to connect to server");
////////            }
////////        });
////////    }
////////}
////////package com.SIMATS.hope;
////////
////////import android.os.Bundle;
////////import android.view.View;
////////import android.widget.ProgressBar;
////////import android.widget.TextView;
////////import android.widget.Toast;
////////import androidx.appcompat.app.AppCompatActivity;
////////import androidx.recyclerview.widget.LinearLayoutManager;
////////import androidx.recyclerview.widget.RecyclerView;
////////import java.util.ArrayList;
////////import retrofit2.Call;
////////import retrofit2.Callback;
////////import retrofit2.Response;
////////import retrofit2.Retrofit;
////////import retrofit2.converter.gson.GsonConverterFactory;
////////
////////public class DonationListActivity_volunteer extends AppCompatActivity {
////////
////////    private RecyclerView recyclerView;
////////    private DonationAdapter_Volunteer adapter;
////////    private ArrayList<Donation_get_volunteer> donationList = new ArrayList<>();
////////    private ProgressBar progressBar;
////////    private TextView tvEmpty;
////////    private ApiService apiService;
////////    private int volunteerId = 33; // Replace with actual volunteer ID from session
////////
////////    @Override
////////    protected void onCreate(Bundle savedInstanceState) {
////////        super.onCreate(savedInstanceState);
////////        setContentView(R.layout.manage_donation_volunteer);
////////
////////        recyclerView = findViewById(R.id.recyclerDonations);
////////        progressBar = findViewById(R.id.progressBar);
////////        tvEmpty = findViewById(R.id.tvEmpty);
////////
////////        // Initialize RecyclerView
////////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
////////        adapter = new DonationAdapter_Volunteer(this, donationList);
////////        recyclerView.setAdapter(adapter);
////////
////////        // Initialize Retrofit
////////        Retrofit retrofit = new Retrofit.Builder()
////////                .baseUrl("https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/")
////////                .addConverterFactory(GsonConverterFactory.create())
////////                .build();
////////
////////        apiService = retrofit.create(ApiService.class);
////////
////////        // Set click listener for status updates
////////        // In your DonationListActivity_volunteer
////////        adapter.setOnItemClickListener(position -> {
////////            Donation_get_volunteer donation = donationList.get(position);
////////            // Handle the update status action here
////////            Toast.makeText(this,
////////                    "Update donation ID: " + donation.getId() +
////////                            "\nAssigned to: " + donation.getVolunteerUsername(),
////////                    Toast.LENGTH_SHORT).show();
////////        });
////////
////////        // Load data from API
////////        loadDonations();
////////    }
////////
////////    private void updateDonationStatus_Volunteer(int donationId, String newStatus, int volunteerId) {
////////        progressBar.setVisibility(View.VISIBLE);
////////
////////        StatusUpdateRequest_Volunteer request = new StatusUpdateRequest_Volunteer(donationId, newStatus, volunteerId);
////////        Call<StatusUpdateResponse_Volunteer> call = apiService.updateDonationStatus_Volunteer(request);
////////
////////        call.enqueue(new Callback<StatusUpdateResponse_Volunteer>() {
////////            @Override
////////            public void onResponse(Call<StatusUpdateResponse_Volunteer> call, Response<StatusUpdateResponse_Volunteer> response) {
////////                progressBar.setVisibility(View.GONE);
////////
////////                if (response.isSuccessful() && response.body() != null) {
////////                    StatusUpdateResponse_Volunteer updateResponse = response.body();
////////                    if (updateResponse.getStatus().equals("success")) {
////////                        Toast.makeText(DonationListActivity_volunteer.this,
////////                                updateResponse.getMessage(), Toast.LENGTH_SHORT).show();
////////                        // Refresh the donations list
////////                        loadDonations();
////////                    } else {
////////                        Toast.makeText(DonationListActivity_volunteer.this,
////////                                updateResponse.getMessage(), Toast.LENGTH_SHORT).show();
////////                    }
////////                } else {
////////                    Toast.makeText(DonationListActivity_volunteer.this,
////////                            "Failed to update status", Toast.LENGTH_SHORT).show();
////////                }
////////            }
////////
////////            @Override
////////            public void onFailure(Call<StatusUpdateResponse_Volunteer> call, Throwable t) {
////////                progressBar.setVisibility(View.GONE);
////////                Toast.makeText(DonationListActivity_volunteer.this,
////////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////////            }
////////        });
////////    }
////////
////////    private void loadDonations() {
////////        progressBar.setVisibility(View.VISIBLE);
////////        tvEmpty.setVisibility(View.GONE);
////////
////////        Call<DonationResponse_get_Volunteer> call = apiService.getVolunteerDonations(volunteerId);
////////        call.enqueue(new Callback<DonationResponse_get_Volunteer>() {
////////            @Override
////////            public void onResponse(Call<DonationResponse_get_Volunteer> call, Response<DonationResponse_get_Volunteer> response) {
////////                progressBar.setVisibility(View.GONE);
////////
////////                if (response.isSuccessful() && response.body() != null) {
////////                    DonationResponse_get_Volunteer donationResponse = response.body();
////////                    if (donationResponse.getStatus().equals("success")) {
////////                        donationList.clear();
////////                        donationList.addAll(donationResponse.getDonations());
////////                        adapter.notifyDataSetChanged();
////////
////////                        if (donationList.isEmpty()) {
////////                            tvEmpty.setVisibility(View.VISIBLE);
////////                            tvEmpty.setText("No donations assigned to you");
////////                        }
////////                    } else {
////////                        Toast.makeText(DonationListActivity_volunteer.this,
////////                                "Failed to load donations", Toast.LENGTH_SHORT).show();
////////                    }
////////                } else {
////////                    Toast.makeText(DonationListActivity_volunteer.this,
////////                            "Server error", Toast.LENGTH_SHORT).show();
////////                }
////////            }
////////
////////            @Override
////////            public void onFailure(Call<DonationResponse_get_Volunteer> call, Throwable t) {
////////                progressBar.setVisibility(View.GONE);
////////                Toast.makeText(DonationListActivity_volunteer.this,
////////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////////                tvEmpty.setVisibility(View.VISIBLE);
////////                tvEmpty.setText("Failed to connect to server");
////////            }
////////        });
////////    }
////////}
//////package com.SIMATS.hope;
//////
//////import android.os.Bundle;
//////import android.view.View;
//////import android.widget.ProgressBar;
//////import android.widget.TextView;
//////import android.widget.Toast;
//////import androidx.appcompat.app.AppCompatActivity;
//////import androidx.recyclerview.widget.LinearLayoutManager;
//////import androidx.recyclerview.widget.RecyclerView;
//////import java.util.ArrayList;
//////import retrofit2.Call;
//////import retrofit2.Callback;
//////import retrofit2.Response;
//////import retrofit2.Retrofit;
//////import retrofit2.converter.gson.GsonConverterFactory;
//////
//////public class DonationListActivity_volunteer extends AppCompatActivity {
//////
//////    private RecyclerView recyclerView;
//////    private DonationAdapter_Volunteer adapter;
//////    private ArrayList<Donation_get_volunteer> donationList = new ArrayList<>();
//////    private ProgressBar progressBar;
//////    private TextView tvEmpty;
//////    private ApiService apiService;
//////    private int volunteerId = 33; // Replace with actual volunteer ID from session or login
//////
//////    @Override
//////    protected void onCreate(Bundle savedInstanceState) {
//////        super.onCreate(savedInstanceState);
//////        setContentView(R.layout.manage_donation_volunteer);
//////
//////        recyclerView = findViewById(R.id.recyclerDonations);
//////        progressBar = findViewById(R.id.progressBar);
//////        tvEmpty = findViewById(R.id.tvEmpty);
//////
//////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//////        adapter = new DonationAdapter_Volunteer(this, donationList);
//////        recyclerView.setAdapter(adapter);
//////
//////        // Retrofit initialization
//////        Retrofit retrofit = new Retrofit.Builder()
//////                .baseUrl("https://nqwplfz1-80.inc1.devtunnels.ms/Orphanage-app/") // Replace with production IP/domain
//////                .addConverterFactory(GsonConverterFactory.create())
//////                .build();
//////
//////        apiService = retrofit.create(ApiService.class);
//////
//////        // Item click: update donation status
//////        adapter.setOnItemClickListener(position -> {
//////            Donation_get_volunteer donation = donationList.get(position);
//////
//////            // Update status to "collected"
//////            updateDonationStatus_Volunteer(donation.getId(), "collected", volunteerId);
//////
//////            Toast.makeText(this,
//////                    "Updating donation ID: " + donation.getId() +
//////                            "\nAssigned to: " + donation.getVolunteerUsername(),
//////                    Toast.LENGTH_SHORT).show();
//////        });
//////
//////        // Load the list initially
//////        loadDonations();
//////    }
//////
//////    private void loadDonations() {
//////        progressBar.setVisibility(View.VISIBLE);
//////        tvEmpty.setVisibility(View.GONE);
//////
//////        Call<DonationResponse_get_Volunteer> call = apiService.getVolunteerDonations(volunteerId);
//////        call.enqueue(new Callback<DonationResponse_get_Volunteer>() {
//////            @Override
//////            public void onResponse(Call<DonationResponse_get_Volunteer> call, Response<DonationResponse_get_Volunteer> response) {
//////                progressBar.setVisibility(View.GONE);
//////
//////                if (response.isSuccessful() && response.body() != null) {
//////                    DonationResponse_get_Volunteer donationResponse = response.body();
//////                    if ("success".equals(donationResponse.getStatus())) {
//////                        donationList.clear();
//////                        donationList.addAll(donationResponse.getDonations());
//////                        adapter.notifyDataSetChanged();
//////
//////                        if (donationList.isEmpty()) {
//////                            tvEmpty.setVisibility(View.VISIBLE);
//////                            tvEmpty.setText("No donations assigned to you");
//////                        }
//////                    } else {
//////                        Toast.makeText(DonationListActivity_volunteer.this,
//////                                "Failed to load donations", Toast.LENGTH_SHORT).show();
//////                    }
//////                } else {
//////                    Toast.makeText(DonationListActivity_volunteer.this,
//////                            "Server error", Toast.LENGTH_SHORT).show();
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<DonationResponse_get_Volunteer> call, Throwable t) {
//////                progressBar.setVisibility(View.GONE);
//////                tvEmpty.setVisibility(View.VISIBLE);
//////                tvEmpty.setText("Failed to connect to server");
//////                Toast.makeText(DonationListActivity_volunteer.this,
//////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////            }
//////        });
//////    }
//////
//////    private void updateDonationStatus_Volunteer(int donationId, String newStatus, int volunteerId) {
//////        progressBar.setVisibility(View.VISIBLE);
//////
//////        StatusUpdateRequest_Volunteer request = new StatusUpdateRequest_Volunteer(donationId, newStatus, volunteerId);
//////        Call<StatusUpdateResponse_Volunteer> call = apiService.updateDonationStatus_Volunteer(request);
//////
//////        call.enqueue(new Callback<StatusUpdateResponse_Volunteer>() {
//////            @Override
//////            public void onResponse(Call<StatusUpdateResponse_Volunteer> call, Response<StatusUpdateResponse_Volunteer> response) {
//////                progressBar.setVisibility(View.GONE);
//////
//////                if (response.isSuccessful() && response.body() != null) {
//////                    StatusUpdateResponse_Volunteer updateResponse = response.body();
//////                    Toast.makeText(DonationListActivity_volunteer.this,
//////                            updateResponse.getMessage(), Toast.LENGTH_SHORT).show();
//////
//////                    if ("success".equals(updateResponse.getStatus())) {
//////                        loadDonations(); // Refresh the list
//////                    }
//////                } else {
//////                    Toast.makeText(DonationListActivity_volunteer.this,
//////                            "Failed to update status", Toast.LENGTH_SHORT).show();
//////                }
//////            }
//////
//////            @Override
//////            public void onFailure(Call<StatusUpdateResponse_Volunteer> call, Throwable t) {
//////                progressBar.setVisibility(View.GONE);
//////                Toast.makeText(DonationListActivity_volunteer.this,
//////                        "Network error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//////            }
//////        });
//////    }
//////}
////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.os.Bundle;
////import android.view.View;
////import android.widget.ProgressBar;
////import android.widget.TextView;
////import android.widget.Toast;
////
////import androidx.appcompat.app.AppCompatActivity;
////import androidx.recyclerview.widget.LinearLayoutManager;
////import androidx.recyclerview.widget.RecyclerView;
////
////import java.util.ArrayList;
////
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class DonationListActivity_volunteer extends AppCompatActivity {
////
////    private RecyclerView recyclerView;
////    private DonationAdapter_Volunteer adapter;
////    private ArrayList<Donation_get_volunteer> donationList = new ArrayList<>();
////    private ProgressBar progressBar;
////    private TextView tvEmpty, tvTotalCount, tvAssignedCount, tvCompletedCount;
////    private ApiService apiService;
////    private PrefManager prefManager;
////    private int volunteerId;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.manage_donation_volunteer);
////
////        prefManager = new PrefManager(this);
////        checkLoginStatus();
////
////        volunteerId = prefManager.getVolunteerId();
////
////        recyclerView = findViewById(R.id.recyclerDonations);
////        progressBar = findViewById(R.id.progressBar);
////        tvEmpty = findViewById(R.id.tvEmpty);
////        tvTotalCount = findViewById(R.id.tvTotalCount);
////        tvAssignedCount = findViewById(R.id.tvAssignedCount);
////        tvCompletedCount = findViewById(R.id.tvCompletedCount);
////
////        recyclerView.setLayoutManager(new LinearLayoutManager(this));
////        adapter = new DonationAdapter_Volunteer(this, donationList);
////        recyclerView.setAdapter(adapter);
////
////        apiService = ApiClient.getClient().create(ApiService.class);
////
////        // Handle item click to toggle status
////        adapter.setOnItemClickListener(position -> {
////            Donation_get_volunteer donation = donationList.get(position);
////            String currentStatus = donation.getStatus();
////
////            // Toggle between "Assigned" and "Completed"
////            String newStatus = "Completed".equalsIgnoreCase(currentStatus) ? "Assigned" : "Completed";
////
////            updateDonationStatus(donation.getId(), newStatus, position);
////        });
////
////        fetchVolunteerDonations();
////    }
////
////    private void checkLoginStatus() {
////        if (!prefManager.isLoggedIn() || !prefManager.isVolunteer()) {
////            startActivity(new Intent(this, LoginActivity.class));
////            finish();
////        }
////    }
////
////    private void fetchVolunteerDonations() {
////        progressBar.setVisibility(View.VISIBLE);
////        recyclerView.setVisibility(View.GONE);
////        tvEmpty.setVisibility(View.GONE);
////
////        Call<DonationResponse_get_Volunteer> call = apiService.getVolunteerDonations(volunteerId);
////        call.enqueue(new Callback<DonationResponse_get_Volunteer>() {
////            @Override
////            public void onResponse(Call<DonationResponse_get_Volunteer> call, Response<DonationResponse_get_Volunteer> response) {
////                progressBar.setVisibility(View.GONE);
////                if (response.isSuccessful() && response.body() != null) {
////                    donationList.clear();
////                    donationList.addAll(response.body().getDonations());
////                    adapter.notifyDataSetChanged();
////
////                    updateCounts();
////                    recyclerView.setVisibility(donationList.isEmpty() ? View.GONE : View.VISIBLE);
////                    tvEmpty.setVisibility(donationList.isEmpty() ? View.VISIBLE : View.GONE);
////                } else {
////                    Toast.makeText(DonationListActivity_volunteer.this, "Failed to load donations", Toast.LENGTH_SHORT).show();
////                }
////            }
////
////            @Override
////            public void onFailure(Call<DonationResponse_get_Volunteer> call, Throwable t) {
////                progressBar.setVisibility(View.GONE);
////                Toast.makeText(DonationListActivity_volunteer.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////            }
////        });
////    }
////
////    private void updateDonationStatus(int donationId, String newStatus, int position) {
////        StatusUpdateRequest_Volunteer request = new StatusUpdateRequest_Volunteer(donationId, newStatus, volunteerId);
////
////        Call<StatusUpdateResponse_Volunteer> call = apiService.updateDonationStatus_Volunteer(request);
////        call.enqueue(new Callback<StatusUpdateResponse_Volunteer>() {
////            @Override
////            public void onResponse(Call<StatusUpdateResponse_Volunteer> call, Response<StatusUpdateResponse_Volunteer> response) {
////                if (response.isSuccessful() && response.body() != null) {
////                    donationList.get(position).setStatus(newStatus); // Update local data
////                    adapter.notifyItemChanged(position);
////                    Toast.makeText(DonationListActivity_volunteer.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
////                    updateCounts();
////                } else {
////                    Toast.makeText(DonationListActivity_volunteer.this, "Failed to update status", Toast.LENGTH_SHORT).show();
////                }
////            }
////
////            @Override
////            public void onFailure(Call<StatusUpdateResponse_Volunteer> call, Throwable t) {
////                Toast.makeText(DonationListActivity_volunteer.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
////            }
////        });
////    }
////
////    private void updateCounts() {
////        int total = donationList.size();
////        int assigned = 0;
////        int completed = 0;
////
////        for (Donation_get_volunteer d : donationList) {
////            if ("Completed".equalsIgnoreCase(d.getStatus())) {
////                completed++;
////            } else {
////                assigned++;
////            }
////        }
////
////        tvTotalCount.setText("Total: " + total);
////        tvAssignedCount.setText("Assigned: " + assigned);
////        tvCompletedCount.setText("Completed: " + completed);
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.google.android.material.bottomnavigation.BottomNavigationView;
//
//import java.util.ArrayList;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class DonationListActivity_volunteer extends AppCompatActivity {
//
//    private RecyclerView recyclerView;
//    private DonationAdapter_Volunteer adapter;
//    private ArrayList<Donation_get_volunteer> donationList = new ArrayList<>();
//    private ProgressBar progressBar;
//    private TextView tvEmpty, tvTotalCount, tvAssignedCount, tvCompletedCount;
//    private ApiService apiService;
//    private PrefManager prefManager;
//    private int volunteerId;
//    private BottomNavigationView bottomNavigationView;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.manage_donation_volunteer);
//
//        prefManager = new PrefManager(this);
//        checkLoginStatus();
//
//        volunteerId = prefManager.getVolunteerId();
//
//        initializeViews();
//        setupBottomNavigation();
//        setupRecyclerView();
//
//        // Handle item click to toggle status
//        adapter.setOnItemClickListener(position -> {
//            Donation_get_volunteer donation = donationList.get(position);
//            String currentStatus = donation.getStatus();
//
//            // Toggle between "Assigned" and "Completed"
//            String newStatus = "Completed".equalsIgnoreCase(currentStatus) ? "Assigned" : "Completed";
//
//            updateDonationStatus(donation.getId(), newStatus, position);
//        });
//
//        fetchVolunteerDonations();
//    }
//
//    private void initializeViews() {
//        recyclerView = findViewById(R.id.recyclerDonations);
//        progressBar = findViewById(R.id.progressBar);
//        tvEmpty = findViewById(R.id.tvEmpty);
//        tvTotalCount = findViewById(R.id.tvTotalCount);
//        tvAssignedCount = findViewById(R.id.tvAssignedCount);
//        tvCompletedCount = findViewById(R.id.tvCompletedCount);
//        bottomNavigationView = findViewById(R.id.bottomNavigationView);
//    }
//
//    private void setupBottomNavigation() {
//        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
//            @Override
//            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//                int itemId = item.getItemId();
//
//                if (itemId == R.id.nav_home) {
//                    startActivity(new Intent(DonationListActivity_volunteer.this, VolunteerDashboardActivity.class));
//                    finish();
//                    return true;
//                } else if (itemId == R.id.nav_reports) {
//                    startActivity(new Intent(DonationListActivity_volunteer.this, AssignedReportsActivity_Volunteer.class));
//                    finish();
//                    return true;
//                } else if (itemId == R.id.nav_donations) {
//                    // Already on donations page, do nothing
//                    return true;
//                }
//                return false;
//            }
//        });
//
//        // Set donations as selected by default
//        bottomNavigationView.setSelectedItemId(R.id.nav_donations);
//    }
//
//    private void setupRecyclerView() {
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        adapter = new DonationAdapter_Volunteer(this, donationList);
//        recyclerView.setAdapter(adapter);
//
//        apiService = ApiClient.getClient().create(ApiService.class);
//    }
//
//    private void checkLoginStatus() {
//        if (!prefManager.isLoggedIn() || !prefManager.isVolunteer()) {
//            startActivity(new Intent(this, LoginActivity.class));
//            finish();
//        }
//    }
//
//    private void fetchVolunteerDonations() {
//        progressBar.setVisibility(View.VISIBLE);
//        recyclerView.setVisibility(View.GONE);
//        tvEmpty.setVisibility(View.GONE);
//
//        Call<DonationResponse_get_Volunteer> call = apiService.getVolunteerDonations(volunteerId);
//        call.enqueue(new Callback<DonationResponse_get_Volunteer>() {
//            @Override
//            public void onResponse(Call<DonationResponse_get_Volunteer> call, Response<DonationResponse_get_Volunteer> response) {
//                progressBar.setVisibility(View.GONE);
//                if (response.isSuccessful() && response.body() != null) {
//                    donationList.clear();
//                    donationList.addAll(response.body().getDonations());
//                    adapter.notifyDataSetChanged();
//
//                    updateCounts();
//                    recyclerView.setVisibility(donationList.isEmpty() ? View.GONE : View.VISIBLE);
//                    tvEmpty.setVisibility(donationList.isEmpty() ? View.VISIBLE : View.GONE);
//                } else {
//                    Toast.makeText(DonationListActivity_volunteer.this, "Failed to load donations", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<DonationResponse_get_Volunteer> call, Throwable t) {
//                progressBar.setVisibility(View.GONE);
//                Toast.makeText(DonationListActivity_volunteer.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void updateDonationStatus(int donationId, String newStatus, int position) {
//        StatusUpdateRequest_Volunteer request = new StatusUpdateRequest_Volunteer(donationId, newStatus, volunteerId);
//
//        Call<StatusUpdateResponse_Volunteer> call = apiService.updateDonationStatus_Volunteer(request);
//        call.enqueue(new Callback<StatusUpdateResponse_Volunteer>() {
//            @Override
//            public void onResponse(Call<StatusUpdateResponse_Volunteer> call, Response<StatusUpdateResponse_Volunteer> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    donationList.get(position).setStatus(newStatus); // Update local data
//                    adapter.notifyItemChanged(position);
//                    Toast.makeText(DonationListActivity_volunteer.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
//                    updateCounts();
//                } else {
//                    Toast.makeText(DonationListActivity_volunteer.this, "Failed to update status", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<StatusUpdateResponse_Volunteer> call, Throwable t) {
//                Toast.makeText(DonationListActivity_volunteer.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void updateCounts() {
//        int total = donationList.size();
//        int assigned = 0;
//        int completed = 0;
//
//        for (Donation_get_volunteer d : donationList) {
//            if ("Completed".equalsIgnoreCase(d.getStatus())) {
//                completed++;
//            } else {
//                assigned++;
//            }
//        }
//
//        tvTotalCount.setText("Total: " + total);
//        tvAssignedCount.setText("Assigned: " + assigned);
//        tvCompletedCount.setText("Completed: " + completed);
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        // Set donations as selected when returning to this activity
//        if (bottomNavigationView != null) {
//            bottomNavigationView.setSelectedItemId(R.id.nav_donations);
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DonationListActivity_volunteer extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DonationAdapter_Volunteer adapter;
    private ArrayList<Donation_get_volunteer> donationList = new ArrayList<>();
    private ProgressBar progressBar;
    private TextView tvEmpty, tvTotalCount, tvAssignedCount, tvCompletedCount;
    private ApiService apiService;
    private PrefManager prefManager;
    private int volunteerId;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manage_donation_volunteer);

        prefManager = new PrefManager(this);
        checkLoginStatus();

        volunteerId = prefManager.getVolunteerId();

        initializeViews();
        setupBottomNavigation();
        setupRecyclerView();

        // Handle item click to toggle status
        adapter.setOnItemClickListener(position -> {
            Donation_get_volunteer donation = donationList.get(position);
            String currentStatus = donation.getStatus();

            // Toggle between "Assigned" and "Completed"
            String newStatus = "Completed".equalsIgnoreCase(currentStatus) ? "Assigned" : "Completed";

            updateDonationStatus(donation.getId(), newStatus, position);
        });

        // Handle upload receipt button click
        adapter.setOnUploadClickListener(donationId -> {
            navigateToUploadReceipt(donationId);
        });

        fetchVolunteerDonations();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerDonations);
        progressBar = findViewById(R.id.progressBar);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTotalCount = findViewById(R.id.tvTotalCount);
        tvAssignedCount = findViewById(R.id.tvAssignedCount);
        tvCompletedCount = findViewById(R.id.tvCompletedCount);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(DonationListActivity_volunteer.this, VolunteerDashboardActivity.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_reports) {
                    startActivity(new Intent(DonationListActivity_volunteer.this, AssignedReportsActivity_Volunteer.class));
                    finish();
                    return true;
                } else if (itemId == R.id.nav_donations) {
                    // Already on donations page, do nothing
                    return true;
                }
                return false;
            }
        });

        // Set donations as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_donations);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DonationAdapter_Volunteer(this, donationList);
        recyclerView.setAdapter(adapter);

        apiService = ApiClient.getClient().create(ApiService.class);
    }

    private void checkLoginStatus() {
        if (!prefManager.isLoggedIn() || !prefManager.isVolunteer()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }

    private void navigateToUploadReceipt(int donationId) {
        Intent intent = new Intent(DonationListActivity_volunteer.this, UploadReceiptActivity.class);
        intent.putExtra("donation_id", donationId);
        startActivity(intent);
    }

    private void fetchVolunteerDonations() {
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.GONE);
        tvEmpty.setVisibility(View.GONE);

        Call<DonationResponse_get_Volunteer> call = apiService.getVolunteerDonations(volunteerId);
        call.enqueue(new Callback<DonationResponse_get_Volunteer>() {
            @Override
            public void onResponse(Call<DonationResponse_get_Volunteer> call, Response<DonationResponse_get_Volunteer> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    donationList.clear();
                    donationList.addAll(response.body().getDonations());
                    adapter.notifyDataSetChanged();

                    updateCounts();
                    recyclerView.setVisibility(donationList.isEmpty() ? View.GONE : View.VISIBLE);
                    tvEmpty.setVisibility(donationList.isEmpty() ? View.VISIBLE : View.GONE);
                } else {
                    Toast.makeText(DonationListActivity_volunteer.this, "Failed to load donations", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<DonationResponse_get_Volunteer> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(DonationListActivity_volunteer.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateDonationStatus(int donationId, String newStatus, int position) {
        StatusUpdateRequest_Volunteer request = new StatusUpdateRequest_Volunteer(donationId, newStatus, volunteerId);

        Call<StatusUpdateResponse_Volunteer> call = apiService.updateDonationStatus_Volunteer(request);
        call.enqueue(new Callback<StatusUpdateResponse_Volunteer>() {
            @Override
            public void onResponse(Call<StatusUpdateResponse_Volunteer> call, Response<StatusUpdateResponse_Volunteer> response) {
                if (response.isSuccessful() && response.body() != null) {
                    donationList.get(position).setStatus(newStatus); // Update local data
                    adapter.notifyItemChanged(position);
                    Toast.makeText(DonationListActivity_volunteer.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    updateCounts();
                } else {
                    Toast.makeText(DonationListActivity_volunteer.this, "Failed to update status", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<StatusUpdateResponse_Volunteer> call, Throwable t) {
                Toast.makeText(DonationListActivity_volunteer.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateCounts() {
        int total = donationList.size();
        int assigned = 0;
        int completed = 0;

        for (Donation_get_volunteer d : donationList) {
            if ("Completed".equalsIgnoreCase(d.getStatus())) {
                completed++;
            } else {
                assigned++;
            }
        }

        tvTotalCount.setText("Total: " + total);
        tvAssignedCount.setText("Assigned: " + assigned);
        tvCompletedCount.setText("Completed: " + completed);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Set donations as selected when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_donations);
        }
        // Refresh data when returning to this activity
        fetchVolunteerDonations();
    }
}