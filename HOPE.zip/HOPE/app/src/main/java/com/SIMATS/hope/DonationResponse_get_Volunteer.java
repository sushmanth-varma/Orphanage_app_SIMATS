package com.SIMATS.hope;

import java.util.ArrayList;

public class DonationResponse_get_Volunteer {
    private String status;
    private int count;
    private ArrayList<Donation_get_volunteer> donations;

    public String getStatus() { return status; }
    public int getCount() { return count; }
    public ArrayList<Donation_get_volunteer> getDonations() { return donations; }
}
