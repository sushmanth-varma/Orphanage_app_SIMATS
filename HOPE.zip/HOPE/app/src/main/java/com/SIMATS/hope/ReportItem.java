package com.SIMATS.hope;

public class ReportItem {
    private String caseId;
    private String status;
    private String location;
    private String description;

    public ReportItem(String caseId, String status, String location, String description) {
        this.caseId = caseId;
        this.status = status;
        this.location = location;
        this.description = description;
    }

    public String getCaseId() {
        return caseId;
    }

    public String getStatus() {
        return status;
    }

    public String getLocation() {
        return location;
    }

    public String getDescription() {
        return description;
    }
}
