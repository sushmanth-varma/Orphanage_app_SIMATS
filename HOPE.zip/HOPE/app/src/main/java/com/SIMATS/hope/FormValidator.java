package com.SIMATS.hope;

import android.widget.EditText;
import java.util.regex.Pattern;

public class FormValidator {
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
            Pattern.CASE_INSENSITIVE
    );

    private static final Pattern PHONE_PATTERN = Pattern.compile(
            "^[+]?[0-9]{10,13}$"
    );

    public static boolean validateField(EditText field, String errorMessage) {
        if (field.getText().toString().trim().isEmpty()) {
            field.setError(errorMessage);
            field.requestFocus();
            return false;
        }
        return true;
    }

    public static boolean isValidName(String name) {
        // Allows only letters, spaces, and common name characters
        String namePattern = "^[a-zA-Z\\s.'-]{2,50}$";
        return Pattern.matches(namePattern, name);
    }

    public static boolean isValidIndianMobile(String mobile) {
        // Indian mobile numbers: 10 digits starting with 6-9
        String mobilePattern = "^[6-9]\\d{9}$";
        return Pattern.matches(mobilePattern, mobile);
    }

    public static boolean isValidEmail(String email) {
        // Standard email validation
        String emailPattern = "^[A-Za-z0-9+_.-]+@(.+)$";
        return Pattern.matches(emailPattern, email);
    }

    public static boolean isValidEmailOrPhone(String contact) {
        // Check if it's a valid mobile number OR valid email
        return isValidIndianMobile(contact) || isValidEmail(contact);
    }
}
