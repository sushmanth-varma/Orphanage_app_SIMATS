package com.SIMATS.hope;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;

public class ProofViewActivity extends AppCompatActivity {

    private ImageView ivProof;
    private TextView ivBack;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proof_view);

        String proofUrl = getIntent().getStringExtra("proof_url");

        initializeViews();

        if (proofUrl != null && !proofUrl.isEmpty()) {
            loadProofImage(proofUrl);
        } else {
            Toast.makeText(this, "No proof image available", Toast.LENGTH_SHORT).show();
            finish();
        }

        ivBack.setOnClickListener(v -> finish());
    }

    private void initializeViews() {
        ivProof = findViewById(R.id.ivProof);
        ivBack = findViewById(R.id.ivBack);
        progressBar = findViewById(R.id.progressBar);
    }

    private void loadProofImage(String proofImageUrl) {
        progressBar.setVisibility(android.view.View.VISIBLE);

        RequestOptions requestOptions = new RequestOptions()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.ic_image_placeholder)
                .error(R.drawable.ic_error);

        Glide.with(this)
                .load(proofImageUrl)
                .apply(requestOptions)
                .into(ivProof);

        progressBar.setVisibility(android.view.View.GONE);
    }
}