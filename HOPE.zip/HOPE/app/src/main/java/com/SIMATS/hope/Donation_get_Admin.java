package com.SIMATS.hope;

public class Donation_get_Admin {
    private String id;
    private String donation_type;
    private String cause;
    private String amount;
    private String item_description;
    private String quantity;
    private String full_name;
    private String email;
    private String phone;
    private String orphanage_name;
    private String location;
    private String created_at;
    private String status;
    private String assigned_to;
    private String collected_at;
    private String updated_by;
    private String user_id;
    private String donor_name;
    private String volunteer_name;

    // Getters
    public String getId() { return id; }
    public String getDonation_type() { return donation_type; }
    public String getCause() { return cause; }
    public String getAmount() { return amount; }
    public String getItem_description() { return item_description; }
    public String getQuantity() { return quantity; }
    public String getFull_name() { return full_name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getOrphanage_name() { return orphanage_name; }
    public String getLocation() { return location; }
    public String getCreated_at() { return created_at; }
    public String getStatus() { return status; }
    public String getAssigned_to() { return assigned_to; }
    public String getCollected_at() { return collected_at; }
    public String getUpdated_by() { return updated_by; }
    public String getUser_id() { return user_id; }
    public String getDonor_name() {
        return donor_name != null ? donor_name : full_name;
    }
    public String getVolunteer_name() { return volunteer_name; }
}