////package com.SIMATS.hope;
////
////import android.content.Intent;
////import android.os.Bundle;
////import android.text.Editable;
////import android.text.TextUtils;
////import android.text.TextWatcher;
////import android.util.Patterns;
////import android.view.View;
////import android.widget.Button;
////import android.widget.ImageView;
////import android.widget.ProgressBar;
////import android.widget.Toast;
////
////import androidx.appcompat.app.AppCompatActivity;
////
////import com.google.android.material.textfield.TextInputEditText;
////import com.google.android.material.textfield.TextInputLayout;
////
////import retrofit2.Call;
////import retrofit2.Callback;
////import retrofit2.Response;
////
////public class VolunteerRequestActivity extends AppCompatActivity {
////    private TextInputEditText etName, etEmail, etPhone, etPlace, etReason;
////    private TextInputLayout nameInputLayout, emailInputLayout, phoneInputLayout, placeInputLayout;
////    private Button btnSubmit;
////    private ProgressBar progressBar;
////    private ImageView ivBack; // Added back button reference
////    private String phone;
////
////    @Override
////    protected void onCreate(Bundle savedInstanceState) {
////        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_volunteer_request);
////
////        phone = getIntent().getStringExtra("phone");
////
////        initializeViews();
////        setupTextWatchers();
////
////        etPhone.setText(phone); // prefill phone
////        etPhone.setEnabled(false); // Make phone field non-editable since it's prefilled
////
////        btnSubmit.setOnClickListener(v -> validateAndSubmit());
////
////        // Add back button functionality
////        ivBack.setOnClickListener(v -> finish());
////    }
////
////    private void initializeViews() {
////        etName = findViewById(R.id.etName);
////        etEmail = findViewById(R.id.etEmail);
////        etPhone = findViewById(R.id.etPhone);
////        etPlace = findViewById(R.id.etPlace);
////        etReason = findViewById(R.id.etReason);
////
////        nameInputLayout = findViewById(R.id.nameInputLayout);
////        emailInputLayout = findViewById(R.id.emailInputLayout);
////        phoneInputLayout = findViewById(R.id.phoneInputLayout);
////        placeInputLayout = findViewById(R.id.placeInputLayout);
////
////        btnSubmit = findViewById(R.id.btnSubmitVolunteer);
////        progressBar = findViewById(R.id.progressBar);
////        ivBack = findViewById(R.id.ivBack); // Initialize back button
////    }
////
////    private void setupTextWatchers() {
////        // Clear errors when user starts typing
////        etName.addTextChangedListener(new ClearErrorTextWatcher(nameInputLayout));
////        etEmail.addTextChangedListener(new ClearErrorTextWatcher(emailInputLayout));
////        etPhone.addTextChangedListener(new ClearErrorTextWatcher(phoneInputLayout));
////        etPlace.addTextChangedListener(new ClearErrorTextWatcher(placeInputLayout));
////    }
////
////    private void validateAndSubmit() {
////        String name = etName.getText().toString().trim();
////        String email = etEmail.getText().toString().trim();
////        String phone = etPhone.getText().toString().trim();
////        String place = etPlace.getText().toString().trim();
////        String reason = etReason.getText().toString().trim();
////
////        boolean isValid = true;
////
////        // Validate name
////        if (TextUtils.isEmpty(name)) {
////            nameInputLayout.setError("Name is required");
////            isValid = false;
////        } else if (name.length() < 3) {
////            nameInputLayout.setError("Name should be at least 3 characters");
////            isValid = false;
////        }
////
////        // Validate email
////        if (TextUtils.isEmpty(email)) {
////            emailInputLayout.setError("Email is required");
////            isValid = false;
////        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
////            emailInputLayout.setError("Please enter a valid email address");
////            isValid = false;
////        }
////
////        // Validate phone
////        if (TextUtils.isEmpty(phone)) {
////            phoneInputLayout.setError("Phone number is required");
////            isValid = false;
////        } else if (phone.length() < 10) {
////            phoneInputLayout.setError("Please enter a valid phone number");
////            isValid = false;
////        }
////
////        // Validate place
////        if (TextUtils.isEmpty(place)) {
////            placeInputLayout.setError("Place is required");
////            isValid = false;
////        }
////
////        if (!isValid) {
////            return;
////        }
////
////        // All validations passed, proceed with submission
////        submitForm(name, email, phone, place, reason);
////    }
////
////    private void submitForm(String name, String email, String phone, String place, String reason) {
////        // Show loading state
////        progressBar.setVisibility(View.VISIBLE);
////        btnSubmit.setEnabled(false);
////
////        // Create volunteer request object
////        VolunteerRequest volunteerRequest = new VolunteerRequest(name, email, phone, place, reason);
////
////        // Make API call using Retrofit
////        ApiService apiService = ApiClient.getClient().create(ApiService.class);
////        Call<Volunteer_OtpResponse> call = apiService.registerVolunteer(volunteerRequest);
////
////        call.enqueue(new Callback<Volunteer_OtpResponse>() {
////            @Override
////            public void onResponse(Call<Volunteer_OtpResponse> call, Response<Volunteer_OtpResponse> response) {
////                // Hide loading state
////                progressBar.setVisibility(View.GONE);
////                btnSubmit.setEnabled(true);
////
////                if (response.isSuccessful() && response.body() != null) {
////                    Volunteer_OtpResponse apiResponse = response.body();
////
////                    if ("success".equals(apiResponse.getStatus())) {
////                        // Show success message
////                        Toast.makeText(VolunteerRequestActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
////
////                        // Navigate to success activity
////                        Intent intent = new Intent(VolunteerRequestActivity.this, VolunteerSuccessActivity.class);
////                        intent.putExtra("name", name);
////                        startActivity(intent);
////                        finish();
////                    } else {
////                        // Show error message from server
////                        Toast.makeText(VolunteerRequestActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
////                    }
////                } else {
////                    // Handle server error
////                    Toast.makeText(VolunteerRequestActivity.this, "Server error. Please try again.", Toast.LENGTH_SHORT).show();
////                }
////            }
////
////            @Override
////            public void onFailure(Call<Volunteer_OtpResponse> call, Throwable t) {
////                // Hide loading state
////                progressBar.setVisibility(View.GONE);
////                btnSubmit.setEnabled(true);
////
////                // Handle network failure
////                Toast.makeText(VolunteerRequestActivity.this, "Network error. Please check your connection.", Toast.LENGTH_SHORT).show();
////                t.printStackTrace(); // For debugging
////            }
////        });
////    }
////
////    // TextWatcher to clear error when user starts typing
////    private class ClearErrorTextWatcher implements TextWatcher {
////        private TextInputLayout inputLayout;
////
////        ClearErrorTextWatcher(TextInputLayout inputLayout) {
////            this.inputLayout = inputLayout;
////        }
////
////        @Override
////        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
////        }
////
////        @Override
////        public void onTextChanged(CharSequence s, int start, int before, int count) {
////            inputLayout.setError(null);
////        }
////
////        @Override
////        public void afterTextChanged(Editable s) {
////        }
////    }
////}
//package com.SIMATS.hope;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.text.Editable;
//import android.text.TextUtils;
//import android.text.TextWatcher;
//import android.util.Patterns;
//import android.view.View;
//import android.widget.AdapterView;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.ProgressBar;
//import android.widget.Spinner;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.android.material.textfield.TextInputEditText;
//import com.google.android.material.textfield.TextInputLayout;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class VolunteerRequestActivity extends AppCompatActivity {
//    private TextInputEditText etName, etEmail, etPhone, etReason;
//    private TextInputLayout nameInputLayout, emailInputLayout, phoneInputLayout, placeInputLayout;
//    private Button btnSubmit;
//    private ProgressBar progressBar;
//    private ImageView ivBack;
//    private Spinner spinnerCity;
//
//    private List<String> citiesList = new ArrayList<>();
//    private String selectedCity = "";
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_volunteer_request);
//
//        initializeViews();
//        setupTextWatchers();
//        fetchCities(); // Fetch cities from API
//
//        btnSubmit.setOnClickListener(v -> validateAndSubmit());
//        ivBack.setOnClickListener(v -> finish());
//    }
//
//    private void initializeViews() {
//        etName = findViewById(R.id.etName);
//        etEmail = findViewById(R.id.etEmail);
//        etPhone = findViewById(R.id.etPhone);
//        etReason = findViewById(R.id.etReason);
//        spinnerCity = findViewById(R.id.spinnerCity);
//
//        nameInputLayout = findViewById(R.id.nameInputLayout);
//        emailInputLayout = findViewById(R.id.emailInputLayout);
//        phoneInputLayout = findViewById(R.id.phoneInputLayout);
//        placeInputLayout = findViewById(R.id.placeInputLayout);
//
//        btnSubmit = findViewById(R.id.btnSubmitVolunteer);
//        progressBar = findViewById(R.id.progressBar);
//        ivBack = findViewById(R.id.ivBack);
//    }
//
//    private void fetchCities() {
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<CityResponse> call = apiService.getAllCities();
//
//        call.enqueue(new Callback<CityResponse>() {
//            @Override
//            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    citiesList = response.body().getCities();
//                    if (citiesList != null && !citiesList.isEmpty()) {
//                        citiesList.add(0, "Select Your City");
//                        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(VolunteerRequestActivity.this,
//                                android.R.layout.simple_spinner_dropdown_item, citiesList);
//                        spinnerCity.setAdapter(cityAdapter);
//
//                        // Set spinner selection listener
//                        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//                            @Override
//                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                                selectedCity = parent.getItemAtPosition(position).toString();
//                                // Clear error when user selects a city
//                                if (!selectedCity.equals("Select Your City")) {
//                                    placeInputLayout.setError(null);
//                                }
//                            }
//
//                            @Override
//                            public void onNothingSelected(AdapterView<?> parent) {
//                            }
//                        });
//                    }
//                }
//            }
//
//            @Override
//            public void onFailure(Call<CityResponse> call, Throwable t) {
//                Toast.makeText(VolunteerRequestActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private void setupTextWatchers() {
//        // Clear errors when user starts typing
//        etName.addTextChangedListener(new ClearErrorTextWatcher(nameInputLayout));
//        etEmail.addTextChangedListener(new ClearErrorTextWatcher(emailInputLayout));
//        etPhone.addTextChangedListener(new ClearErrorTextWatcher(phoneInputLayout));
//
//        // Real-time validation for phone
//        etPhone.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                phoneInputLayout.setError(null);
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                String phone = s.toString();
//                if (!phone.isEmpty()) {
//                    if (!phone.matches("^[6-9]\\d{0,9}$")) {
//                        phoneInputLayout.setError("Enter valid Indian mobile number");
//                    } else if (phone.length() < 10) {
//                        phoneInputLayout.setError("10 digits required");
//                    } else {
//                        phoneInputLayout.setError(null);
//                    }
//                }
//            }
//        });
//    }
//
//    private void validateAndSubmit() {
//        String name = etName.getText().toString().trim();
//        String email = etEmail.getText().toString().trim();
//        String phone = etPhone.getText().toString().trim();
//        String reason = etReason.getText().toString().trim();
//
//        boolean isValid = true;
//
//        // Strict name validation
//        if (TextUtils.isEmpty(name)) {
//            nameInputLayout.setError("Name is required");
//            isValid = false;
//        } else if (!name.matches("^[a-zA-Z\\s.'-]{2,50}$")) {
//            nameInputLayout.setError("Only letters, spaces, . ' - allowed (2-50 characters)");
//            isValid = false;
//        }
//
//        // Strict email validation
//        if (TextUtils.isEmpty(email)) {
//            emailInputLayout.setError("Email is required");
//            isValid = false;
//        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
//            emailInputLayout.setError("Please enter a valid email address");
//            isValid = false;
//        }
//
//        // Strict phone validation (Indian numbers only)
//        if (TextUtils.isEmpty(phone)) {
//            phoneInputLayout.setError("Phone number is required");
//            isValid = false;
//        } else if (!phone.matches("^[6-9]\\d{9}$")) {
//            phoneInputLayout.setError("Please enter a valid 10-digit Indian mobile number");
//            isValid = false;
//        }
//
//        // City validation
//        if (selectedCity.equals("Select Your City") || selectedCity.isEmpty()) {
//            placeInputLayout.setError("Please select your city");
//            isValid = false;
//        }
//
//        if (!isValid) {
//            return;
//        }
//
//        // All validations passed, proceed with submission
//        submitForm(name, email, phone, selectedCity, reason);
//    }
//
//    private void submitForm(String name, String email, String phone, String place, String reason) {
//        // Show loading state
//        progressBar.setVisibility(View.VISIBLE);
//        btnSubmit.setEnabled(false);
//
//        // Create volunteer request object
//        VolunteerRequest volunteerRequest = new VolunteerRequest(name, email, phone, place, reason);
//
//        // Make API call using Retrofit
//        ApiService apiService = ApiClient.getClient().create(ApiService.class);
//        Call<Volunteer_OtpResponse> call = apiService.registerVolunteer(volunteerRequest);
//
//        call.enqueue(new Callback<Volunteer_OtpResponse>() {
//            @Override
//            public void onResponse(Call<Volunteer_OtpResponse> call, Response<Volunteer_OtpResponse> response) {
//                // Hide loading state
//                progressBar.setVisibility(View.GONE);
//                btnSubmit.setEnabled(true);
//
//                if (response.isSuccessful() && response.body() != null) {
//                    Volunteer_OtpResponse apiResponse = response.body();
//
//                    if ("success".equals(apiResponse.getStatus())) {
//                        // Show success message
//                        Toast.makeText(VolunteerRequestActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
//
//                        // Navigate to success activity
//                        Intent intent = new Intent(VolunteerRequestActivity.this, VolunteerSuccessActivity.class);
//                        intent.putExtra("name", name);
//                        startActivity(intent);
//                        finish();
//                    } else {
//                        // Show error message from server
//                        Toast.makeText(VolunteerRequestActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    // Handle server error
//                    Toast.makeText(VolunteerRequestActivity.this, "Server error. Please try again.", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<Volunteer_OtpResponse> call, Throwable t) {
//                // Hide loading state
//                progressBar.setVisibility(View.GONE);
//                btnSubmit.setEnabled(true);
//
//                // Handle network failure
//                Toast.makeText(VolunteerRequestActivity.this, "Network error. Please check your connection.", Toast.LENGTH_SHORT).show();
//                t.printStackTrace(); // For debugging
//            }
//        });
//    }
//
//    // TextWatcher to clear error when user starts typing
//    private class ClearErrorTextWatcher implements TextWatcher {
//        private TextInputLayout inputLayout;
//
//        ClearErrorTextWatcher(TextInputLayout inputLayout) {
//            this.inputLayout = inputLayout;
//        }
//
//        @Override
//        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//        }
//
//        @Override
//        public void onTextChanged(CharSequence s, int start, int before, int count) {
//            inputLayout.setError(null);
//        }
//
//        @Override
//        public void afterTextChanged(Editable s) {
//        }
//    }
//}
package com.SIMATS.hope;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class VolunteerRequestActivity extends AppCompatActivity {
    private TextInputEditText etName, etEmail, etPhone, etReason;
    private TextInputLayout nameInputLayout, emailInputLayout, phoneInputLayout, placeInputLayout;
    private Button btnSubmit;
    private ProgressBar progressBar;
    private ImageView ivBack;
    private Spinner spinnerCity;
    private BottomNavigationView bottomNavigationView;

    private List<String> citiesList = new ArrayList<>();
    private String selectedCity = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volunteer_request);

        initializeViews();
        setupBottomNavigation();
        setupTextWatchers();
        fetchCities(); // Fetch cities from API

        btnSubmit.setOnClickListener(v -> validateAndSubmit());
        ivBack.setOnClickListener(v -> finish());
    }

    private void initializeViews() {
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        etReason = findViewById(R.id.etReason);
        spinnerCity = findViewById(R.id.spinnerCity);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        nameInputLayout = findViewById(R.id.nameInputLayout);
        emailInputLayout = findViewById(R.id.emailInputLayout);
        phoneInputLayout = findViewById(R.id.phoneInputLayout);
        placeInputLayout = findViewById(R.id.placeInputLayout);

        btnSubmit = findViewById(R.id.btnSubmitVolunteer);
        progressBar = findViewById(R.id.progressBar);
        ivBack = findViewById(R.id.ivBack);
    }

    private void setupBottomNavigation() {
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                startActivity(new Intent(VolunteerRequestActivity.this, DashboardActivity.class));
                return true;
            } else if (itemId == R.id.nav_donate) {
                startActivity(new Intent(VolunteerRequestActivity.this, DonateActivity.class));
                return true;
            } else if (itemId == R.id.nav_report) {
                startActivity(new Intent(VolunteerRequestActivity.this, ReportChildActivity.class));
                return true;
            } else if (itemId == R.id.nav_volunteer) {
                // Already on volunteer page
                return true;
            } else if (itemId == R.id.nav_profile) {
                startActivity(new Intent(VolunteerRequestActivity.this, SettingsActivity.class));
                return true;
            }
            return false;
        });

        // Set volunteer as selected by default
        bottomNavigationView.setSelectedItemId(R.id.nav_volunteer);
    }

    private void fetchCities() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<CityResponse> call = apiService.getAllCities();

        call.enqueue(new Callback<CityResponse>() {
            @Override
            public void onResponse(Call<CityResponse> call, Response<CityResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    citiesList = response.body().getCities();
                    if (citiesList != null && !citiesList.isEmpty()) {
                        citiesList.add(0, "Select Your City");
                        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(VolunteerRequestActivity.this,
                                android.R.layout.simple_spinner_dropdown_item, citiesList);
                        spinnerCity.setAdapter(cityAdapter);

                        // Set spinner selection listener
                        spinnerCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                selectedCity = parent.getItemAtPosition(position).toString();
                                // Clear error when user selects a city
                                if (!selectedCity.equals("Select Your City")) {
                                    placeInputLayout.setError(null);
                                }
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {
                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(Call<CityResponse> call, Throwable t) {
                Toast.makeText(VolunteerRequestActivity.this, "Failed to fetch cities", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupTextWatchers() {
        // Clear errors when user starts typing
        etName.addTextChangedListener(new ClearErrorTextWatcher(nameInputLayout));
        etEmail.addTextChangedListener(new ClearErrorTextWatcher(emailInputLayout));
        etPhone.addTextChangedListener(new ClearErrorTextWatcher(phoneInputLayout));

        // Real-time validation for phone
        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                phoneInputLayout.setError(null);
            }

            @Override
            public void afterTextChanged(Editable s) {
                String phone = s.toString();
                if (!phone.isEmpty()) {
                    if (!phone.matches("^[6-9]\\d{0,9}$")) {
                        phoneInputLayout.setError("Enter valid Indian mobile number");
                    } else if (phone.length() < 10) {
                        phoneInputLayout.setError("10 digits required");
                    } else {
                        phoneInputLayout.setError(null);
                    }
                }
            }
        });
    }

    private void validateAndSubmit() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String reason = etReason.getText().toString().trim();

        boolean isValid = true;

        // Strict name validation
        if (TextUtils.isEmpty(name)) {
            nameInputLayout.setError("Name is required");
            isValid = false;
        } else if (!name.matches("^[a-zA-Z\\s.'-]{2,50}$")) {
            nameInputLayout.setError("Only letters, spaces, . ' - allowed (2-50 characters)");
            isValid = false;
        }

        // Strict email validation
        if (TextUtils.isEmpty(email)) {
            emailInputLayout.setError("Email is required");
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInputLayout.setError("Please enter a valid email address");
            isValid = false;
        }

        // Strict phone validation (Indian numbers only)
        if (TextUtils.isEmpty(phone)) {
            phoneInputLayout.setError("Phone number is required");
            isValid = false;
        } else if (!phone.matches("^[6-9]\\d{9}$")) {
            phoneInputLayout.setError("Please enter a valid 10-digit Indian mobile number");
            isValid = false;
        }

        // City validation
        if (selectedCity.equals("Select Your City") || selectedCity.isEmpty()) {
            placeInputLayout.setError("Please select your city");
            isValid = false;
        }

        if (!isValid) {
            return;
        }

        // All validations passed, proceed with submission
        submitForm(name, email, phone, selectedCity, reason);
    }

    private void submitForm(String name, String email, String phone, String place, String reason) {
        // Show loading state
        progressBar.setVisibility(View.VISIBLE);
        btnSubmit.setEnabled(false);

        // Create volunteer request object
        VolunteerRequest volunteerRequest = new VolunteerRequest(name, email, phone, place, reason);

        // Make API call using Retrofit
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<Volunteer_OtpResponse> call = apiService.registerVolunteer(volunteerRequest);

        call.enqueue(new Callback<Volunteer_OtpResponse>() {
            @Override
            public void onResponse(Call<Volunteer_OtpResponse> call, Response<Volunteer_OtpResponse> response) {
                // Hide loading state
                progressBar.setVisibility(View.GONE);
                btnSubmit.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    Volunteer_OtpResponse apiResponse = response.body();

                    if ("success".equals(apiResponse.getStatus())) {
                        // Show success message
                        Toast.makeText(VolunteerRequestActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();

                        // Navigate to success activity
                        Intent intent = new Intent(VolunteerRequestActivity.this, VolunteerSuccessActivity.class);
                        intent.putExtra("name", name);
                        startActivity(intent);
                        finish();
                    } else {
                        // Show error message from server
                        Toast.makeText(VolunteerRequestActivity.this, apiResponse.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Handle server error
                    Toast.makeText(VolunteerRequestActivity.this, "Server error. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Volunteer_OtpResponse> call, Throwable t) {
                // Hide loading state
                progressBar.setVisibility(View.GONE);
                btnSubmit.setEnabled(true);

                // Handle network failure
                Toast.makeText(VolunteerRequestActivity.this, "Network error. Please check your connection.", Toast.LENGTH_SHORT).show();
                t.printStackTrace(); // For debugging
            }
        });
    }

    // TextWatcher to clear error when user starts typing
    private class ClearErrorTextWatcher implements TextWatcher {
        private TextInputLayout inputLayout;

        ClearErrorTextWatcher(TextInputLayout inputLayout) {
            this.inputLayout = inputLayout;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            inputLayout.setError(null);
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Set volunteer as selected when returning to this activity
        if (bottomNavigationView != null) {
            bottomNavigationView.setSelectedItemId(R.id.nav_volunteer);
        }
    }
}