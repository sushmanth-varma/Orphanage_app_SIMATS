package com.SIMATS.hope;

public class StatusUpdateResponse_Volunteer {
    private String status;
    private String message;

    public String getStatus() { return status; }
    public String getMessage() { return message; }
}
